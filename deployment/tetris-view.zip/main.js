(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "../p2pt/src/p2pt.umd.min.js":
/*!*******************************************************!*\
  !*** d:/Repositories/tetris/p2pt/src/p2pt.umd.min.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

!function(e){if(true)module.exports=e();else {}}((function(){var e,t,n=function(e){var t;return function(n){return t||e(t={exports:{},parent:n},t.exports),t.exports}},r=n((function(e,t){(function(t,n){"use strict";var r;e.exports=k,k.ReadableState=E,q.EventEmitter;var s,c=function(e,t){return e.listeners(t).length},l=u({}).Buffer,f=n.Uint8Array||function(){};s=oe&&oe.debuglog?oe.debuglog("stream"):function(){};var d,p,g,y=me.getHighWaterMark,_=pe.codes,b=_.ERR_INVALID_ARG_TYPE,m=_.ERR_STREAM_PUSH_AFTER_EOF,w=_.ERR_METHOD_NOT_IMPLEMENTED,v=_.ERR_STREAM_UNSHIFT_AFTER_END_EVENT;we(k,ie);var C=de.errorOrDestroy,S=["error","close","destroy","pause","resume"];function E(e,t,n){r=r||h({}),e=e||{},"boolean"!=typeof n&&(n=t instanceof r),this.objectMode=!!e.objectMode,n&&(this.objectMode=this.objectMode||!!e.readableObjectMode),this.highWaterMark=y(this,e,"readableHighWaterMark",n),this.buffer=new fe,this.length=0,this.pipes=null,this.pipesCount=0,this.flowing=null,this.ended=!1,this.endEmitted=!1,this.reading=!1,this.sync=!0,this.needReadable=!1,this.emittedReadable=!1,this.readableListening=!1,this.resumeScheduled=!1,this.paused=!0,this.emitClose=!1!==e.emitClose,this.autoDestroy=!!e.autoDestroy,this.destroyed=!1,this.defaultEncoding=e.defaultEncoding||"utf8",this.awaitDrain=0,this.readingMore=!1,this.decoder=null,this.encoding=null,e.encoding&&(d||(d=a({}).StringDecoder),this.decoder=new d(e.encoding),this.encoding=e.encoding)}function k(e){if(r=r||h({}),!(this instanceof k))return new k(e);var t=this instanceof r;this._readableState=new E(e,this,t),this.readable=!0,e&&("function"==typeof e.read&&(this._read=e.read),"function"==typeof e.destroy&&(this._destroy=e.destroy)),ie.call(this)}function R(e,t,n,r,i){s("readableAddChunk",t);var o,a=e._readableState;if(null===t)a.reading=!1,function(e,t){if(s("onEofChunk"),!t.ended){if(t.decoder){var n=t.decoder.end();n&&n.length&&(t.buffer.push(n),t.length+=t.objectMode?1:n.length)}t.ended=!0,t.sync?L(e):(t.needReadable=!1,t.emittedReadable||(t.emittedReadable=!0,O(e)))}}(e,a);else if(i||(o=function(e,t){var n,r;return r=t,l.isBuffer(r)||r instanceof f||"string"==typeof t||void 0===t||e.objectMode||(n=new b("chunk",["string","Buffer","Uint8Array"],t)),n}(a,t)),o)C(e,o);else if(a.objectMode||t&&t.length>0)if("string"==typeof t||a.objectMode||Object.getPrototypeOf(t)===l.prototype||(t=function(e){return l.from(e)}(t)),r)a.endEmitted?C(e,new v):T(e,a,t,!0);else if(a.ended)C(e,new m);else{if(a.destroyed)return!1;a.reading=!1,a.decoder&&!n?(t=a.decoder.write(t),a.objectMode||0!==t.length?T(e,a,t,!1):x(e,a)):T(e,a,t,!1)}else r||(a.reading=!1,x(e,a));return!a.ended&&(a.length<a.highWaterMark||0===a.length)}function T(e,t,n,r){t.flowing&&0===t.length&&!t.sync?(t.awaitDrain=0,e.emit("data",n)):(t.length+=t.objectMode?1:n.length,r?t.buffer.unshift(n):t.buffer.push(n),t.needReadable&&L(e)),x(e,t)}Object.defineProperty(k.prototype,"destroyed",{enumerable:!1,get:function(){return void 0!==this._readableState&&this._readableState.destroyed},set:function(e){this._readableState&&(this._readableState.destroyed=e)}}),k.prototype.destroy=de.destroy,k.prototype._undestroy=de.undestroy,k.prototype._destroy=function(e,t){t(e)},k.prototype.push=function(e,t){var n,r=this._readableState;return r.objectMode?n=!0:"string"==typeof e&&((t=t||r.defaultEncoding)!==r.encoding&&(e=l.from(e,t),t=""),n=!0),R(this,e,t,!1,n)},k.prototype.unshift=function(e){return R(this,e,null,!0,!1)},k.prototype.isPaused=function(){return!1===this._readableState.flowing},k.prototype.setEncoding=function(e){d||(d=a({}).StringDecoder);var t=new d(e);this._readableState.decoder=t,this._readableState.encoding=this._readableState.decoder.encoding;for(var n=this._readableState.buffer.head,r="";null!==n;)r+=t.write(n.data),n=n.next;return this._readableState.buffer.clear(),""!==r&&this._readableState.buffer.push(r),this._readableState.length=r.length,this};function A(e,t){return e<=0||0===t.length&&t.ended?0:t.objectMode?1:e!=e?t.flowing&&t.length?t.buffer.head.data.length:t.length:(e>t.highWaterMark&&(t.highWaterMark=function(e){return e>=1073741824?e=1073741824:(e--,e|=e>>>1,e|=e>>>2,e|=e>>>4,e|=e>>>8,e|=e>>>16,e++),e}(e)),e<=t.length?e:t.ended?t.length:(t.needReadable=!0,0))}function L(e){var n=e._readableState;s("emitReadable",n.needReadable,n.emittedReadable),n.needReadable=!1,n.emittedReadable||(s("emitReadable",n.flowing),n.emittedReadable=!0,t.nextTick(O,e))}function O(e){var t=e._readableState;s("emitReadable_",t.destroyed,t.length,t.ended),t.destroyed||!t.length&&!t.ended||(e.emit("readable"),t.emittedReadable=!1),t.needReadable=!t.flowing&&!t.ended&&t.length<=t.highWaterMark,P(e)}function x(e,n){n.readingMore||(n.readingMore=!0,t.nextTick(M,e,n))}function M(e,t){for(;!t.reading&&!t.ended&&(t.length<t.highWaterMark||t.flowing&&0===t.length);){var n=t.length;if(s("maybeReadMore read 0"),e.read(0),n===t.length)break}t.readingMore=!1}function N(e){var t=e._readableState;t.readableListening=e.listenerCount("readable")>0,t.resumeScheduled&&!t.paused?t.flowing=!0:e.listenerCount("data")>0&&e.resume()}function I(e){s("readable nexttick read 0"),e.read(0)}function B(e,t){s("resume",t.reading),t.reading||e.read(0),t.resumeScheduled=!1,e.emit("resume"),P(e),t.flowing&&!t.reading&&e.read(0)}function P(e){var t=e._readableState;for(s("flow",t.flowing);t.flowing&&null!==e.read(););}function D(e,t){return 0===t.length?null:(t.objectMode?n=t.buffer.shift():!e||e>=t.length?(n=t.decoder?t.buffer.join(""):1===t.buffer.length?t.buffer.first():t.buffer.concat(t.length),t.buffer.clear()):n=t.buffer.consume(e,t.decoder),n);var n}function U(e){var n=e._readableState;s("endReadable",n.endEmitted),n.endEmitted||(n.ended=!0,t.nextTick(F,n,e))}function F(e,t){if(s("endReadableNT",e.endEmitted,e.length),!e.endEmitted&&0===e.length&&(e.endEmitted=!0,t.readable=!1,t.emit("end"),e.autoDestroy)){var n=t._writableState;(!n||n.autoDestroy&&n.finished)&&t.destroy()}}function j(e,t){for(var n=0,r=e.length;n<r;n++)if(e[n]===t)return n;return-1}k.prototype.read=function(e){s("read",e),e=parseInt(e,10);var t=this._readableState,n=e;if(0!==e&&(t.emittedReadable=!1),0===e&&t.needReadable&&((0!==t.highWaterMark?t.length>=t.highWaterMark:t.length>0)||t.ended))return s("read: emitReadable",t.length,t.ended),0===t.length&&t.ended?U(this):L(this),null;if(0===(e=A(e,t))&&t.ended)return 0===t.length&&U(this),null;var r,i=t.needReadable;return s("need readable",i),(0===t.length||t.length-e<t.highWaterMark)&&s("length less than watermark",i=!0),t.ended||t.reading?s("reading or ended",i=!1):i&&(s("do read"),t.reading=!0,t.sync=!0,0===t.length&&(t.needReadable=!0),this._read(t.highWaterMark),t.sync=!1,t.reading||(e=A(n,t))),null===(r=e>0?D(e,t):null)?(t.needReadable=t.length<=t.highWaterMark,e=0):(t.length-=e,t.awaitDrain=0),0===t.length&&(t.ended||(t.needReadable=!0),n!==e&&t.ended&&U(this)),null!==r&&this.emit("data",r),r},k.prototype._read=function(e){C(this,new w("_read()"))},k.prototype.pipe=function(e,n){var r=this,i=this._readableState;switch(i.pipesCount){case 0:i.pipes=e;break;case 1:i.pipes=[i.pipes,e];break;default:i.pipes.push(e)}i.pipesCount+=1,s("pipe count=%d opts=%j",i.pipesCount,n);var o=n&&!1===n.end||e===t.stdout||e===t.stderr?g:a;function a(){s("onend"),e.end()}i.endEmitted?t.nextTick(o):r.once("end",o),e.on("unpipe",(function t(n,o){s("onunpipe"),n===r&&o&&!1===o.hasUnpiped&&(o.hasUnpiped=!0,s("cleanup"),e.removeListener("close",d),e.removeListener("finish",p),e.removeListener("drain",h),e.removeListener("error",f),e.removeListener("unpipe",t),r.removeListener("end",a),r.removeListener("end",g),r.removeListener("data",l),u=!0,!i.awaitDrain||e._writableState&&!e._writableState.needDrain||h())}));var h=function(e){return function(){var t=e._readableState;s("pipeOnDrain",t.awaitDrain),t.awaitDrain&&t.awaitDrain--,0===t.awaitDrain&&c(e,"data")&&(t.flowing=!0,P(e))}}(r);e.on("drain",h);var u=!1;function l(t){s("ondata");var n=e.write(t);s("dest.write",n),!1===n&&((1===i.pipesCount&&i.pipes===e||i.pipesCount>1&&-1!==j(i.pipes,e))&&!u&&(s("false write response, pause",i.awaitDrain),i.awaitDrain++),r.pause())}function f(t){s("onerror",t),g(),e.removeListener("error",f),0===c(e,"error")&&C(e,t)}function d(){e.removeListener("finish",p),g()}function p(){s("onfinish"),e.removeListener("close",d),g()}function g(){s("unpipe"),r.unpipe(e)}return r.on("data",l),function(e,t,n){if("function"==typeof e.prependListener)return e.prependListener("error",n);e._events&&e._events.error?Array.isArray(e._events.error)?e._events.error.unshift(n):e._events.error=[n,e._events.error]:e.on("error",n)}(e,0,f),e.once("close",d),e.once("finish",p),e.emit("pipe",r),i.flowing||(s("pipe resume"),r.resume()),e},k.prototype.unpipe=function(e){var t=this._readableState,n={hasUnpiped:!1};if(0===t.pipesCount)return this;if(1===t.pipesCount)return e&&e!==t.pipes||(e||(e=t.pipes),t.pipes=null,t.pipesCount=0,t.flowing=!1,e&&e.emit("unpipe",this,n)),this;if(!e){var r=t.pipes,i=t.pipesCount;t.pipes=null,t.pipesCount=0,t.flowing=!1;for(var o=0;o<i;o++)r[o].emit("unpipe",this,{hasUnpiped:!1});return this}var s=j(t.pipes,e);return-1===s||(t.pipes.splice(s,1),t.pipesCount-=1,1===t.pipesCount&&(t.pipes=t.pipes[0]),e.emit("unpipe",this,n)),this},k.prototype.on=function(e,n){var r=ie.prototype.on.call(this,e,n),i=this._readableState;return"data"===e?(i.readableListening=this.listenerCount("readable")>0,!1!==i.flowing&&this.resume()):"readable"===e&&(i.endEmitted||i.readableListening||(i.readableListening=i.needReadable=!0,i.flowing=!1,i.emittedReadable=!1,s("on readable",i.length,i.reading),i.length?L(this):i.reading||t.nextTick(I,this))),r},k.prototype.addListener=k.prototype.on,k.prototype.removeListener=function(e,n){var r=ie.prototype.removeListener.call(this,e,n);return"readable"===e&&t.nextTick(N,this),r},k.prototype.removeAllListeners=function(e){var n=ie.prototype.removeAllListeners.apply(this,arguments);return"readable"!==e&&void 0!==e||t.nextTick(N,this),n},k.prototype.resume=function(){var e=this._readableState;return e.flowing||(s("resume"),e.flowing=!e.readableListening,function(e,n){n.resumeScheduled||(n.resumeScheduled=!0,t.nextTick(B,e,n))}(this,e)),e.paused=!1,this},k.prototype.pause=function(){return s("call pause flowing=%j",this._readableState.flowing),!1!==this._readableState.flowing&&(s("pause"),this._readableState.flowing=!1,this.emit("pause")),this._readableState.paused=!0,this},k.prototype.wrap=function(e){var t=this,n=this._readableState,r=!1;for(var i in e.on("end",(function(){if(s("wrapped end"),n.decoder&&!n.ended){var e=n.decoder.end();e&&e.length&&t.push(e)}t.push(null)})),e.on("data",(function(i){s("wrapped data"),n.decoder&&(i=n.decoder.write(i)),n.objectMode&&null==i||(n.objectMode||i&&i.length)&&(t.push(i)||(r=!0,e.pause()))})),e)void 0===this[i]&&"function"==typeof e[i]&&(this[i]=function(t){return function(){return e[t].apply(e,arguments)}}(i));for(var o=0;o<S.length;o++)e.on(S[o],this.emit.bind(this,S[o]));return this._read=function(t){s("wrapped _read",t),r&&(r=!1,e.resume())},this},"function"==typeof Symbol&&(k.prototype[Symbol.asyncIterator]=function(){return void 0===p&&(p=o({})),p(this)}),Object.defineProperty(k.prototype,"readableHighWaterMark",{enumerable:!1,get:function(){return this._readableState.highWaterMark}}),Object.defineProperty(k.prototype,"readableBuffer",{enumerable:!1,get:function(){return this._readableState&&this._readableState.buffer}}),Object.defineProperty(k.prototype,"readableFlowing",{enumerable:!1,get:function(){return this._readableState.flowing},set:function(e){this._readableState&&(this._readableState.flowing=e)}}),k._fromList=D,Object.defineProperty(k.prototype,"readableLength",{enumerable:!1,get:function(){return this._readableState.length}}),"function"==typeof Symbol&&(k.from=function(e,t){return void 0===g&&(g=i({})),g(k,e,t)})}).call(this,f,"undefined"!=typeof global?global:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{})})),i=n((function(e,t){e.exports=function(){throw new Error("Readable.from is not available in the browser")}})),o=n((function(e,t){(function(t){"use strict";var n;function r(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var i=s({}),o=Symbol("lastResolve"),a=Symbol("lastReject"),h=Symbol("error"),c=Symbol("ended"),u=Symbol("lastPromise"),l=Symbol("handlePromise"),f=Symbol("stream");function d(e,t){return{value:e,done:t}}function p(e){var t=e[o];if(null!==t){var n=e[f].read();null!==n&&(e[u]=null,e[o]=null,e[a]=null,t(d(n,!1)))}}var g=Object.getPrototypeOf((function(){})),y=Object.setPrototypeOf((r(n={get stream(){return this[f]},next:function(){var e=this,n=this[h];if(null!==n)return Promise.reject(n);if(this[c])return Promise.resolve(d(void 0,!0));if(this[f].destroyed)return new Promise((function(n,r){t.nextTick((function(){e[h]?r(e[h]):n(d(void 0,!0))}))}));var r,i=this[u];if(i)r=new Promise(function(e,t){return function(n,r){e.then((function(){t[c]?n(d(void 0,!0)):t[l](n,r)}),r)}}(i,this));else{var o=this[f].read();if(null!==o)return Promise.resolve(d(o,!1));r=new Promise(this[l])}return this[u]=r,r}},Symbol.asyncIterator,(function(){return this})),r(n,"return",(function(){var e=this;return new Promise((function(t,n){e[f].destroy(null,(function(e){e?n(e):t(d(void 0,!0))}))}))})),n),g);e.exports=function(e){var n,s=Object.create(y,(r(n={},f,{value:e,writable:!0}),r(n,o,{value:null,writable:!0}),r(n,a,{value:null,writable:!0}),r(n,h,{value:null,writable:!0}),r(n,c,{value:e._readableState.endEmitted,writable:!0}),r(n,l,{value:function(e,t){var n=s[f].read();n?(s[u]=null,s[o]=null,s[a]=null,e(d(n,!1))):(s[o]=e,s[a]=t)},writable:!0}),n));return s[u]=null,i(e,(function(e){if(e&&"ERR_STREAM_PREMATURE_CLOSE"!==e.code){var t=s[a];return null!==t&&(s[u]=null,s[o]=null,s[a]=null,t(e)),void(s[h]=e)}var n=s[o];null!==n&&(s[u]=null,s[o]=null,s[a]=null,n(d(void 0,!0))),s[c]=!0})),e.on("readable",function(e){t.nextTick(p,e)}.bind(null,s)),s}}).call(this,f)})),s=n((function(e,t){"use strict";var n=pe.codes.ERR_STREAM_PREMATURE_CLOSE;function r(){}e.exports=function e(t,i,o){if("function"==typeof i)return e(t,null,i);i||(i={}),o=function(e){var t=!1;return function(){if(!t){t=!0;for(var n=arguments.length,r=new Array(n),i=0;i<n;i++)r[i]=arguments[i];e.apply(this,r)}}}(o||r);var s=i.readable||!1!==i.readable&&t.readable,a=i.writable||!1!==i.writable&&t.writable,h=function(){t.writable||u()},c=t._writableState&&t._writableState.finished,u=function(){a=!1,c=!0,s||o.call(t)},l=t._readableState&&t._readableState.endEmitted,f=function(){s=!1,l=!0,a||o.call(t)},d=function(e){o.call(t,e)},p=function(){var e;return s&&!l?(t._readableState&&t._readableState.ended||(e=new n),o.call(t,e)):a&&!c?(t._writableState&&t._writableState.ended||(e=new n),o.call(t,e)):void 0},g=function(){t.req.on("finish",u)};return function(e){return e.setHeader&&"function"==typeof e.abort}(t)?(t.on("complete",u),t.on("abort",p),t.req?g():t.on("request",g)):a&&!t._writableState&&(t.on("end",h),t.on("close",h)),t.on("end",f),t.on("finish",u),!1!==i.error&&t.on("error",d),t.on("close",p),function(){t.removeListener("complete",u),t.removeListener("abort",p),t.removeListener("request",g),t.req&&t.req.removeListener("finish",u),t.removeListener("end",h),t.removeListener("close",h),t.removeListener("finish",u),t.removeListener("end",f),t.removeListener("error",d),t.removeListener("close",p)}}})),a=n((function(e,t){"use strict";var n=D.Buffer,r=n.isEncoding||function(e){switch((e=""+e)&&e.toLowerCase()){case"hex":case"utf8":case"utf-8":case"ascii":case"binary":case"base64":case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":case"raw":return!0;default:return!1}};function i(e){var t;switch(this.encoding=function(e){var t=function(e){if(!e)return"utf8";for(var t;;)switch(e){case"utf8":case"utf-8":return"utf8";case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return"utf16le";case"latin1":case"binary":return"latin1";case"base64":case"ascii":case"hex":return e;default:if(t)return;e=(""+e).toLowerCase(),t=!0}}(e);if("string"!=typeof t&&(n.isEncoding===r||!r(e)))throw new Error("Unknown encoding: "+e);return t||e}(e),this.encoding){case"utf16le":this.text=a,this.end=h,t=4;break;case"utf8":this.fillLast=s,t=4;break;case"base64":this.text=c,this.end=u,t=3;break;default:return this.write=l,void(this.end=f)}this.lastNeed=0,this.lastTotal=0,this.lastChar=n.allocUnsafe(t)}function o(e){return e<=127?0:e>>5==6?2:e>>4==14?3:e>>3==30?4:e>>6==2?-1:-2}function s(e){var t=this.lastTotal-this.lastNeed,n=function(e,t,n){if(128!=(192&t[0]))return e.lastNeed=0,"\ufffd";if(e.lastNeed>1&&t.length>1){if(128!=(192&t[1]))return e.lastNeed=1,"\ufffd";if(e.lastNeed>2&&t.length>2&&128!=(192&t[2]))return e.lastNeed=2,"\ufffd"}}(this,e);return void 0!==n?n:this.lastNeed<=e.length?(e.copy(this.lastChar,t,0,this.lastNeed),this.lastChar.toString(this.encoding,0,this.lastTotal)):(e.copy(this.lastChar,t,0,e.length),void(this.lastNeed-=e.length))}function a(e,t){if((e.length-t)%2==0){var n=e.toString("utf16le",t);if(n){var r=n.charCodeAt(n.length-1);if(r>=55296&&r<=56319)return this.lastNeed=2,this.lastTotal=4,this.lastChar[0]=e[e.length-2],this.lastChar[1]=e[e.length-1],n.slice(0,-1)}return n}return this.lastNeed=1,this.lastTotal=2,this.lastChar[0]=e[e.length-1],e.toString("utf16le",t,e.length-1)}function h(e){var t=e&&e.length?this.write(e):"";if(this.lastNeed){var n=this.lastTotal-this.lastNeed;return t+this.lastChar.toString("utf16le",0,n)}return t}function c(e,t){var n=(e.length-t)%3;return 0===n?e.toString("base64",t):(this.lastNeed=3-n,this.lastTotal=3,1===n?this.lastChar[0]=e[e.length-1]:(this.lastChar[0]=e[e.length-2],this.lastChar[1]=e[e.length-1]),e.toString("base64",t,e.length-n))}function u(e){var t=e&&e.length?this.write(e):"";return this.lastNeed?t+this.lastChar.toString("base64",0,3-this.lastNeed):t}function l(e){return e.toString(this.encoding)}function f(e){return e&&e.length?this.write(e):""}t.StringDecoder=i,i.prototype.write=function(e){if(0===e.length)return"";var t,n;if(this.lastNeed){if(void 0===(t=this.fillLast(e)))return"";n=this.lastNeed,this.lastNeed=0}else n=0;return n<e.length?t?t+this.text(e,n):this.text(e,n):t||""},i.prototype.end=function(e){var t=e&&e.length?this.write(e):"";return this.lastNeed?t+"\ufffd":t},i.prototype.text=function(e,t){var n=function(e,t,n){var r=t.length-1;if(r<n)return 0;var i=o(t[r]);return i>=0?(i>0&&(e.lastNeed=i-1),i):--r<n||-2===i?0:(i=o(t[r]))>=0?(i>0&&(e.lastNeed=i-2),i):--r<n||-2===i?0:(i=o(t[r]))>=0?(i>0&&(2===i?i=0:e.lastNeed=i-3),i):0}(this,e,t);if(!this.lastNeed)return e.toString("utf8",t);this.lastTotal=n;var r=e.length-(n-this.lastNeed);return e.copy(this.lastChar,0,r),e.toString("utf8",t,r)},i.prototype.fillLast=function(e){if(this.lastNeed<=e.length)return e.copy(this.lastChar,this.lastTotal-this.lastNeed,0,this.lastNeed),this.lastChar.toString(this.encoding,0,this.lastTotal);e.copy(this.lastChar,this.lastTotal-this.lastNeed,0,e.length),this.lastNeed-=e.length}})),h=n((function(e,t){(function(t){"use strict";var n=Object.keys||function(e){var t=[];for(var n in e)t.push(n);return t};e.exports=u;var i=r({}),o=c({});we(u,i);for(var s=n(o.prototype),a=0;a<s.length;a++){var h=s[a];u.prototype[h]||(u.prototype[h]=o.prototype[h])}function u(e){if(!(this instanceof u))return new u(e);i.call(this,e),o.call(this,e),this.allowHalfOpen=!0,e&&(!1===e.readable&&(this.readable=!1),!1===e.writable&&(this.writable=!1),!1===e.allowHalfOpen&&(this.allowHalfOpen=!1,this.once("end",l)))}function l(){this._writableState.ended||t.nextTick(f,this)}function f(e){e.end()}Object.defineProperty(u.prototype,"writableHighWaterMark",{enumerable:!1,get:function(){return this._writableState.highWaterMark}}),Object.defineProperty(u.prototype,"writableBuffer",{enumerable:!1,get:function(){return this._writableState&&this._writableState.getBuffer()}}),Object.defineProperty(u.prototype,"writableLength",{enumerable:!1,get:function(){return this._writableState.length}}),Object.defineProperty(u.prototype,"destroyed",{enumerable:!1,get:function(){return void 0!==this._readableState&&void 0!==this._writableState&&this._readableState.destroyed&&this._writableState.destroyed},set:function(e){void 0!==this._readableState&&void 0!==this._writableState&&(this._readableState.destroyed=e,this._writableState.destroyed=e)}})}).call(this,f)})),c=n((function(e,t){(function(t,n){"use strict";function r(e){var t=this;this.next=null,this.entry=null,this.finish=function(){!function(e,t,n){var r=e.entry;for(e.entry=null;r;){var i=r.callback;t.pendingcb--,i(void 0),r=r.next}t.corkedRequestsFree.next=e}(t,e)}}var i;e.exports=E,E.WritableState=S;var o,s={deprecate:ve},a=u({}).Buffer,c=n.Uint8Array||function(){},l=me.getHighWaterMark,f=pe.codes,d=f.ERR_INVALID_ARG_TYPE,p=f.ERR_METHOD_NOT_IMPLEMENTED,g=f.ERR_MULTIPLE_CALLBACK,y=f.ERR_STREAM_CANNOT_PIPE,_=f.ERR_STREAM_DESTROYED,b=f.ERR_STREAM_NULL_VALUES,m=f.ERR_STREAM_WRITE_AFTER_END,w=f.ERR_UNKNOWN_ENCODING,v=de.errorOrDestroy;function C(){}function S(e,n,o){i=i||h({}),e=e||{},"boolean"!=typeof o&&(o=n instanceof i),this.objectMode=!!e.objectMode,o&&(this.objectMode=this.objectMode||!!e.writableObjectMode),this.highWaterMark=l(this,e,"writableHighWaterMark",o),this.finalCalled=!1,this.needDrain=!1,this.ending=!1,this.ended=!1,this.finished=!1,this.destroyed=!1;var s=!1===e.decodeStrings;this.decodeStrings=!s,this.defaultEncoding=e.defaultEncoding||"utf8",this.length=0,this.writing=!1,this.corked=0,this.sync=!0,this.bufferProcessing=!1,this.onwrite=function(e){!function(e,n){var r=e._writableState,i=r.sync,o=r.writecb;if("function"!=typeof o)throw new g;if(function(e){e.writing=!1,e.writecb=null,e.length-=e.writelen,e.writelen=0}(r),n)!function(e,n,r,i,o){--n.pendingcb,r?(t.nextTick(o,i),t.nextTick(O,e,n),e._writableState.errorEmitted=!0,v(e,i)):(o(i),e._writableState.errorEmitted=!0,v(e,i),O(e,n))}(e,r,i,n,o);else{var s=A(r)||e.destroyed;s||r.corked||r.bufferProcessing||!r.bufferedRequest||T(e,r),i?t.nextTick(R,e,r,s,o):R(e,r,s,o)}}(n,e)},this.writecb=null,this.writelen=0,this.bufferedRequest=null,this.lastBufferedRequest=null,this.pendingcb=0,this.prefinished=!1,this.errorEmitted=!1,this.emitClose=!1!==e.emitClose,this.autoDestroy=!!e.autoDestroy,this.bufferedRequestCount=0,this.corkedRequestsFree=new r(this)}function E(e){var t=this instanceof(i=i||h({}));if(!t&&!o.call(E,this))return new E(e);this._writableState=new S(e,this,t),this.writable=!0,e&&("function"==typeof e.write&&(this._write=e.write),"function"==typeof e.writev&&(this._writev=e.writev),"function"==typeof e.destroy&&(this._destroy=e.destroy),"function"==typeof e.final&&(this._final=e.final)),ie.call(this)}function k(e,t,n,r,i,o,s){t.writelen=r,t.writecb=s,t.writing=!0,t.sync=!0,t.destroyed?t.onwrite(new _("write")):n?e._writev(i,t.onwrite):e._write(i,o,t.onwrite),t.sync=!1}function R(e,t,n,r){n||function(e,t){0===t.length&&t.needDrain&&(t.needDrain=!1,e.emit("drain"))}(e,t),t.pendingcb--,r(),O(e,t)}function T(e,t){t.bufferProcessing=!0;var n=t.bufferedRequest;if(e._writev&&n&&n.next){var i=t.bufferedRequestCount,o=new Array(i),s=t.corkedRequestsFree;s.entry=n;for(var a=0,h=!0;n;)o[a]=n,n.isBuf||(h=!1),n=n.next,a+=1;o.allBuffers=h,k(e,t,!0,t.length,o,"",s.finish),t.pendingcb++,t.lastBufferedRequest=null,s.next?(t.corkedRequestsFree=s.next,s.next=null):t.corkedRequestsFree=new r(t),t.bufferedRequestCount=0}else{for(;n;){var c=n.chunk,u=n.encoding,l=n.callback;if(k(e,t,!1,t.objectMode?1:c.length,c,u,l),n=n.next,t.bufferedRequestCount--,t.writing)break}null===n&&(t.lastBufferedRequest=null)}t.bufferedRequest=n,t.bufferProcessing=!1}function A(e){return e.ending&&0===e.length&&null===e.bufferedRequest&&!e.finished&&!e.writing}function L(e,t){e._final((function(n){t.pendingcb--,n&&v(e,n),t.prefinished=!0,e.emit("prefinish"),O(e,t)}))}function O(e,n){var r=A(n);if(r&&(function(e,n){n.prefinished||n.finalCalled||("function"!=typeof e._final||n.destroyed?(n.prefinished=!0,e.emit("prefinish")):(n.pendingcb++,n.finalCalled=!0,t.nextTick(L,e,n)))}(e,n),0===n.pendingcb&&(n.finished=!0,e.emit("finish"),n.autoDestroy))){var i=e._readableState;(!i||i.autoDestroy&&i.endEmitted)&&e.destroy()}return r}we(E,ie),S.prototype.getBuffer=function(){for(var e=this.bufferedRequest,t=[];e;)t.push(e),e=e.next;return t},function(){try{Object.defineProperty(S.prototype,"buffer",{get:s.deprecate((function(){return this.getBuffer()}),"_writableState.buffer is deprecated. Use _writableState.getBuffer instead.","DEP0003")})}catch(e){}}(),"function"==typeof Symbol&&Symbol.hasInstance&&"function"==typeof Function.prototype[Symbol.hasInstance]?(o=Function.prototype[Symbol.hasInstance],Object.defineProperty(E,Symbol.hasInstance,{value:function(e){return!!o.call(this,e)||this===E&&e&&e._writableState instanceof S}})):o=function(e){return e instanceof this},E.prototype.pipe=function(){v(this,new y)},E.prototype.write=function(e,n,r){var i,o=this._writableState,s=!1,h=!o.objectMode&&(i=e,a.isBuffer(i)||i instanceof c);return h&&!a.isBuffer(e)&&(e=function(e){return a.from(e)}(e)),"function"==typeof n&&(r=n,n=null),h?n="buffer":n||(n=o.defaultEncoding),"function"!=typeof r&&(r=C),o.ending?function(e,n){var r=new m;v(e,r),t.nextTick(n,r)}(this,r):(h||function(e,n,r,i){var o;return null===r?o=new b:"string"==typeof r||n.objectMode||(o=new d("chunk",["string","Buffer"],r)),!o||(v(e,o),t.nextTick(i,o),!1)}(this,o,e,r))&&(o.pendingcb++,s=function(e,t,n,r,i,o){if(!n){var s=function(e,t,n){return e.objectMode||!1===e.decodeStrings||"string"!=typeof t||(t=a.from(t,n)),t}(t,r,i);r!==s&&(n=!0,i="buffer",r=s)}var h=t.objectMode?1:r.length;t.length+=h;var c=t.length<t.highWaterMark;if(c||(t.needDrain=!0),t.writing||t.corked){var u=t.lastBufferedRequest;t.lastBufferedRequest={chunk:r,encoding:i,isBuf:n,callback:o,next:null},u?u.next=t.lastBufferedRequest:t.bufferedRequest=t.lastBufferedRequest,t.bufferedRequestCount+=1}else k(e,t,!1,h,r,i,o);return c}(this,o,h,e,n,r)),s},E.prototype.cork=function(){this._writableState.corked++},E.prototype.uncork=function(){var e=this._writableState;e.corked&&(e.corked--,e.writing||e.corked||e.bufferProcessing||!e.bufferedRequest||T(this,e))},E.prototype.setDefaultEncoding=function(e){if("string"==typeof e&&(e=e.toLowerCase()),!(["hex","utf8","utf-8","ascii","binary","base64","ucs2","ucs-2","utf16le","utf-16le","raw"].indexOf((e+"").toLowerCase())>-1))throw new w(e);return this._writableState.defaultEncoding=e,this},Object.defineProperty(E.prototype,"writableBuffer",{enumerable:!1,get:function(){return this._writableState&&this._writableState.getBuffer()}}),Object.defineProperty(E.prototype,"writableHighWaterMark",{enumerable:!1,get:function(){return this._writableState.highWaterMark}}),E.prototype._write=function(e,t,n){n(new p("_write()"))},E.prototype._writev=null,E.prototype.end=function(e,n,r){var i=this._writableState;return"function"==typeof e?(r=e,e=null,n=null):"function"==typeof n&&(r=n,n=null),null!=e&&this.write(e,n),i.corked&&(i.corked=1,this.uncork()),i.ending||function(e,n,r){n.ending=!0,O(e,n),r&&(n.finished?t.nextTick(r):e.once("finish",r)),n.ended=!0,e.writable=!1}(this,i,r),this},Object.defineProperty(E.prototype,"writableLength",{enumerable:!1,get:function(){return this._writableState.length}}),Object.defineProperty(E.prototype,"destroyed",{enumerable:!1,get:function(){return void 0!==this._writableState&&this._writableState.destroyed},set:function(e){this._writableState&&(this._writableState.destroyed=e)}}),E.prototype.destroy=de.destroy,E.prototype._undestroy=de.undestroy,E.prototype._destroy=function(e,t){t(e)}}).call(this,f,"undefined"!=typeof global?global:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{})})),u=n((function(e,t){(function(e){"use strict";t.Buffer=e,t.SlowBuffer=function(t){return+t!=t&&(t=0),e.alloc(+t)},t.INSPECT_MAX_BYTES=50;function n(t){if(t>2147483647)throw new RangeError('The value "'+t+'" is invalid for option "size"');var n=new Uint8Array(t);return n.__proto__=e.prototype,n}function e(e,t,n){if("number"==typeof e){if("string"==typeof t)throw new TypeError('The "string" argument must be of type string. Received type number');return o(e)}return r(e,t,n)}function r(t,r,i){if("string"==typeof t)return function(t,r){if("string"==typeof r&&""!==r||(r="utf8"),!e.isEncoding(r))throw new TypeError("Unknown encoding: "+r);var i=0|h(t,r),o=n(i),s=o.write(t,r);return s!==i&&(o=o.slice(0,s)),o}(t,r);if(ArrayBuffer.isView(t))return s(t);if(null==t)throw TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type "+typeof t);if(B(t,ArrayBuffer)||t&&B(t.buffer,ArrayBuffer))return function(t,n,r){if(n<0||t.byteLength<n)throw new RangeError('"offset" is outside of buffer bounds');if(t.byteLength<n+(r||0))throw new RangeError('"length" is outside of buffer bounds');var i;return(i=void 0===n&&void 0===r?new Uint8Array(t):void 0===r?new Uint8Array(t,n):new Uint8Array(t,n,r)).__proto__=e.prototype,i}(t,r,i);if("number"==typeof t)throw new TypeError('The "value" argument must not be of type number. Received type number');var o=t.valueOf&&t.valueOf();if(null!=o&&o!==t)return e.from(o,r,i);var c=function(t){if(e.isBuffer(t)){var r=0|a(t.length),i=n(r);return 0===i.length||t.copy(i,0,0,r),i}return void 0!==t.length?"number"!=typeof t.length||D(t.length)?n(0):s(t):"Buffer"===t.type&&Array.isArray(t.data)?s(t.data):void 0}(t);if(c)return c;if("undefined"!=typeof Symbol&&null!=Symbol.toPrimitive&&"function"==typeof t[Symbol.toPrimitive])return e.from(t[Symbol.toPrimitive]("string"),r,i);throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type "+typeof t)}function i(e){if("number"!=typeof e)throw new TypeError('"size" argument must be of type number');if(e<0)throw new RangeError('The value "'+e+'" is invalid for option "size"')}function o(e){return i(e),n(e<0?0:0|a(e))}function s(e){for(var t=e.length<0?0:0|a(e.length),r=n(t),i=0;i<t;i+=1)r[i]=255&e[i];return r}function a(e){if(e>=2147483647)throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x"+2147483647..toString(16)+" bytes");return 0|e}function h(t,n){if(e.isBuffer(t))return t.length;if(ArrayBuffer.isView(t)||B(t,ArrayBuffer))return t.byteLength;if("string"!=typeof t)throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type '+typeof t);var r=t.length,i=arguments.length>2&&!0===arguments[2];if(!i&&0===r)return 0;for(var o=!1;;)switch(n){case"ascii":case"latin1":case"binary":return r;case"utf8":case"utf-8":return M(t).length;case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return 2*r;case"hex":return r>>>1;case"base64":return N(t).length;default:if(o)return i?-1:M(t).length;n=(""+n).toLowerCase(),o=!0}}function c(e,t,n){var r=e[t];e[t]=e[n],e[n]=r}function u(t,n,r,i,o){if(0===t.length)return-1;if("string"==typeof r?(i=r,r=0):r>2147483647?r=2147483647:r<-2147483648&&(r=-2147483648),D(r=+r)&&(r=o?0:t.length-1),r<0&&(r=t.length+r),r>=t.length){if(o)return-1;r=t.length-1}else if(r<0){if(!o)return-1;r=0}if("string"==typeof n&&(n=e.from(n,i)),e.isBuffer(n))return 0===n.length?-1:l(t,n,r,i,o);if("number"==typeof n)return n&=255,"function"==typeof Uint8Array.prototype.indexOf?o?Uint8Array.prototype.indexOf.call(t,n,r):Uint8Array.prototype.lastIndexOf.call(t,n,r):l(t,[n],r,i,o);throw new TypeError("val must be string, number or Buffer")}function l(e,t,n,r,i){var o,s=1,a=e.length,h=t.length;if(void 0!==r&&("ucs2"===(r=String(r).toLowerCase())||"ucs-2"===r||"utf16le"===r||"utf-16le"===r)){if(e.length<2||t.length<2)return-1;s=2,a/=2,h/=2,n/=2}function c(e,t){return 1===s?e[t]:e.readUInt16BE(t*s)}if(i){var u=-1;for(o=n;o<a;o++)if(c(e,o)===c(t,-1===u?0:o-u)){if(-1===u&&(u=o),o-u+1===h)return u*s}else-1!==u&&(o-=o-u),u=-1}else for(n+h>a&&(n=a-h),o=n;o>=0;o--){for(var l=!0,f=0;f<h;f++)if(c(e,o+f)!==c(t,f)){l=!1;break}if(l)return o}return-1}function f(e,t,n,r){n=Number(n)||0;var i=e.length-n;r?(r=Number(r))>i&&(r=i):r=i;var o=t.length;r>o/2&&(r=o/2);for(var s=0;s<r;++s){var a=parseInt(t.substr(2*s,2),16);if(D(a))return s;e[n+s]=a}return s}function d(e,t,n,r){return I(M(t,e.length-n),e,n,r)}function p(e,t,n,r){return I(function(e){for(var t=[],n=0;n<e.length;++n)t.push(255&e.charCodeAt(n));return t}(t),e,n,r)}function g(e,t,n,r){return p(e,t,n,r)}function y(e,t,n,r){return I(N(t),e,n,r)}function _(e,t,n,r){return I(function(e,t){for(var n,r,i,o=[],s=0;s<e.length&&!((t-=2)<0);++s)r=(n=e.charCodeAt(s))>>8,i=n%256,o.push(i),o.push(r);return o}(t,e.length-n),e,n,r)}function b(e,t,n){return 0===t&&n===e.length?T.fromByteArray(e):T.fromByteArray(e.slice(t,n))}function m(e,t,n){n=Math.min(e.length,n);for(var r=[],i=t;i<n;){var o,s,a,h,c=e[i],u=null,l=c>239?4:c>223?3:c>191?2:1;if(i+l<=n)switch(l){case 1:c<128&&(u=c);break;case 2:128==(192&(o=e[i+1]))&&(h=(31&c)<<6|63&o)>127&&(u=h);break;case 3:o=e[i+1],s=e[i+2],128==(192&o)&&128==(192&s)&&(h=(15&c)<<12|(63&o)<<6|63&s)>2047&&(h<55296||h>57343)&&(u=h);break;case 4:o=e[i+1],s=e[i+2],a=e[i+3],128==(192&o)&&128==(192&s)&&128==(192&a)&&(h=(15&c)<<18|(63&o)<<12|(63&s)<<6|63&a)>65535&&h<1114112&&(u=h)}null===u?(u=65533,l=1):u>65535&&(u-=65536,r.push(u>>>10&1023|55296),u=56320|1023&u),r.push(u),i+=l}return function(e){var t=e.length;if(t<=w)return String.fromCharCode.apply(String,e);for(var n="",r=0;r<t;)n+=String.fromCharCode.apply(String,e.slice(r,r+=w));return n}(r)}t.kMaxLength=2147483647,e.TYPED_ARRAY_SUPPORT=function(){try{var e=new Uint8Array(1);return e.__proto__={__proto__:Uint8Array.prototype,foo:function(){return 42}},42===e.foo()}catch(t){return!1}}(),e.TYPED_ARRAY_SUPPORT||"undefined"==typeof console||"function"!=typeof console.error||console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."),Object.defineProperty(e.prototype,"parent",{enumerable:!0,get:function(){if(e.isBuffer(this))return this.buffer}}),Object.defineProperty(e.prototype,"offset",{enumerable:!0,get:function(){if(e.isBuffer(this))return this.byteOffset}}),"undefined"!=typeof Symbol&&null!=Symbol.species&&e[Symbol.species]===e&&Object.defineProperty(e,Symbol.species,{value:null,configurable:!0,enumerable:!1,writable:!1}),e.poolSize=8192,e.from=function(e,t,n){return r(e,t,n)},e.prototype.__proto__=Uint8Array.prototype,e.__proto__=Uint8Array,e.alloc=function(e,t,r){return function(e,t,r){return i(e),e<=0?n(e):void 0!==t?"string"==typeof r?n(e).fill(t,r):n(e).fill(t):n(e)}(e,t,r)},e.allocUnsafe=function(e){return o(e)},e.allocUnsafeSlow=function(e){return o(e)},e.isBuffer=function(t){return null!=t&&!0===t._isBuffer&&t!==e.prototype},e.compare=function(t,n){if(B(t,Uint8Array)&&(t=e.from(t,t.offset,t.byteLength)),B(n,Uint8Array)&&(n=e.from(n,n.offset,n.byteLength)),!e.isBuffer(t)||!e.isBuffer(n))throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');if(t===n)return 0;for(var r=t.length,i=n.length,o=0,s=Math.min(r,i);o<s;++o)if(t[o]!==n[o]){r=t[o],i=n[o];break}return r<i?-1:i<r?1:0},e.isEncoding=function(e){switch(String(e).toLowerCase()){case"hex":case"utf8":case"utf-8":case"ascii":case"latin1":case"binary":case"base64":case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return!0;default:return!1}},e.concat=function(t,n){if(!Array.isArray(t))throw new TypeError('"list" argument must be an Array of Buffers');if(0===t.length)return e.alloc(0);var r;if(void 0===n)for(n=0,r=0;r<t.length;++r)n+=t[r].length;var i=e.allocUnsafe(n),o=0;for(r=0;r<t.length;++r){var s=t[r];if(B(s,Uint8Array)&&(s=e.from(s)),!e.isBuffer(s))throw new TypeError('"list" argument must be an Array of Buffers');s.copy(i,o),o+=s.length}return i},e.byteLength=h,e.prototype._isBuffer=!0,e.prototype.swap16=function(){var e=this.length;if(e%2!=0)throw new RangeError("Buffer size must be a multiple of 16-bits");for(var t=0;t<e;t+=2)c(this,t,t+1);return this},e.prototype.swap32=function(){var e=this.length;if(e%4!=0)throw new RangeError("Buffer size must be a multiple of 32-bits");for(var t=0;t<e;t+=4)c(this,t,t+3),c(this,t+1,t+2);return this},e.prototype.swap64=function(){var e=this.length;if(e%8!=0)throw new RangeError("Buffer size must be a multiple of 64-bits");for(var t=0;t<e;t+=8)c(this,t,t+7),c(this,t+1,t+6),c(this,t+2,t+5),c(this,t+3,t+4);return this},e.prototype.toString=function(){var e=this.length;return 0===e?"":0===arguments.length?m(this,0,e):function(e,t,n){var r=!1;if((void 0===t||t<0)&&(t=0),t>this.length)return"";if((void 0===n||n>this.length)&&(n=this.length),n<=0)return"";if((n>>>=0)<=(t>>>=0))return"";for(e||(e="utf8");;)switch(e){case"hex":return S(this,t,n);case"utf8":case"utf-8":return m(this,t,n);case"ascii":return v(this,t,n);case"latin1":case"binary":return C(this,t,n);case"base64":return b(this,t,n);case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return E(this,t,n);default:if(r)throw new TypeError("Unknown encoding: "+e);e=(e+"").toLowerCase(),r=!0}}.apply(this,arguments)},e.prototype.toLocaleString=e.prototype.toString,e.prototype.equals=function(t){if(!e.isBuffer(t))throw new TypeError("Argument must be a Buffer");return this===t||0===e.compare(this,t)},e.prototype.inspect=function(){var e="",n=t.INSPECT_MAX_BYTES;return e=this.toString("hex",0,n).replace(/(.{2})/g,"$1 ").trim(),this.length>n&&(e+=" ... "),"<Buffer "+e+">"},e.prototype.compare=function(t,n,r,i,o){if(B(t,Uint8Array)&&(t=e.from(t,t.offset,t.byteLength)),!e.isBuffer(t))throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type '+typeof t);if(void 0===n&&(n=0),void 0===r&&(r=t?t.length:0),void 0===i&&(i=0),void 0===o&&(o=this.length),n<0||r>t.length||i<0||o>this.length)throw new RangeError("out of range index");if(i>=o&&n>=r)return 0;if(i>=o)return-1;if(n>=r)return 1;if(this===t)return 0;for(var s=(o>>>=0)-(i>>>=0),a=(r>>>=0)-(n>>>=0),h=Math.min(s,a),c=this.slice(i,o),u=t.slice(n,r),l=0;l<h;++l)if(c[l]!==u[l]){s=c[l],a=u[l];break}return s<a?-1:a<s?1:0},e.prototype.includes=function(e,t,n){return-1!==this.indexOf(e,t,n)},e.prototype.indexOf=function(e,t,n){return u(this,e,t,n,!0)},e.prototype.lastIndexOf=function(e,t,n){return u(this,e,t,n,!1)},e.prototype.write=function(e,t,n,r){if(void 0===t)r="utf8",n=this.length,t=0;else if(void 0===n&&"string"==typeof t)r=t,n=this.length,t=0;else{if(!isFinite(t))throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");t>>>=0,isFinite(n)?(n>>>=0,void 0===r&&(r="utf8")):(r=n,n=void 0)}var i=this.length-t;if((void 0===n||n>i)&&(n=i),e.length>0&&(n<0||t<0)||t>this.length)throw new RangeError("Attempt to write outside buffer bounds");r||(r="utf8");for(var o=!1;;)switch(r){case"hex":return f(this,e,t,n);case"utf8":case"utf-8":return d(this,e,t,n);case"ascii":return p(this,e,t,n);case"latin1":case"binary":return g(this,e,t,n);case"base64":return y(this,e,t,n);case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return _(this,e,t,n);default:if(o)throw new TypeError("Unknown encoding: "+r);r=(""+r).toLowerCase(),o=!0}},e.prototype.toJSON=function(){return{type:"Buffer",data:Array.prototype.slice.call(this._arr||this,0)}};var w=4096;function v(e,t,n){var r="";n=Math.min(e.length,n);for(var i=t;i<n;++i)r+=String.fromCharCode(127&e[i]);return r}function C(e,t,n){var r="";n=Math.min(e.length,n);for(var i=t;i<n;++i)r+=String.fromCharCode(e[i]);return r}function S(e,t,n){var r,i=e.length;(!t||t<0)&&(t=0),(!n||n<0||n>i)&&(n=i);for(var o="",s=t;s<n;++s)o+=(r=e[s])<16?"0"+r.toString(16):r.toString(16);return o}function E(e,t,n){for(var r=e.slice(t,n),i="",o=0;o<r.length;o+=2)i+=String.fromCharCode(r[o]+256*r[o+1]);return i}function k(e,t,n){if(e%1!=0||e<0)throw new RangeError("offset is not uint");if(e+t>n)throw new RangeError("Trying to access beyond buffer length")}function R(t,n,r,i,o,s){if(!e.isBuffer(t))throw new TypeError('"buffer" argument must be a Buffer instance');if(n>o||n<s)throw new RangeError('"value" argument is out of bounds');if(r+i>t.length)throw new RangeError("Index out of range")}function A(e,t,n,r,i,o){if(n+r>e.length)throw new RangeError("Index out of range");if(n<0)throw new RangeError("Index out of range")}function L(e,t,n,r,i){return t=+t,n>>>=0,i||A(e,0,n,4),P.write(e,t,n,r,23,4),n+4}function O(e,t,n,r,i){return t=+t,n>>>=0,i||A(e,0,n,8),P.write(e,t,n,r,52,8),n+8}e.prototype.slice=function(t,n){var r=this.length;(t=~~t)<0?(t+=r)<0&&(t=0):t>r&&(t=r),(n=void 0===n?r:~~n)<0?(n+=r)<0&&(n=0):n>r&&(n=r),n<t&&(n=t);var i=this.subarray(t,n);return i.__proto__=e.prototype,i},e.prototype.readUIntLE=function(e,t,n){e>>>=0,t>>>=0,n||k(e,t,this.length);for(var r=this[e],i=1,o=0;++o<t&&(i*=256);)r+=this[e+o]*i;return r},e.prototype.readUIntBE=function(e,t,n){e>>>=0,t>>>=0,n||k(e,t,this.length);for(var r=this[e+--t],i=1;t>0&&(i*=256);)r+=this[e+--t]*i;return r},e.prototype.readUInt8=function(e,t){return e>>>=0,t||k(e,1,this.length),this[e]},e.prototype.readUInt16LE=function(e,t){return e>>>=0,t||k(e,2,this.length),this[e]|this[e+1]<<8},e.prototype.readUInt16BE=function(e,t){return e>>>=0,t||k(e,2,this.length),this[e]<<8|this[e+1]},e.prototype.readUInt32LE=function(e,t){return e>>>=0,t||k(e,4,this.length),(this[e]|this[e+1]<<8|this[e+2]<<16)+16777216*this[e+3]},e.prototype.readUInt32BE=function(e,t){return e>>>=0,t||k(e,4,this.length),16777216*this[e]+(this[e+1]<<16|this[e+2]<<8|this[e+3])},e.prototype.readIntLE=function(e,t,n){e>>>=0,t>>>=0,n||k(e,t,this.length);for(var r=this[e],i=1,o=0;++o<t&&(i*=256);)r+=this[e+o]*i;return r>=(i*=128)&&(r-=Math.pow(2,8*t)),r},e.prototype.readIntBE=function(e,t,n){e>>>=0,t>>>=0,n||k(e,t,this.length);for(var r=t,i=1,o=this[e+--r];r>0&&(i*=256);)o+=this[e+--r]*i;return o>=(i*=128)&&(o-=Math.pow(2,8*t)),o},e.prototype.readInt8=function(e,t){return e>>>=0,t||k(e,1,this.length),128&this[e]?-1*(255-this[e]+1):this[e]},e.prototype.readInt16LE=function(e,t){e>>>=0,t||k(e,2,this.length);var n=this[e]|this[e+1]<<8;return 32768&n?4294901760|n:n},e.prototype.readInt16BE=function(e,t){e>>>=0,t||k(e,2,this.length);var n=this[e+1]|this[e]<<8;return 32768&n?4294901760|n:n},e.prototype.readInt32LE=function(e,t){return e>>>=0,t||k(e,4,this.length),this[e]|this[e+1]<<8|this[e+2]<<16|this[e+3]<<24},e.prototype.readInt32BE=function(e,t){return e>>>=0,t||k(e,4,this.length),this[e]<<24|this[e+1]<<16|this[e+2]<<8|this[e+3]},e.prototype.readFloatLE=function(e,t){return e>>>=0,t||k(e,4,this.length),P.read(this,e,!0,23,4)},e.prototype.readFloatBE=function(e,t){return e>>>=0,t||k(e,4,this.length),P.read(this,e,!1,23,4)},e.prototype.readDoubleLE=function(e,t){return e>>>=0,t||k(e,8,this.length),P.read(this,e,!0,52,8)},e.prototype.readDoubleBE=function(e,t){return e>>>=0,t||k(e,8,this.length),P.read(this,e,!1,52,8)},e.prototype.writeUIntLE=function(e,t,n,r){e=+e,t>>>=0,n>>>=0,r||R(this,e,t,n,Math.pow(2,8*n)-1,0);var i=1,o=0;for(this[t]=255&e;++o<n&&(i*=256);)this[t+o]=e/i&255;return t+n},e.prototype.writeUIntBE=function(e,t,n,r){e=+e,t>>>=0,n>>>=0,r||R(this,e,t,n,Math.pow(2,8*n)-1,0);var i=n-1,o=1;for(this[t+i]=255&e;--i>=0&&(o*=256);)this[t+i]=e/o&255;return t+n},e.prototype.writeUInt8=function(e,t,n){return e=+e,t>>>=0,n||R(this,e,t,1,255,0),this[t]=255&e,t+1},e.prototype.writeUInt16LE=function(e,t,n){return e=+e,t>>>=0,n||R(this,e,t,2,65535,0),this[t]=255&e,this[t+1]=e>>>8,t+2},e.prototype.writeUInt16BE=function(e,t,n){return e=+e,t>>>=0,n||R(this,e,t,2,65535,0),this[t]=e>>>8,this[t+1]=255&e,t+2},e.prototype.writeUInt32LE=function(e,t,n){return e=+e,t>>>=0,n||R(this,e,t,4,4294967295,0),this[t+3]=e>>>24,this[t+2]=e>>>16,this[t+1]=e>>>8,this[t]=255&e,t+4},e.prototype.writeUInt32BE=function(e,t,n){return e=+e,t>>>=0,n||R(this,e,t,4,4294967295,0),this[t]=e>>>24,this[t+1]=e>>>16,this[t+2]=e>>>8,this[t+3]=255&e,t+4},e.prototype.writeIntLE=function(e,t,n,r){if(e=+e,t>>>=0,!r){var i=Math.pow(2,8*n-1);R(this,e,t,n,i-1,-i)}var o=0,s=1,a=0;for(this[t]=255&e;++o<n&&(s*=256);)e<0&&0===a&&0!==this[t+o-1]&&(a=1),this[t+o]=(e/s>>0)-a&255;return t+n},e.prototype.writeIntBE=function(e,t,n,r){if(e=+e,t>>>=0,!r){var i=Math.pow(2,8*n-1);R(this,e,t,n,i-1,-i)}var o=n-1,s=1,a=0;for(this[t+o]=255&e;--o>=0&&(s*=256);)e<0&&0===a&&0!==this[t+o+1]&&(a=1),this[t+o]=(e/s>>0)-a&255;return t+n},e.prototype.writeInt8=function(e,t,n){return e=+e,t>>>=0,n||R(this,e,t,1,127,-128),e<0&&(e=255+e+1),this[t]=255&e,t+1},e.prototype.writeInt16LE=function(e,t,n){return e=+e,t>>>=0,n||R(this,e,t,2,32767,-32768),this[t]=255&e,this[t+1]=e>>>8,t+2},e.prototype.writeInt16BE=function(e,t,n){return e=+e,t>>>=0,n||R(this,e,t,2,32767,-32768),this[t]=e>>>8,this[t+1]=255&e,t+2},e.prototype.writeInt32LE=function(e,t,n){return e=+e,t>>>=0,n||R(this,e,t,4,2147483647,-2147483648),this[t]=255&e,this[t+1]=e>>>8,this[t+2]=e>>>16,this[t+3]=e>>>24,t+4},e.prototype.writeInt32BE=function(e,t,n){return e=+e,t>>>=0,n||R(this,e,t,4,2147483647,-2147483648),e<0&&(e=4294967295+e+1),this[t]=e>>>24,this[t+1]=e>>>16,this[t+2]=e>>>8,this[t+3]=255&e,t+4},e.prototype.writeFloatLE=function(e,t,n){return L(this,e,t,!0,n)},e.prototype.writeFloatBE=function(e,t,n){return L(this,e,t,!1,n)},e.prototype.writeDoubleLE=function(e,t,n){return O(this,e,t,!0,n)},e.prototype.writeDoubleBE=function(e,t,n){return O(this,e,t,!1,n)},e.prototype.copy=function(t,n,r,i){if(!e.isBuffer(t))throw new TypeError("argument should be a Buffer");if(r||(r=0),i||0===i||(i=this.length),n>=t.length&&(n=t.length),n||(n=0),i>0&&i<r&&(i=r),i===r)return 0;if(0===t.length||0===this.length)return 0;if(n<0)throw new RangeError("targetStart out of bounds");if(r<0||r>=this.length)throw new RangeError("Index out of range");if(i<0)throw new RangeError("sourceEnd out of bounds");i>this.length&&(i=this.length),t.length-n<i-r&&(i=t.length-n+r);var o=i-r;if(this===t&&"function"==typeof Uint8Array.prototype.copyWithin)this.copyWithin(n,r,i);else if(this===t&&r<n&&n<i)for(var s=o-1;s>=0;--s)t[s+n]=this[s+r];else Uint8Array.prototype.set.call(t,this.subarray(r,i),n);return o},e.prototype.fill=function(t,n,r,i){if("string"==typeof t){if("string"==typeof n?(i=n,n=0,r=this.length):"string"==typeof r&&(i=r,r=this.length),void 0!==i&&"string"!=typeof i)throw new TypeError("encoding must be a string");if("string"==typeof i&&!e.isEncoding(i))throw new TypeError("Unknown encoding: "+i);if(1===t.length){var o=t.charCodeAt(0);("utf8"===i&&o<128||"latin1"===i)&&(t=o)}}else"number"==typeof t&&(t&=255);if(n<0||this.length<n||this.length<r)throw new RangeError("Out of range index");if(r<=n)return this;var s;if(n>>>=0,r=void 0===r?this.length:r>>>0,t||(t=0),"number"==typeof t)for(s=n;s<r;++s)this[s]=t;else{var a=e.isBuffer(t)?t:e.from(t,i),h=a.length;if(0===h)throw new TypeError('The value "'+t+'" is invalid for argument "value"');for(s=0;s<r-n;++s)this[s+n]=a[s%h]}return this};var x=/[^+/0-9A-Za-z-_]/g;function M(e,t){var n;t=t||1/0;for(var r=e.length,i=null,o=[],s=0;s<r;++s){if((n=e.charCodeAt(s))>55295&&n<57344){if(!i){if(n>56319){(t-=3)>-1&&o.push(239,191,189);continue}if(s+1===r){(t-=3)>-1&&o.push(239,191,189);continue}i=n;continue}if(n<56320){(t-=3)>-1&&o.push(239,191,189),i=n;continue}n=65536+(i-55296<<10|n-56320)}else i&&(t-=3)>-1&&o.push(239,191,189);if(i=null,n<128){if((t-=1)<0)break;o.push(n)}else if(n<2048){if((t-=2)<0)break;o.push(n>>6|192,63&n|128)}else if(n<65536){if((t-=3)<0)break;o.push(n>>12|224,n>>6&63|128,63&n|128)}else{if(!(n<1114112))throw new Error("Invalid code point");if((t-=4)<0)break;o.push(n>>18|240,n>>12&63|128,n>>6&63|128,63&n|128)}}return o}function N(e){return T.toByteArray(function(e){if((e=(e=e.split("=")[0]).trim().replace(x,"")).length<2)return"";for(;e.length%4!=0;)e+="=";return e}(e))}function I(e,t,n,r){for(var i=0;i<r&&!(i+n>=t.length||i>=e.length);++i)t[i+n]=e[i];return i}function B(e,t){return e instanceof t||null!=e&&null!=e.constructor&&null!=e.constructor.name&&e.constructor.name===t.name}function D(e){return e!=e}}).call(this,u({}).Buffer)})),l=n((function(e,t){var n=1e3,r=6e4,i=60*r,o=24*i;function s(e,t,n,r){var i=t>=1.5*n;return Math.round(e/n)+" "+r+(i?"s":"")}e.exports=function(e,t){t=t||{};var a,h,c=typeof e;if("string"===c&&e.length>0)return function(e){if(!((e=String(e)).length>100)){var t=/^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(e);if(t){var s=parseFloat(t[1]);switch((t[2]||"ms").toLowerCase()){case"years":case"year":case"yrs":case"yr":case"y":return 315576e5*s;case"weeks":case"week":case"w":return 6048e5*s;case"days":case"day":case"d":return s*o;case"hours":case"hour":case"hrs":case"hr":case"h":return s*i;case"minutes":case"minute":case"mins":case"min":case"m":return s*r;case"seconds":case"second":case"secs":case"sec":case"s":return s*n;case"milliseconds":case"millisecond":case"msecs":case"msec":case"ms":return s;default:return}}}}(e);if("number"===c&&isFinite(e))return t.long?(a=e,(h=Math.abs(a))>=o?s(a,h,o,"day"):h>=i?s(a,h,i,"hour"):h>=r?s(a,h,r,"minute"):h>=n?s(a,h,n,"second"):a+" ms"):function(e){var t=Math.abs(e);return t>=o?Math.round(e/o)+"d":t>=i?Math.round(e/i)+"h":t>=r?Math.round(e/r)+"m":t>=n?Math.round(e/n)+"s":e+"ms"}(e);throw new Error("val is not a non-empty string or a valid number. val="+JSON.stringify(e))}})),f={},d=f={};function p(){throw new Error("setTimeout has not been defined")}function g(){throw new Error("clearTimeout has not been defined")}function y(t){if(e===setTimeout)return setTimeout(t,0);if((e===p||!e)&&setTimeout)return e=setTimeout,setTimeout(t,0);try{return e(t,0)}catch(n){try{return e.call(null,t,0)}catch(n){return e.call(this,t,0)}}}!function(){try{e="function"==typeof setTimeout?setTimeout:p}catch(n){e=p}try{t="function"==typeof clearTimeout?clearTimeout:g}catch(n){t=g}}();var _,b=[],m=!1,w=-1;function v(){m&&_&&(m=!1,_.length?b=_.concat(b):w=-1,b.length&&C())}function C(){if(!m){var e=y(v);m=!0;for(var n=b.length;n;){for(_=b,b=[];++w<n;)_&&_[w].run();w=-1,n=b.length}_=null,m=!1,function(e){if(t===clearTimeout)return clearTimeout(e);if((t===g||!t)&&clearTimeout)return t=clearTimeout,clearTimeout(e);try{t(e)}catch(n){try{return t.call(null,e)}catch(n){return t.call(this,e)}}}(e)}}function S(e,t){this.fun=e,this.array=t}function E(){}d.nextTick=function(e){var t=new Array(arguments.length-1);if(arguments.length>1)for(var n=1;n<arguments.length;n++)t[n-1]=arguments[n];b.push(new S(e,t)),1!==b.length||m||y(C)},S.prototype.run=function(){this.fun.apply(null,this.array)},d.title="browser",d.browser=!0,d.env={},d.argv=[],d.version="",d.versions={},d.on=E,d.addListener=E,d.once=E,d.off=E,d.removeListener=E,d.removeAllListeners=E,d.emit=E,d.prependListener=E,d.prependOnceListener=E,d.listeners=function(e){return[]},d.binding=function(e){throw new Error("process.binding is not supported")},d.cwd=function(){return"/"},d.chdir=function(e){throw new Error("process.chdir is not supported")},d.umask=function(){return 0};var k={};(function(e){k.log=function(...e){return"object"==typeof console&&console.log&&console.log(...e)},k.formatArgs=function(e){if(e[0]=(this.useColors?"%c":"")+this.namespace+(this.useColors?" %c":" ")+e[0]+(this.useColors?"%c ":" ")+"+"+k.humanize(this.diff),!this.useColors)return;const t="color: "+this.color;e.splice(1,0,t,"color: inherit");let n=0,r=0;e[0].replace(/%[a-zA-Z%]/g,e=>{"%%"!==e&&(n++,"%c"===e&&(r=n))}),e.splice(r,0,t)},k.save=function(e){try{e?k.storage.setItem("debug",e):k.storage.removeItem("debug")}catch(t){}},k.load=function(){let t;try{t=k.storage.getItem("debug")}catch(n){}return!t&&void 0!==e&&"env"in e&&(t=e.env.DEBUG),t},k.useColors=function(){return!("undefined"==typeof window||!window.process||"renderer"!==window.process.type&&!window.process.__nwjs)||("undefined"==typeof navigator||!navigator.userAgent||!navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/))&&("undefined"!=typeof document&&document.documentElement&&document.documentElement.style&&document.documentElement.style.WebkitAppearance||"undefined"!=typeof window&&window.console&&(window.console.firebug||window.console.exception&&window.console.table)||"undefined"!=typeof navigator&&navigator.userAgent&&navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)&&parseInt(RegExp.$1,10)>=31||"undefined"!=typeof navigator&&navigator.userAgent&&navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/))},k.storage=function(){try{return localStorage}catch(e){}}(),k.colors=["#0000CC","#0000FF","#0033CC","#0033FF","#0066CC","#0066FF","#0099CC","#0099FF","#00CC00","#00CC33","#00CC66","#00CC99","#00CCCC","#00CCFF","#3300CC","#3300FF","#3333CC","#3333FF","#3366CC","#3366FF","#3399CC","#3399FF","#33CC00","#33CC33","#33CC66","#33CC99","#33CCCC","#33CCFF","#6600CC","#6600FF","#6633CC","#6633FF","#66CC00","#66CC33","#9900CC","#9900FF","#9933CC","#9933FF","#99CC00","#99CC33","#CC0000","#CC0033","#CC0066","#CC0099","#CC00CC","#CC00FF","#CC3300","#CC3333","#CC3366","#CC3399","#CC33CC","#CC33FF","#CC6600","#CC6633","#CC9900","#CC9933","#CCCC00","#CCCC33","#FF0000","#FF0033","#FF0066","#FF0099","#FF00CC","#FF00FF","#FF3300","#FF3333","#FF3366","#FF3399","#FF33CC","#FF33FF","#FF6600","#FF6633","#FF9900","#FF9933","#FFCC00","#FFCC33"],k=function(e){function t(e){let t=0;for(let n=0;n<e.length;n++)t=(t<<5)-t+e.charCodeAt(n),t|=0;return n.colors[Math.abs(t)%n.colors.length]}function n(e){let o;function s(...e){if(!s.enabled)return;const t=s,r=Number(new Date),i=r-(o||r);t.diff=i,t.prev=o,t.curr=r,o=r,e[0]=n.coerce(e[0]),"string"!=typeof e[0]&&e.unshift("%O");let a=0;e[0]=e[0].replace(/%([a-zA-Z%])/g,(r,i)=>{if("%%"===r)return r;a++;const o=n.formatters[i];if("function"==typeof o){const n=e[a];r=o.call(t,n),e.splice(a,1),a--}return r}),n.formatArgs.call(t,e),(t.log||n.log).apply(t,e)}return s.namespace=e,s.enabled=n.enabled(e),s.useColors=n.useColors(),s.color=t(e),s.destroy=r,s.extend=i,"function"==typeof n.init&&n.init(s),n.instances.push(s),s}function r(){const e=n.instances.indexOf(this);return-1!==e&&(n.instances.splice(e,1),!0)}function i(e,t){const r=n(this.namespace+(void 0===t?":":t)+e);return r.log=this.log,r}function o(e){return e.toString().substring(2,e.toString().length-2).replace(/\.\*\?$/,"*")}return n.debug=n,n.default=n,n.coerce=function(e){return e instanceof Error?e.stack||e.message:e},n.disable=function(){const e=[...n.names.map(o),...n.skips.map(o).map(e=>"-"+e)].join(",");return n.enable(""),e},n.enable=function(e){let t;n.save(e),n.names=[],n.skips=[];const r=("string"==typeof e?e:"").split(/[\s,]+/),i=r.length;for(t=0;t<i;t++)r[t]&&("-"===(e=r[t].replace(/\*/g,".*?"))[0]?n.skips.push(new RegExp("^"+e.substr(1)+"$")):n.names.push(new RegExp("^"+e+"$")));for(t=0;t<n.instances.length;t++){const e=n.instances[t];e.enabled=n.enabled(e.namespace)}},n.enabled=function(e){if("*"===e[e.length-1])return!0;let t,r;for(t=0,r=n.skips.length;t<r;t++)if(n.skips[t].test(e))return!1;for(t=0,r=n.names.length;t<r;t++)if(n.names[t].test(e))return!0;return!1},n.humanize=l({}),Object.keys(e).forEach(t=>{n[t]=e[t]}),n.instances=[],n.names=[],n.skips=[],n.formatters={},n.selectColor=t,n.enable(n.load()),n}(k);const{formatters:t}=k;t.j=function(e){try{return JSON.stringify(e)}catch(t){return"[UnexpectedJSONParseError]: "+t.message}}}).call(this,f);for(var R=function(){if("undefined"==typeof window)return null;var e={RTCPeerConnection:window.RTCPeerConnection||window.mozRTCPeerConnection||window.webkitRTCPeerConnection,RTCSessionDescription:window.RTCSessionDescription||window.mozRTCSessionDescription||window.webkitRTCSessionDescription,RTCIceCandidate:window.RTCIceCandidate||window.mozRTCIceCandidate||window.webkitRTCIceCandidate};return e.RTCPeerConnection?e:null},T={toByteArray:function(e){var t,n,r=I(e),i=r[0],o=r[1],s=new O(function(e,t,n){return 3*(t+n)/4-n}(0,i,o)),a=0,h=o>0?i-4:i;for(n=0;n<h;n+=4)t=L[e.charCodeAt(n)]<<18|L[e.charCodeAt(n+1)]<<12|L[e.charCodeAt(n+2)]<<6|L[e.charCodeAt(n+3)],s[a++]=t>>16&255,s[a++]=t>>8&255,s[a++]=255&t;return 2===o&&(t=L[e.charCodeAt(n)]<<2|L[e.charCodeAt(n+1)]>>4,s[a++]=255&t),1===o&&(t=L[e.charCodeAt(n)]<<10|L[e.charCodeAt(n+1)]<<4|L[e.charCodeAt(n+2)]>>2,s[a++]=t>>8&255,s[a++]=255&t),s},fromByteArray:function(e){for(var t,n=e.length,r=n%3,i=[],o=0,s=n-r;o<s;o+=16383)i.push(B(e,o,o+16383>s?s:o+16383));return 1===r?(t=e[n-1],i.push(A[t>>2]+A[t<<4&63]+"==")):2===r&&(t=(e[n-2]<<8)+e[n-1],i.push(A[t>>10]+A[t>>4&63]+A[t<<2&63]+"=")),i.join("")}},A=[],L=[],O="undefined"!=typeof Uint8Array?Uint8Array:Array,x="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",M=0,N=x.length;M<N;++M)A[M]=x[M],L[x.charCodeAt(M)]=M;function I(e){var t=e.length;if(t%4>0)throw new Error("Invalid string. Length must be a multiple of 4");var n=e.indexOf("=");return-1===n&&(n=t),[n,n===t?0:4-n%4]}function B(e,t,n){for(var r,i,o=[],s=t;s<n;s+=3)r=(e[s]<<16&16711680)+(e[s+1]<<8&65280)+(255&e[s+2]),o.push(A[(i=r)>>18&63]+A[i>>12&63]+A[i>>6&63]+A[63&i]);return o.join("")}L["-".charCodeAt(0)]=62,L["_".charCodeAt(0)]=63;var P={read:function(e,t,n,r,i){var o,s,a=8*i-r-1,h=(1<<a)-1,c=h>>1,u=-7,l=n?i-1:0,f=n?-1:1,d=e[t+l];for(l+=f,o=d&(1<<-u)-1,d>>=-u,u+=a;u>0;o=256*o+e[t+l],l+=f,u-=8);for(s=o&(1<<-u)-1,o>>=-u,u+=r;u>0;s=256*s+e[t+l],l+=f,u-=8);if(0===o)o=1-c;else{if(o===h)return s?NaN:1/0*(d?-1:1);s+=Math.pow(2,r),o-=c}return(d?-1:1)*s*Math.pow(2,o-r)},write:function(e,t,n,r,i,o){var s,a,h,c=8*o-i-1,u=(1<<c)-1,l=u>>1,f=23===i?Math.pow(2,-24)-Math.pow(2,-77):0,d=r?0:o-1,p=r?1:-1,g=t<0||0===t&&1/t<0?1:0;for(t=Math.abs(t),isNaN(t)||t===1/0?(a=isNaN(t)?1:0,s=u):(s=Math.floor(Math.log(t)/Math.LN2),t*(h=Math.pow(2,-s))<1&&(s--,h*=2),(t+=s+l>=1?f/h:f*Math.pow(2,1-l))*h>=2&&(s++,h/=2),s+l>=u?(a=0,s=u):s+l>=1?(a=(t*h-1)*Math.pow(2,i),s+=l):(a=t*Math.pow(2,l-1)*Math.pow(2,i),s=0));i>=8;e[n+d]=255&a,d+=p,a/=256,i-=8);for(s=s<<i|a,c+=i;c>0;e[n+d]=255&s,d+=p,s/=256,c-=8);e[n+d-p]|=128*g}},D={},U=u({}),F=U.Buffer;function j(e,t){for(var n in e)t[n]=e[n]}function W(e,t,n){return F(e,t,n)}F.from&&F.alloc&&F.allocUnsafe&&F.allocUnsafeSlow?D=U:(j(U,D),D.Buffer=W),W.prototype=Object.create(F.prototype),j(F,W),W.from=function(e,t,n){if("number"==typeof e)throw new TypeError("Argument must not be a number");return F(e,t,n)},W.alloc=function(e,t,n){if("number"!=typeof e)throw new TypeError("Argument must be a number");var r=F(e);return void 0!==t?"string"==typeof n?r.fill(t,n):r.fill(t):r.fill(0),r},W.allocUnsafe=function(e){if("number"!=typeof e)throw new TypeError("Argument must be a number");return F(e)},W.allocUnsafeSlow=function(e){if("number"!=typeof e)throw new TypeError("Argument must be a number");return U.SlowBuffer(e)};var H={};(function(e,t){"use strict";var n=D.Buffer,r=t.crypto||t.msCrypto;H=r&&r.getRandomValues?function(t,i){if(t>4294967295)throw new RangeError("requested too many random bytes");var o=n.allocUnsafe(t);if(t>0)if(t>65536)for(var s=0;s<t;s+=65536)r.getRandomValues(o.slice(s,s+65536));else r.getRandomValues(o);return"function"==typeof i?e.nextTick((function(){i(null,o)})):o}:function(){throw new Error("Secure random number generation is not supported by this browser.\nUse Chrome, Firefox or Internet Explorer 11")}}).call(this,f,"undefined"!=typeof global?global:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{});var q={},z=Object.create||function(e){var t=function(){};return t.prototype=e,new t},V=Object.keys||function(e){var t=[];for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&t.push(n);return n},G=Function.prototype.bind||function(e){var t=this;return function(){return t.apply(e,arguments)}};function Y(){this._events&&Object.prototype.hasOwnProperty.call(this,"_events")||(this._events=z(null),this._eventsCount=0),this._maxListeners=this._maxListeners||void 0}q=Y,Y.EventEmitter=Y,Y.prototype._events=void 0,Y.prototype._maxListeners=void 0;var J,K=10;try{var $={};Object.defineProperty&&Object.defineProperty($,"x",{value:0}),J=0===$.x}catch(dt){J=!1}function X(e){return void 0===e._maxListeners?Y.defaultMaxListeners:e._maxListeners}function Z(e,t,n,r){var i,o,s;if("function"!=typeof n)throw new TypeError('"listener" argument must be a function');if((o=e._events)?(o.newListener&&(e.emit("newListener",t,n.listener?n.listener:n),o=e._events),s=o[t]):(o=e._events=z(null),e._eventsCount=0),s){if("function"==typeof s?s=o[t]=r?[n,s]:[s,n]:r?s.unshift(n):s.push(n),!s.warned&&(i=X(e))&&i>0&&s.length>i){s.warned=!0;var a=new Error("Possible EventEmitter memory leak detected. "+s.length+' "'+String(t)+'" listeners added. Use emitter.setMaxListeners() to increase limit.');a.name="MaxListenersExceededWarning",a.emitter=e,a.type=t,a.count=s.length,"object"==typeof console&&console.warn&&console.warn("%s: %s",a.name,a.message)}}else s=o[t]=n,++e._eventsCount;return e}function Q(){if(!this.fired)switch(this.target.removeListener(this.type,this.wrapFn),this.fired=!0,arguments.length){case 0:return this.listener.call(this.target);case 1:return this.listener.call(this.target,arguments[0]);case 2:return this.listener.call(this.target,arguments[0],arguments[1]);case 3:return this.listener.call(this.target,arguments[0],arguments[1],arguments[2]);default:for(var e=new Array(arguments.length),t=0;t<e.length;++t)e[t]=arguments[t];this.listener.apply(this.target,e)}}function ee(e,t,n){var r={fired:!1,wrapFn:void 0,target:e,type:t,listener:n},i=G.call(Q,r);return i.listener=n,r.wrapFn=i,i}function te(e,t,n){var r=e._events;if(!r)return[];var i=r[t];return i?"function"==typeof i?n?[i.listener||i]:[i]:n?function(e){for(var t=new Array(e.length),n=0;n<t.length;++n)t[n]=e[n].listener||e[n];return t}(i):re(i,i.length):[]}function ne(e){var t=this._events;if(t){var n=t[e];if("function"==typeof n)return 1;if(n)return n.length}return 0}function re(e,t){for(var n=new Array(t),r=0;r<t;++r)n[r]=e[r];return n}J?Object.defineProperty(Y,"defaultMaxListeners",{enumerable:!0,get:function(){return K},set:function(e){if("number"!=typeof e||e<0||e!=e)throw new TypeError('"defaultMaxListeners" must be a positive number');K=e}}):Y.defaultMaxListeners=K,Y.prototype.setMaxListeners=function(e){if("number"!=typeof e||e<0||isNaN(e))throw new TypeError('"n" argument must be a positive number');return this._maxListeners=e,this},Y.prototype.getMaxListeners=function(){return X(this)},Y.prototype.emit=function(e){var t,n,r,i,o,s,a="error"===e;if(s=this._events)a=a&&null==s.error;else if(!a)return!1;if(a){if(arguments.length>1&&(t=arguments[1]),t instanceof Error)throw t;var h=new Error('Unhandled "error" event. ('+t+")");throw h.context=t,h}if(!(n=s[e]))return!1;var c="function"==typeof n;switch(r=arguments.length){case 1:!function(e,t,n){if(t)e.call(n);else for(var r=e.length,i=re(e,r),o=0;o<r;++o)i[o].call(n)}(n,c,this);break;case 2:!function(e,t,n,r){if(t)e.call(n,r);else for(var i=e.length,o=re(e,i),s=0;s<i;++s)o[s].call(n,r)}(n,c,this,arguments[1]);break;case 3:!function(e,t,n,r,i){if(t)e.call(n,r,i);else for(var o=e.length,s=re(e,o),a=0;a<o;++a)s[a].call(n,r,i)}(n,c,this,arguments[1],arguments[2]);break;case 4:!function(e,t,n,r,i,o){if(t)e.call(n,r,i,o);else for(var s=e.length,a=re(e,s),h=0;h<s;++h)a[h].call(n,r,i,o)}(n,c,this,arguments[1],arguments[2],arguments[3]);break;default:for(i=new Array(r-1),o=1;o<r;o++)i[o-1]=arguments[o];!function(e,t,n,r){if(t)e.apply(n,r);else for(var i=e.length,o=re(e,i),s=0;s<i;++s)o[s].apply(n,r)}(n,c,this,i)}return!0},Y.prototype.addListener=function(e,t){return Z(this,e,t,!1)},Y.prototype.on=Y.prototype.addListener,Y.prototype.prependListener=function(e,t){return Z(this,e,t,!0)},Y.prototype.once=function(e,t){if("function"!=typeof t)throw new TypeError('"listener" argument must be a function');return this.on(e,ee(this,e,t)),this},Y.prototype.prependOnceListener=function(e,t){if("function"!=typeof t)throw new TypeError('"listener" argument must be a function');return this.prependListener(e,ee(this,e,t)),this},Y.prototype.removeListener=function(e,t){var n,r,i,o,s;if("function"!=typeof t)throw new TypeError('"listener" argument must be a function');if(!(r=this._events))return this;if(!(n=r[e]))return this;if(n===t||n.listener===t)0==--this._eventsCount?this._events=z(null):(delete r[e],r.removeListener&&this.emit("removeListener",e,n.listener||t));else if("function"!=typeof n){for(i=-1,o=n.length-1;o>=0;o--)if(n[o]===t||n[o].listener===t){s=n[o].listener,i=o;break}if(i<0)return this;0===i?n.shift():function(e,t){for(var n=t,r=n+1,i=e.length;r<i;n+=1,r+=1)e[n]=e[r];e.pop()}(n,i),1===n.length&&(r[e]=n[0]),r.removeListener&&this.emit("removeListener",e,s||t)}return this},Y.prototype.removeAllListeners=function(e){var t,n,r;if(!(n=this._events))return this;if(!n.removeListener)return 0===arguments.length?(this._events=z(null),this._eventsCount=0):n[e]&&(0==--this._eventsCount?this._events=z(null):delete n[e]),this;if(0===arguments.length){var i,o=V(n);for(r=0;r<o.length;++r)"removeListener"!==(i=o[r])&&this.removeAllListeners(i);return this.removeAllListeners("removeListener"),this._events=z(null),this._eventsCount=0,this}if("function"==typeof(t=n[e]))this.removeListener(e,t);else if(t)for(r=t.length-1;r>=0;r--)this.removeListener(e,t[r]);return this},Y.prototype.listeners=function(e){return te(this,e,!0)},Y.prototype.rawListeners=function(e){return te(this,e,!1)},Y.listenerCount=function(e,t){return"function"==typeof e.listenerCount?e.listenerCount(t):ne.call(e,t)},Y.prototype.listenerCount=ne,Y.prototype.eventNames=function(){return this._eventsCount>0?Reflect.ownKeys(this._events):[]};var ie=q.EventEmitter,oe={};function se(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function ae(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function he(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}var ce=u({}).Buffer,ue=oe.inspect,le=ue&&ue.custom||"inspect",fe=function(){function e(){!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e),this.head=null,this.tail=null,this.length=0}var t,n;return t=e,(n=[{key:"push",value:function(e){var t={data:e,next:null};this.length>0?this.tail.next=t:this.head=t,this.tail=t,++this.length}},{key:"unshift",value:function(e){var t={data:e,next:this.head};0===this.length&&(this.tail=t),this.head=t,++this.length}},{key:"shift",value:function(){if(0!==this.length){var e=this.head.data;return 1===this.length?this.head=this.tail=null:this.head=this.head.next,--this.length,e}}},{key:"clear",value:function(){this.head=this.tail=null,this.length=0}},{key:"join",value:function(e){if(0===this.length)return"";for(var t=this.head,n=""+t.data;t=t.next;)n+=e+t.data;return n}},{key:"concat",value:function(e){if(0===this.length)return ce.alloc(0);for(var t,n,r,i=ce.allocUnsafe(e>>>0),o=this.head,s=0;o;)t=o.data,n=i,r=s,ce.prototype.copy.call(t,n,r),s+=o.data.length,o=o.next;return i}},{key:"consume",value:function(e,t){var n;return e<this.head.data.length?(n=this.head.data.slice(0,e),this.head.data=this.head.data.slice(e)):n=e===this.head.data.length?this.shift():t?this._getString(e):this._getBuffer(e),n}},{key:"first",value:function(){return this.head.data}},{key:"_getString",value:function(e){var t=this.head,n=1,r=t.data;for(e-=r.length;t=t.next;){var i=t.data,o=e>i.length?i.length:e;if(o===i.length?r+=i:r+=i.slice(0,e),0==(e-=o)){o===i.length?(++n,t.next?this.head=t.next:this.head=this.tail=null):(this.head=t,t.data=i.slice(o));break}++n}return this.length-=n,r}},{key:"_getBuffer",value:function(e){var t=ce.allocUnsafe(e),n=this.head,r=1;for(n.data.copy(t),e-=n.data.length;n=n.next;){var i=n.data,o=e>i.length?i.length:e;if(i.copy(t,t.length-e,0,o),0==(e-=o)){o===i.length?(++r,n.next?this.head=n.next:this.head=this.tail=null):(this.head=n,n.data=i.slice(o));break}++r}return this.length-=r,t}},{key:le,value:function(e,t){return ue(this,function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?se(Object(n),!0).forEach((function(t){ae(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):se(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}({},t,{depth:0,customInspect:!1}))}}])&&he(t.prototype,n),e}(),de={};(function(e){"use strict";function t(e,t){r(e,t),n(e)}function n(e){e._writableState&&!e._writableState.emitClose||e._readableState&&!e._readableState.emitClose||e.emit("close")}function r(e,t){e.emit("error",t)}de={destroy:function(i,o){var s=this,a=this._readableState&&this._readableState.destroyed,h=this._writableState&&this._writableState.destroyed;return a||h?(o?o(i):i&&(this._writableState?this._writableState.errorEmitted||(this._writableState.errorEmitted=!0,e.nextTick(r,this,i)):e.nextTick(r,this,i)),this):(this._readableState&&(this._readableState.destroyed=!0),this._writableState&&(this._writableState.destroyed=!0),this._destroy(i||null,(function(r){!o&&r?s._writableState?s._writableState.errorEmitted?e.nextTick(n,s):(s._writableState.errorEmitted=!0,e.nextTick(t,s,r)):e.nextTick(t,s,r):o?(e.nextTick(n,s),o(r)):e.nextTick(n,s)})),this)},undestroy:function(){this._readableState&&(this._readableState.destroyed=!1,this._readableState.reading=!1,this._readableState.ended=!1,this._readableState.endEmitted=!1),this._writableState&&(this._writableState.destroyed=!1,this._writableState.ended=!1,this._writableState.ending=!1,this._writableState.finalCalled=!1,this._writableState.prefinished=!1,this._writableState.finished=!1,this._writableState.errorEmitted=!1)},errorOrDestroy:function(e,t){var n=e._readableState,r=e._writableState;n&&n.autoDestroy||r&&r.autoDestroy?e.destroy(t):e.emit("error",t)}}}).call(this,f);var pe={},ge={};function ye(e,t,n){n||(n=Error);var r=function(e){var n,r;function i(n,r,i){return e.call(this,function(e,n,r){return"string"==typeof t?t:t(e,n,r)}(n,r,i))||this}return r=e,(n=i).prototype=Object.create(r.prototype),n.prototype.constructor=n,n.__proto__=r,i}(n);r.prototype.name=n.name,r.prototype.code=e,ge[e]=r}function _e(e,t){if(Array.isArray(e)){var n=e.length;return e=e.map((function(e){return String(e)})),n>2?"one of ".concat(t," ").concat(e.slice(0,n-1).join(", "),", or ")+e[n-1]:2===n?"one of ".concat(t," ").concat(e[0]," or ").concat(e[1]):"of ".concat(t," ").concat(e[0])}return"of ".concat(t," ").concat(String(e))}ye("ERR_INVALID_OPT_VALUE",(function(e,t){return'The value "'+t+'" is invalid for option "'+e+'"'}),TypeError),ye("ERR_INVALID_ARG_TYPE",(function(e,t,n){var r,i,o,s;if("string"==typeof t&&("not ","not "===t.substr(0,"not ".length))?(r="must not be",t=t.replace(/^not /,"")):r="must be",o=e,(void 0===s||s>o.length)&&(s=o.length)," argument"===o.substring(s-" argument".length,s))i="The ".concat(e," ").concat(r," ").concat(_e(t,"type"));else{var a=function(e,t,n){return"number"!=typeof n&&(n=0),!(n+".".length>e.length)&&-1!==e.indexOf(".",n)}(e)?"property":"argument";i='The "'.concat(e,'" ').concat(a," ").concat(r," ").concat(_e(t,"type"))}return i+". Received type ".concat(typeof n)}),TypeError),ye("ERR_STREAM_PUSH_AFTER_EOF","stream.push() after EOF"),ye("ERR_METHOD_NOT_IMPLEMENTED",(function(e){return"The "+e+" method is not implemented"})),ye("ERR_STREAM_PREMATURE_CLOSE","Premature close"),ye("ERR_STREAM_DESTROYED",(function(e){return"Cannot call "+e+" after a stream was destroyed"})),ye("ERR_MULTIPLE_CALLBACK","Callback called multiple times"),ye("ERR_STREAM_CANNOT_PIPE","Cannot pipe, not readable"),ye("ERR_STREAM_WRITE_AFTER_END","write after end"),ye("ERR_STREAM_NULL_VALUES","May not write null values to stream",TypeError),ye("ERR_UNKNOWN_ENCODING",(function(e){return"Unknown encoding: "+e}),TypeError),ye("ERR_STREAM_UNSHIFT_AFTER_END_EVENT","stream.unshift() after end event"),pe.codes=ge;var be=pe.codes.ERR_INVALID_OPT_VALUE,me={getHighWaterMark:function(e,t,n,r){var i=function(e,t,n){return null!=e.highWaterMark?e.highWaterMark:t?e[n]:null}(t,r,n);if(null!=i){if(!isFinite(i)||Math.floor(i)!==i||i<0)throw new be(r?n:"highWaterMark",i);return Math.floor(i)}return e.objectMode?16:16384}},we={};we="function"==typeof Object.create?function(e,t){t&&(e.super_=t,e.prototype=Object.create(t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}))}:function(e,t){if(t){e.super_=t;var n=function(){};n.prototype=t.prototype,e.prototype=new n,e.prototype.constructor=e}};var ve={};(function(e){function t(t){try{if(!e.localStorage)return!1}catch(r){return!1}var n=e.localStorage[t];return null!=n&&"true"===String(n).toLowerCase()}ve=function(e,n){if(t("noDeprecation"))return e;var r=!1;return function(){if(!r){if(t("throwDeprecation"))throw new Error(n);t("traceDeprecation")?console.trace(n):console.warn(n),r=!0}return e.apply(this,arguments)}}}).call(this,"undefined"!=typeof global?global:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{});var Ce=Oe,Se=pe.codes,Ee=Se.ERR_METHOD_NOT_IMPLEMENTED,ke=Se.ERR_MULTIPLE_CALLBACK,Re=Se.ERR_TRANSFORM_ALREADY_TRANSFORMING,Te=Se.ERR_TRANSFORM_WITH_LENGTH_0,Ae=h({});function Le(e,t){var n=this._transformState;n.transforming=!1;var r=n.writecb;if(null===r)return this.emit("error",new ke);n.writechunk=null,n.writecb=null,null!=t&&this.push(t),r(e);var i=this._readableState;i.reading=!1,(i.needReadable||i.length<i.highWaterMark)&&this._read(i.highWaterMark)}function Oe(e){if(!(this instanceof Oe))return new Oe(e);Ae.call(this,e),this._transformState={afterTransform:Le.bind(this),needTransform:!1,transforming:!1,writecb:null,writechunk:null,writeencoding:null},this._readableState.needReadable=!0,this._readableState.sync=!1,e&&("function"==typeof e.transform&&(this._transform=e.transform),"function"==typeof e.flush&&(this._flush=e.flush)),this.on("prefinish",xe)}function xe(){var e=this;"function"!=typeof this._flush||this._readableState.destroyed?Me(this,null,null):this._flush((function(t,n){Me(e,t,n)}))}function Me(e,t,n){if(t)return e.emit("error",t);if(null!=n&&e.push(n),e._writableState.length)throw new Te;if(e._transformState.transforming)throw new Re;return e.push(null)}we(Oe,Ae),Oe.prototype.push=function(e,t){return this._transformState.needTransform=!1,Ae.prototype.push.call(this,e,t)},Oe.prototype._transform=function(e,t,n){n(new Ee("_transform()"))},Oe.prototype._write=function(e,t,n){var r=this._transformState;if(r.writecb=n,r.writechunk=e,r.writeencoding=t,!r.transforming){var i=this._readableState;(r.needTransform||i.needReadable||i.length<i.highWaterMark)&&this._read(i.highWaterMark)}},Oe.prototype._read=function(e){var t=this._transformState;null===t.writechunk||t.transforming?t.needTransform=!0:(t.transforming=!0,this._transform(t.writechunk,t.writeencoding,t.afterTransform))},Oe.prototype._destroy=function(e,t){Ae.prototype._destroy.call(this,e,(function(e){t(e)}))};var Ne,Ie=Be;function Be(e){if(!(this instanceof Be))return new Be(e);Ce.call(this,e)}we(Be,Ce),Be.prototype._transform=function(e,t,n){n(null,e)};var Pe=pe.codes,De=Pe.ERR_MISSING_ARGS,Ue=Pe.ERR_STREAM_DESTROYED;function Fe(e){if(e)throw e}function je(e){e()}function We(e,t){return e.pipe(t)}var He={};let qe;(He=He=r({})).Stream=He,He.Readable=He,He.Writable=c({}),He.Duplex=h({}),He.Transform=Ce,He.PassThrough=Ie,He.finished=s({}),He.pipeline=function(){for(var e=arguments.length,t=new Array(e),n=0;n<e;n++)t[n]=arguments[n];var r,i=function(e){return e.length?"function"!=typeof e[e.length-1]?Fe:e.pop():Fe}(t);if(Array.isArray(t[0])&&(t=t[0]),t.length<2)throw new De("streams");var o=t.map((function(e,n){var a=n<t.length-1;return function(e,t,n,r){r=function(e){var t=!1;return function(){t||(t=!0,e.apply(void 0,arguments))}}(r);var i=!1;e.on("close",(function(){i=!0})),void 0===Ne&&(Ne=s({})),Ne(e,{readable:t,writable:n},(function(e){if(e)return r(e);i=!0,r()}));var o=!1;return function(t){if(!i&&!o)return o=!0,function(e){return e.setHeader&&"function"==typeof e.abort}(e)?e.abort():"function"==typeof e.destroy?e.destroy():void r(t||new Ue("pipe"))}}(e,a,n>0,(function(e){r||(r=e),e&&o.forEach(je),a||(o.forEach(je),i(r))}))}));return t.reduce(We)};var ze="function"==typeof queueMicrotask?queueMicrotask:e=>(qe||(qe=Promise.resolve())).then(e).catch(e=>setTimeout(()=>{throw e},0)),Ve={};(function(e){var t=k("simple-peer");function n(e){return e.replace(/a=ice-options:trickle\s\n/g,"")}function r(e,t){return e instanceof Error||(e=new Error(e)),e.code=t,e}class i extends He.Duplex{constructor(e){if(super(e=Object.assign({allowHalfOpen:!1},e)),this._id=H(4).toString("hex").slice(0,7),this._debug("new peer %o",e),this.channelName=e.initiator?e.channelName||H(20).toString("hex"):null,this.initiator=e.initiator||!1,this.channelConfig=e.channelConfig||i.channelConfig,this.negotiated=this.channelConfig.negotiated,this.config=Object.assign({},i.config,e.config),this.offerOptions=e.offerOptions||{},this.answerOptions=e.answerOptions||{},this.sdpTransform=e.sdpTransform||(e=>e),this.streams=e.streams||(e.stream?[e.stream]:[]),this.trickle=void 0===e.trickle||e.trickle,this.allowHalfTrickle=void 0!==e.allowHalfTrickle&&e.allowHalfTrickle,this.iceCompleteTimeout=e.iceCompleteTimeout||5e3,this.destroyed=!1,this._connected=!1,this.remoteAddress=void 0,this.remoteFamily=void 0,this.remotePort=void 0,this.localAddress=void 0,this.localFamily=void 0,this.localPort=void 0,this._wrtc=e.wrtc&&"object"==typeof e.wrtc?e.wrtc:R(),!this._wrtc)throw"undefined"==typeof window?r("No WebRTC support: Specify `opts.wrtc` option in this environment","ERR_WEBRTC_SUPPORT"):r("No WebRTC support: Not a supported browser","ERR_WEBRTC_SUPPORT");this._pcReady=!1,this._channelReady=!1,this._iceComplete=!1,this._iceCompleteTimer=null,this._channel=null,this._pendingCandidates=[],this._isNegotiating=!this.negotiated&&!this.initiator,this._batchedNegotiation=!1,this._queuedNegotiation=!1,this._sendersAwaitingStable=[],this._senderMap=new Map,this._firstStable=!0,this._closingInterval=null,this._remoteTracks=[],this._remoteStreams=[],this._chunk=null,this._cb=null,this._interval=null;try{this._pc=new this._wrtc.RTCPeerConnection(this.config)}catch(dt){return void ze(()=>this.destroy(r(dt,"ERR_PC_CONSTRUCTOR")))}this._isReactNativeWebrtc="number"==typeof this._pc._peerConnectionId,this._pc.oniceconnectionstatechange=()=>{this._onIceStateChange()},this._pc.onicegatheringstatechange=()=>{this._onIceStateChange()},this._pc.onconnectionstatechange=()=>{this._onConnectionStateChange()},this._pc.onsignalingstatechange=()=>{this._onSignalingStateChange()},this._pc.onicecandidate=e=>{this._onIceCandidate(e)},this.initiator||this.negotiated?this._setupData({channel:this._pc.createDataChannel(this.channelName,this.channelConfig)}):this._pc.ondatachannel=e=>{this._setupData(e)},this.streams&&this.streams.forEach(e=>{this.addStream(e)}),this._pc.ontrack=e=>{this._onTrack(e)},this.initiator&&this._needsNegotiation(),this._onFinishBound=()=>{this._onFinish()},this.once("finish",this._onFinishBound)}get bufferSize(){return this._channel&&this._channel.bufferedAmount||0}get connected(){return this._connected&&"open"===this._channel.readyState}address(){return{port:this.localPort,family:this.localFamily,address:this.localAddress}}signal(e){if(this.destroyed)throw r("cannot signal after peer is destroyed","ERR_SIGNALING");if("string"==typeof e)try{e=JSON.parse(e)}catch(dt){e={}}this._debug("signal()"),e.renegotiate&&this.initiator&&(this._debug("got request to renegotiate"),this._needsNegotiation()),e.transceiverRequest&&this.initiator&&(this._debug("got request for transceiver"),this.addTransceiver(e.transceiverRequest.kind,e.transceiverRequest.init)),e.candidate&&(this._pc.remoteDescription&&this._pc.remoteDescription.type?this._addIceCandidate(e.candidate):this._pendingCandidates.push(e.candidate)),e.sdp&&this._pc.setRemoteDescription(new this._wrtc.RTCSessionDescription(e)).then(()=>{this.destroyed||(this._pendingCandidates.forEach(e=>{this._addIceCandidate(e)}),this._pendingCandidates=[],"offer"===this._pc.remoteDescription.type&&this._createAnswer())}).catch(e=>{this.destroy(r(e,"ERR_SET_REMOTE_DESCRIPTION"))}),e.sdp||e.candidate||e.renegotiate||e.transceiverRequest||this.destroy(r("signal() called with invalid signal data","ERR_SIGNALING"))}_addIceCandidate(e){var t=new this._wrtc.RTCIceCandidate(e);this._pc.addIceCandidate(t).catch(e=>{!t.address||t.address.endsWith(".local")?console.warn("Ignoring unsupported ICE candidate."):this.destroy(r(e,"ERR_ADD_ICE_CANDIDATE"))})}send(e){this._channel.send(e)}addTransceiver(e,t){if(this._debug("addTransceiver()"),this.initiator)try{this._pc.addTransceiver(e,t),this._needsNegotiation()}catch(dt){this.destroy(r(dt,"ERR_ADD_TRANSCEIVER"))}else this.emit("signal",{transceiverRequest:{kind:e,init:t}})}addStream(e){this._debug("addStream()"),e.getTracks().forEach(t=>{this.addTrack(t,e)})}addTrack(e,t){this._debug("addTrack()");var n=this._senderMap.get(e)||new Map,i=n.get(t);if(i)throw i.removed?r("Track has been removed. You should enable/disable tracks that you want to re-add.","ERR_SENDER_REMOVED"):r("Track has already been added to that stream.","ERR_SENDER_ALREADY_ADDED");i=this._pc.addTrack(e,t),n.set(t,i),this._senderMap.set(e,n),this._needsNegotiation()}replaceTrack(e,t,n){this._debug("replaceTrack()");var i=this._senderMap.get(e),o=i?i.get(n):null;if(!o)throw r("Cannot replace track that was never added.","ERR_TRACK_NOT_ADDED");t&&this._senderMap.set(t,i),null!=o.replaceTrack?o.replaceTrack(t):this.destroy(r("replaceTrack is not supported in this browser","ERR_UNSUPPORTED_REPLACETRACK"))}removeTrack(e,t){this._debug("removeSender()");var n=this._senderMap.get(e),i=n?n.get(t):null;if(!i)throw r("Cannot remove track that was never added.","ERR_TRACK_NOT_ADDED");try{i.removed=!0,this._pc.removeTrack(i)}catch(dt){"NS_ERROR_UNEXPECTED"===dt.name?this._sendersAwaitingStable.push(i):this.destroy(r(dt,"ERR_REMOVE_TRACK"))}this._needsNegotiation()}removeStream(e){this._debug("removeSenders()"),e.getTracks().forEach(t=>{this.removeTrack(t,e)})}_needsNegotiation(){this._debug("_needsNegotiation"),this._batchedNegotiation||(this._batchedNegotiation=!0,ze(()=>{this._batchedNegotiation=!1,this._debug("starting batched negotiation"),this.negotiate()}))}negotiate(){this.initiator?this._isNegotiating?(this._queuedNegotiation=!0,this._debug("already negotiating, queueing")):(this._debug("start negotiation"),setTimeout(()=>{this._createOffer()},0)):this._isNegotiating?(this._queuedNegotiation=!0,this._debug("already negotiating, queueing")):(this._debug("requesting negotiation from initiator"),this.emit("signal",{renegotiate:!0})),this._isNegotiating=!0}destroy(e){this._destroy(e,()=>{})}_destroy(e,t){if(!this.destroyed){if(this._debug("destroy (error: %s)",e&&(e.message||e)),this.readable=this.writable=!1,this._readableState.ended||this.push(null),this._writableState.finished||this.end(),this.destroyed=!0,this._connected=!1,this._pcReady=!1,this._channelReady=!1,this._remoteTracks=null,this._remoteStreams=null,this._senderMap=null,clearInterval(this._closingInterval),this._closingInterval=null,clearInterval(this._interval),this._interval=null,this._chunk=null,this._cb=null,this._onFinishBound&&this.removeListener("finish",this._onFinishBound),this._onFinishBound=null,this._channel){try{this._channel.close()}catch(e){}this._channel.onmessage=null,this._channel.onopen=null,this._channel.onclose=null,this._channel.onerror=null}if(this._pc){try{this._pc.close()}catch(e){}this._pc.oniceconnectionstatechange=null,this._pc.onicegatheringstatechange=null,this._pc.onsignalingstatechange=null,this._pc.onicecandidate=null,this._pc.ontrack=null,this._pc.ondatachannel=null}this._pc=null,this._channel=null,e&&this.emit("error",e),this.emit("close"),t()}}_setupData(e){if(!e.channel)return this.destroy(r("Data channel event is missing `channel` property","ERR_DATA_CHANNEL"));this._channel=e.channel,this._channel.binaryType="arraybuffer","number"==typeof this._channel.bufferedAmountLowThreshold&&(this._channel.bufferedAmountLowThreshold=65536),this.channelName=this._channel.label,this._channel.onmessage=e=>{this._onChannelMessage(e)},this._channel.onbufferedamountlow=()=>{this._onChannelBufferedAmountLow()},this._channel.onopen=()=>{this._onChannelOpen()},this._channel.onclose=()=>{this._onChannelClose()},this._channel.onerror=e=>{this.destroy(r(e,"ERR_DATA_CHANNEL"))};var t=!1;this._closingInterval=setInterval(()=>{this._channel&&"closing"===this._channel.readyState?(t&&this._onChannelClose(),t=!0):t=!1},5e3)}_read(){}_write(e,t,n){if(this.destroyed)return n(r("cannot write after peer is destroyed","ERR_DATA_CHANNEL"));if(this._connected){try{this.send(e)}catch(dt){return this.destroy(r(dt,"ERR_DATA_CHANNEL"))}this._channel.bufferedAmount>65536?(this._debug("start backpressure: bufferedAmount %d",this._channel.bufferedAmount),this._cb=n):n(null)}else this._debug("write before connect"),this._chunk=e,this._cb=n}_onFinish(){if(this.destroyed)return;const e=()=>{setTimeout(()=>this.destroy(),1e3)};this._connected?e():this.once("connect",e)}_startIceCompleteTimeout(){this.destroyed||this._iceCompleteTimer||(this._debug("started iceComplete timeout"),this._iceCompleteTimer=setTimeout(()=>{this._iceComplete||(this._iceComplete=!0,this._debug("iceComplete timeout completed"),this.emit("iceTimeout"),this.emit("_iceComplete"))},this.iceCompleteTimeout))}_createOffer(){this.destroyed||this._pc.createOffer(this.offerOptions).then(e=>{if(this.destroyed)return;this.trickle||this.allowHalfTrickle||(e.sdp=n(e.sdp)),e.sdp=this.sdpTransform(e.sdp);const t=()=>{if(!this.destroyed){var t=this._pc.localDescription||e;this._debug("signal"),this.emit("signal",{type:t.type,sdp:t.sdp})}};this._pc.setLocalDescription(e).then(()=>{this._debug("createOffer success"),this.destroyed||(this.trickle||this._iceComplete?t():this.once("_iceComplete",t))}).catch(e=>{this.destroy(r(e,"ERR_SET_LOCAL_DESCRIPTION"))})}).catch(e=>{this.destroy(r(e,"ERR_CREATE_OFFER"))})}_requestMissingTransceivers(){this._pc.getTransceivers&&this._pc.getTransceivers().forEach(e=>{e.mid||!e.sender.track||e.requested||(e.requested=!0,this.addTransceiver(e.sender.track.kind))})}_createAnswer(){this.destroyed||this._pc.createAnswer(this.answerOptions).then(e=>{if(this.destroyed)return;this.trickle||this.allowHalfTrickle||(e.sdp=n(e.sdp)),e.sdp=this.sdpTransform(e.sdp);const t=()=>{if(!this.destroyed){var t=this._pc.localDescription||e;this._debug("signal"),this.emit("signal",{type:t.type,sdp:t.sdp}),this.initiator||this._requestMissingTransceivers()}};this._pc.setLocalDescription(e).then(()=>{this.destroyed||(this.trickle||this._iceComplete?t():this.once("_iceComplete",t))}).catch(e=>{this.destroy(r(e,"ERR_SET_LOCAL_DESCRIPTION"))})}).catch(e=>{this.destroy(r(e,"ERR_CREATE_ANSWER"))})}_onConnectionStateChange(){this.destroyed||"failed"===this._pc.connectionState&&this.destroy(r("Connection failed.","ERR_CONNECTION_FAILURE"))}_onIceStateChange(){if(!this.destroyed){var e=this._pc.iceConnectionState,t=this._pc.iceGatheringState;this._debug("iceStateChange (connection: %s) (gathering: %s)",e,t),this.emit("iceStateChange",e,t),"connected"!==e&&"completed"!==e||(this._pcReady=!0,this._maybeReady()),"failed"===e&&this.destroy(r("Ice connection failed.","ERR_ICE_CONNECTION_FAILURE")),"closed"===e&&this.destroy(r("Ice connection closed.","ERR_ICE_CONNECTION_CLOSED"))}}getStats(e){const t=e=>("[object Array]"===Object.prototype.toString.call(e.values)&&e.values.forEach(t=>{Object.assign(e,t)}),e);0===this._pc.getStats.length||this._isReactNativeWebrtc?this._pc.getStats().then(n=>{var r=[];n.forEach(e=>{r.push(t(e))}),e(null,r)},t=>e(t)):this._pc.getStats.length>0?this._pc.getStats(n=>{if(!this.destroyed){var r=[];n.result().forEach(e=>{var n={};e.names().forEach(t=>{n[t]=e.stat(t)}),n.id=e.id,n.type=e.type,n.timestamp=e.timestamp,r.push(t(n))}),e(null,r)}},t=>e(t)):e(null,[])}_maybeReady(){if(this._debug("maybeReady pc %s channel %s",this._pcReady,this._channelReady),this._connected||this._connecting||!this._pcReady||!this._channelReady)return;this._connecting=!0;const e=()=>{this.destroyed||this.getStats((t,n)=>{if(this.destroyed)return;t&&(n=[]);var i={},o={},s={},a=!1;n.forEach(e=>{"remotecandidate"!==e.type&&"remote-candidate"!==e.type||(i[e.id]=e),"localcandidate"!==e.type&&"local-candidate"!==e.type||(o[e.id]=e),"candidatepair"!==e.type&&"candidate-pair"!==e.type||(s[e.id]=e)});const h=e=>{a=!0;var t=o[e.localCandidateId];t&&(t.ip||t.address)?(this.localAddress=t.ip||t.address,this.localPort=Number(t.port)):t&&t.ipAddress?(this.localAddress=t.ipAddress,this.localPort=Number(t.portNumber)):"string"==typeof e.googLocalAddress&&(t=e.googLocalAddress.split(":"),this.localAddress=t[0],this.localPort=Number(t[1])),this.localAddress&&(this.localFamily=this.localAddress.includes(":")?"IPv6":"IPv4");var n=i[e.remoteCandidateId];n&&(n.ip||n.address)?(this.remoteAddress=n.ip||n.address,this.remotePort=Number(n.port)):n&&n.ipAddress?(this.remoteAddress=n.ipAddress,this.remotePort=Number(n.portNumber)):"string"==typeof e.googRemoteAddress&&(n=e.googRemoteAddress.split(":"),this.remoteAddress=n[0],this.remotePort=Number(n[1])),this.remoteAddress&&(this.remoteFamily=this.remoteAddress.includes(":")?"IPv6":"IPv4"),this._debug("connect local: %s:%s remote: %s:%s",this.localAddress,this.localPort,this.remoteAddress,this.remotePort)};if(n.forEach(e=>{"transport"===e.type&&e.selectedCandidatePairId&&h(s[e.selectedCandidatePairId]),("googCandidatePair"===e.type&&"true"===e.googActiveConnection||("candidatepair"===e.type||"candidate-pair"===e.type)&&e.selected)&&h(e)}),a||Object.keys(s).length&&!Object.keys(o).length){if(this._connecting=!1,this._connected=!0,this._chunk){try{this.send(this._chunk)}catch(t){return this.destroy(r(t,"ERR_DATA_CHANNEL"))}this._chunk=null,this._debug('sent chunk from "write before connect"');var c=this._cb;this._cb=null,c(null)}"number"!=typeof this._channel.bufferedAmountLowThreshold&&(this._interval=setInterval(()=>this._onInterval(),150),this._interval.unref&&this._interval.unref()),this._debug("connect"),this.emit("connect")}else setTimeout(e,100)})};e()}_onInterval(){!this._cb||!this._channel||this._channel.bufferedAmount>65536||this._onChannelBufferedAmountLow()}_onSignalingStateChange(){this.destroyed||("stable"!==this._pc.signalingState||this._firstStable||(this._isNegotiating=!1,this._debug("flushing sender queue",this._sendersAwaitingStable),this._sendersAwaitingStable.forEach(e=>{this._pc.removeTrack(e),this._queuedNegotiation=!0}),this._sendersAwaitingStable=[],this._queuedNegotiation&&(this._debug("flushing negotiation queue"),this._queuedNegotiation=!1,this._needsNegotiation()),this._debug("negotiate"),this.emit("negotiate")),this._firstStable=!1,this._debug("signalingStateChange %s",this._pc.signalingState),this.emit("signalingStateChange",this._pc.signalingState))}_onIceCandidate(e){this.destroyed||(e.candidate&&this.trickle?this.emit("signal",{candidate:{candidate:e.candidate.candidate,sdpMLineIndex:e.candidate.sdpMLineIndex,sdpMid:e.candidate.sdpMid}}):e.candidate||this._iceComplete||(this._iceComplete=!0,this.emit("_iceComplete")),e.candidate&&this._startIceCompleteTimeout())}_onChannelMessage(t){if(!this.destroyed){var n=t.data;n instanceof ArrayBuffer&&(n=e.from(n)),this.push(n)}}_onChannelBufferedAmountLow(){if(!this.destroyed&&this._cb){this._debug("ending backpressure: bufferedAmount %d",this._channel.bufferedAmount);var e=this._cb;this._cb=null,e(null)}}_onChannelOpen(){this._connected||this.destroyed||(this._debug("on channel open"),this._channelReady=!0,this._maybeReady())}_onChannelClose(){this.destroyed||(this._debug("on channel close"),this.destroy())}_onTrack(e){this.destroyed||e.streams.forEach(t=>{this._debug("on track"),this.emit("track",e.track,t),this._remoteTracks.push({track:e.track,stream:t}),this._remoteStreams.some(e=>e.id===t.id)||(this._remoteStreams.push(t),ze(()=>{this.emit("stream",t)}))})}_debug(){var e=[].slice.call(arguments);e[0]="["+this._id+"] "+e[0],t.apply(null,e)}}i.WEBRTC_SUPPORT=!!R(),i.config={iceServers:[{urls:"stun:stun.l.google.com:19302"},{urls:"stun:global.stun.twilio.com:3478?transport=udp"}],sdpSemantics:"unified-plan"},i.channelConfig={},Ve=i}).call(this,u({}).Buffer);var Ge={};(function(e){const t=k("simple-websocket"),n="function"!=typeof oe?WebSocket:oe;class r extends He.Duplex{constructor(e={}){if("string"==typeof e&&(e={url:e}),super(e=Object.assign({allowHalfOpen:!1},e)),null==e.url&&null==e.socket)throw new Error("Missing required `url` or `socket` option");if(null!=e.url&&null!=e.socket)throw new Error("Must specify either `url` or `socket` option, not both");if(this._id=H(4).toString("hex").slice(0,7),this._debug("new websocket: %o",e),this.connected=!1,this.destroyed=!1,this._chunk=null,this._cb=null,this._interval=null,e.socket)this.url=e.socket.url,this._ws=e.socket,this.connected=e.socket.readyState===n.OPEN;else{this.url=e.url;try{this._ws="function"==typeof oe?new n(e.url,e):new n(e.url)}catch(dt){return void ze(()=>this.destroy(dt))}}this._ws.binaryType="arraybuffer",this._ws.onopen=()=>{this._onOpen()},this._ws.onmessage=e=>{this._onMessage(e)},this._ws.onclose=()=>{this._onClose()},this._ws.onerror=()=>{this.destroy(new Error("connection error to "+this.url))},this._onFinishBound=()=>{this._onFinish()},this.once("finish",this._onFinishBound)}send(e){this._ws.send(e)}destroy(e){this._destroy(e,()=>{})}_destroy(e,t){if(!this.destroyed){if(this._debug("destroy (error: %s)",e&&(e.message||e)),this.readable=this.writable=!1,this._readableState.ended||this.push(null),this._writableState.finished||this.end(),this.connected=!1,this.destroyed=!0,clearInterval(this._interval),this._interval=null,this._chunk=null,this._cb=null,this._onFinishBound&&this.removeListener("finish",this._onFinishBound),this._onFinishBound=null,this._ws){const t=this._ws,r=()=>{t.onclose=null};if(t.readyState===n.CLOSED)r();else try{t.onclose=r,t.close()}catch(e){r()}t.onopen=null,t.onmessage=null,t.onerror=()=>{}}if(this._ws=null,e){if("undefined"!=typeof DOMException&&e instanceof DOMException){const t=e.code;(e=new Error(e.message)).code=t}this.emit("error",e)}this.emit("close"),t()}}_read(){}_write(e,t,n){if(this.destroyed)return n(new Error("cannot write after socket is destroyed"));if(this.connected){try{this.send(e)}catch(dt){return this.destroy(dt)}"function"!=typeof oe&&this._ws.bufferedAmount>65536?(this._debug("start backpressure: bufferedAmount %d",this._ws.bufferedAmount),this._cb=n):n(null)}else this._debug("write before connect"),this._chunk=e,this._cb=n}_onFinish(){if(this.destroyed)return;const e=()=>{setTimeout(()=>this.destroy(),1e3)};this.connected?e():this.once("connect",e)}_onMessage(t){if(this.destroyed)return;let n=t.data;n instanceof ArrayBuffer&&(n=e.from(n)),this.push(n)}_onOpen(){if(!this.connected&&!this.destroyed){if(this.connected=!0,this._chunk){try{this.send(this._chunk)}catch(dt){return this.destroy(dt)}this._chunk=null,this._debug('sent chunk from "write before connect"');const e=this._cb;this._cb=null,e(null)}"function"!=typeof oe&&(this._interval=setInterval(()=>this._onInterval(),150),this._interval.unref&&this._interval.unref()),this._debug("connect"),this.emit("connect")}}_onInterval(){if(!this._cb||!this._ws||this._ws.bufferedAmount>65536)return;this._debug("ending backpressure: bufferedAmount %d",this._ws.bufferedAmount);const e=this._cb;this._cb=null,e(null)}_onClose(){this.destroyed||(this._debug("on close"),this.destroy())}_debug(){const e=[].slice.call(arguments);e[0]="["+this._id+"] "+e[0],t.apply(null,e)}}r.WEBSOCKET_SUPPORT=!!n,Ge=r}).call(this,u({}).Buffer);var Ye={};(function(e){Ye.binaryToHex=function(t){return"string"!=typeof t&&(t=String(t)),e.from(t,"binary").toString("hex")},Ye.hexToBinary=function(t){return"string"!=typeof t&&(t=String(t)),e.from(t,"hex").toString("binary")},Object.assign(Ye,oe)}).call(this,u({}).Buffer);var Je=class extends q{constructor(e,t){super(),this.client=e,this.announceUrl=t,this.interval=null,this.destroyed=!1}setInterval(e){null==e&&(e=this.DEFAULT_ANNOUNCE_INTERVAL),clearInterval(this.interval),e&&(this.interval=setInterval(()=>{this.announce(this.client._defaultAnnounceOpts())},e),this.interval.unref&&this.interval.unref())}},Ke={};const $e=k("bittorrent-tracker:websocket-tracker"),Xe={};class Ze extends Je{constructor(e,t,n){super(e,t),$e("new websocket tracker %s",t),this.peers={},this.socket=null,this.reconnecting=!1,this.retries=0,this.reconnectTimer=null,this.expectingResponse=!1,this._openSocket()}announce(e){if(this.destroyed||this.reconnecting)return;if(!this.socket.connected)return void this.socket.once("connect",()=>{this.announce(e)});const t=Object.assign({},e,{action:"announce",info_hash:this.client._infoHashBinary,peer_id:this.client._peerIdBinary});if(this._trackerId&&(t.trackerid=this._trackerId),"stopped"===e.event||"completed"===e.event)this._send(t);else{const n=Math.min(e.numwant,10);this._generateOffers(n,e=>{t.numwant=n,t.offers=e,this._send(t)})}}scrape(e){if(this.destroyed||this.reconnecting)return;if(!this.socket.connected)return void this.socket.once("connect",()=>{this.scrape(e)});const t={action:"scrape",info_hash:Array.isArray(e.infoHash)&&e.infoHash.length>0?e.infoHash.map(e=>e.toString("binary")):e.infoHash&&e.infoHash.toString("binary")||this.client._infoHashBinary};this._send(t)}destroy(e=Qe){if(this.destroyed)return e(null);this.destroyed=!0,clearInterval(this.interval),clearTimeout(this.reconnectTimer);for(const i in this.peers){const e=this.peers[i];clearTimeout(e.trackerTimeout),e.destroy()}if(this.peers=null,this.socket&&(this.socket.removeListener("connect",this._onSocketConnectBound),this.socket.removeListener("data",this._onSocketDataBound),this.socket.removeListener("close",this._onSocketCloseBound),this.socket.removeListener("error",this._onSocketErrorBound),this.socket=null),this._onSocketConnectBound=null,this._onSocketErrorBound=null,this._onSocketDataBound=null,this._onSocketCloseBound=null,Xe[this.announceUrl]&&(Xe[this.announceUrl].consumers-=1),Xe[this.announceUrl].consumers>0)return e();let t=Xe[this.announceUrl];if(delete Xe[this.announceUrl],t.on("error",Qe),t.once("close",e),!this.expectingResponse)return r();var n=setTimeout(r,Ye.DESTROY_TIMEOUT);function r(){n&&(clearTimeout(n),n=null),t.removeListener("data",r),t.destroy(),t=null}t.once("data",r)}_openSocket(){this.destroyed=!1,this.peers||(this.peers={}),this._onSocketConnectBound=()=>{this._onSocketConnect()},this._onSocketErrorBound=e=>{this._onSocketError(e)},this._onSocketDataBound=e=>{this._onSocketData(e)},this._onSocketCloseBound=()=>{this._onSocketClose()},this.socket=Xe[this.announceUrl],this.socket?(Xe[this.announceUrl].consumers+=1,this.socket.connected&&this._onSocketConnectBound()):(this.socket=Xe[this.announceUrl]=new Ge(this.announceUrl),this.socket.consumers=1,this.socket.once("connect",this._onSocketConnectBound)),this.socket.on("data",this._onSocketDataBound),this.socket.once("close",this._onSocketCloseBound),this.socket.once("error",this._onSocketErrorBound)}_onSocketConnect(){this.destroyed||this.reconnecting&&(this.reconnecting=!1,this.retries=0,this.announce(this.client._defaultAnnounceOpts()))}_onSocketData(e){if(!this.destroyed){this.expectingResponse=!1;try{e=JSON.parse(e)}catch(dt){return void this.client.emit("warning",new Error("Invalid tracker response"))}"announce"===e.action?this._onAnnounceResponse(e):"scrape"===e.action?this._onScrapeResponse(e):this._onSocketError(new Error("invalid action in WS response: "+e.action))}}_onAnnounceResponse(e){if(e.info_hash!==this.client._infoHashBinary)return void $e("ignoring websocket data from %s for %s (looking for %s: reused socket)",this.announceUrl,Ye.binaryToHex(e.info_hash),this.client.infoHash);if(e.peer_id&&e.peer_id===this.client._peerIdBinary)return;$e("received %s from %s for %s",JSON.stringify(e),this.announceUrl,this.client.infoHash);const t=e["failure reason"];if(t)return this.client.emit("warning",new Error(t));const n=e["warning message"];n&&this.client.emit("warning",new Error(n));const r=e.interval||e["min interval"];r&&this.setInterval(1e3*r);const i=e["tracker id"];if(i&&(this._trackerId=i),null!=e.complete){const t=Object.assign({},e,{announce:this.announceUrl,infoHash:Ye.binaryToHex(e.info_hash)});this.client.emit("update",t)}let o;if(e.offer&&e.peer_id&&($e("creating peer (from remote offer)"),(o=this._createPeer()).id=Ye.binaryToHex(e.peer_id),o.once("signal",t=>{const n={action:"announce",info_hash:this.client._infoHashBinary,peer_id:this.client._peerIdBinary,to_peer_id:e.peer_id,answer:t,offer_id:e.offer_id};this._trackerId&&(n.trackerid=this._trackerId),this._send(n)}),o.signal(e.offer),this.client.emit("peer",o)),e.answer&&e.peer_id){const t=Ye.binaryToHex(e.offer_id);(o=this.peers[t])?(o.id=Ye.binaryToHex(e.peer_id),o.signal(e.answer),this.client.emit("peer",o),clearTimeout(o.trackerTimeout),o.trackerTimeout=null,delete this.peers[t]):$e("got unexpected answer: "+JSON.stringify(e.answer))}}_onScrapeResponse(e){e=e.files||{};const t=Object.keys(e);0!==t.length?t.forEach(t=>{const n=Object.assign(e[t],{announce:this.announceUrl,infoHash:Ye.binaryToHex(t)});this.client.emit("scrape",n)}):this.client.emit("warning",new Error("invalid scrape response"))}_onSocketClose(){this.destroyed||(this.destroy(),this._startReconnectTimer())}_onSocketError(e){this.destroyed||(this.destroy(),this.client.emit("warning",e),this._startReconnectTimer())}_startReconnectTimer(){const e=Math.floor(3e5*Math.random())+Math.min(1e4*Math.pow(2,this.retries),36e5);this.reconnecting=!0,clearTimeout(this.reconnectTimer),this.reconnectTimer=setTimeout(()=>{this.retries++,this._openSocket()},e),this.reconnectTimer.unref&&this.reconnectTimer.unref(),$e("reconnecting socket in %s ms",e)}_send(e){if(this.destroyed)return;this.expectingResponse=!0;const t=JSON.stringify(e);$e("send %s",t),this.socket.send(t)}_generateOffers(e,t){const n=this,r=[];$e("generating %s offers",e);for(let s=0;s<e;++s)i();function i(){const e=H(20).toString("hex");$e("creating peer (from _generateOffers)");const t=n.peers[e]=n._createPeer({initiator:!0});t.once("signal",t=>{r.push({offer:t,offer_id:Ye.hexToBinary(e)}),o()}),t.trackerTimeout=setTimeout(()=>{$e("tracker timeout: destroying peer"),t.trackerTimeout=null,delete n.peers[e],t.destroy()},5e4),t.trackerTimeout.unref&&t.trackerTimeout.unref()}function o(){r.length===e&&($e("generated %s offers",e),t(r))}o()}_createPeer(e){const t=this;e=Object.assign({trickle:!1,config:t.client._rtcConfig,wrtc:t.client._wrtc},e);const n=new Ve(e);return n.once("error",r),n.once("connect",(function e(){n.removeListener("error",r),n.removeListener("connect",e)})),n;function r(e){t.client.emit("warning",new Error("Connection error: "+e.message)),n.destroy()}}}function Qe(){}Ze.prototype.DEFAULT_ANNOUNCE_INTERVAL=3e4,Ze._socketPool=Xe,Ke=Ze;var et,tt,nt,rt,it,ot={exports:{}};et="undefined"!=typeof self?self:this,tt=function(){return function(e){var t={};function n(r){if(t[r])return t[r].exports;var i=t[r]={i:r,l:!1,exports:{}};return e[r].call(i.exports,i,i.exports,n),i.l=!0,i.exports}return n.m=e,n.c=t,n.d=function(e,t,r){n.o(e,t)||Object.defineProperty(e,t,{configurable:!1,enumerable:!0,get:r})},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="",n(n.s=3)}([function(e,t,n){var r=n(5),i=n(1),o=i.toHex,s=i.ceilHeapSize,a=n(6),h=function(e){for(e+=9;e%64>0;e+=1);return e},c=function(e,t){var n=new Int32Array(e,t+320,5),r=new Int32Array(5),i=new DataView(r.buffer);return i.setInt32(0,n[0],!1),i.setInt32(4,n[1],!1),i.setInt32(8,n[2],!1),i.setInt32(12,n[3],!1),i.setInt32(16,n[4],!1),r},u=function(){function e(t){if(function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e),(t=t||65536)%64>0)throw new Error("Chunk size must be a multiple of 128 bit");this._offset=0,this._maxChunkLen=t,this._padMaxChunkLen=h(t),this._heap=new ArrayBuffer(s(this._padMaxChunkLen+320+20)),this._h32=new Int32Array(this._heap),this._h8=new Int8Array(this._heap),this._core=new r({Int32Array:Int32Array},{},this._heap)}return e.prototype._initState=function(e,t){this._offset=0;var n=new Int32Array(e,t+320,5);n[0]=1732584193,n[1]=-271733879,n[2]=-1732584194,n[3]=271733878,n[4]=-1009589776},e.prototype._padChunk=function(e,t){var n=h(e),r=new Int32Array(this._heap,0,n>>2);return function(e,t){var n=new Uint8Array(e.buffer),r=t%4,i=t-r;switch(r){case 0:n[i+3]=0;case 1:n[i+2]=0;case 2:n[i+1]=0;case 3:n[i+0]=0}for(var o=1+(t>>2);o<e.length;o++)e[o]=0}(r,e),function(e,t,n){e[t>>2]|=128<<24-(t%4<<3),e[14+(2+(t>>2)&-16)]=n/(1<<29)|0,e[15+(2+(t>>2)&-16)]=n<<3}(r,e,t),n},e.prototype._write=function(e,t,n,r){a(e,this._h8,this._h32,t,n,r||0)},e.prototype._coreCall=function(e,t,n,r,i){var o=n;this._write(e,t,n),i&&(o=this._padChunk(n,r)),this._core.hash(o,this._padMaxChunkLen)},e.prototype.rawDigest=function(e){var t=e.byteLength||e.length||e.size||0;this._initState(this._heap,this._padMaxChunkLen);var n=0,r=this._maxChunkLen;for(n=0;t>n+r;n+=r)this._coreCall(e,n,r,t,!1);return this._coreCall(e,n,t-n,t,!0),c(this._heap,this._padMaxChunkLen)},e.prototype.digest=function(e){return o(this.rawDigest(e).buffer)},e.prototype.digestFromString=function(e){return this.digest(e)},e.prototype.digestFromBuffer=function(e){return this.digest(e)},e.prototype.digestFromArrayBuffer=function(e){return this.digest(e)},e.prototype.resetState=function(){return this._initState(this._heap,this._padMaxChunkLen),this},e.prototype.append=function(e){var t=0,n=e.byteLength||e.length||e.size||0,r=this._offset%this._maxChunkLen,i=void 0;for(this._offset+=n;t<n;)i=Math.min(n-t,this._maxChunkLen-r),this._write(e,t,i,r),t+=i,(r+=i)===this._maxChunkLen&&(this._core.hash(this._maxChunkLen,this._padMaxChunkLen),r=0);return this},e.prototype.getState=function(){var e=void 0;if(this._offset%this._maxChunkLen)e=this._heap.slice(0);else{var t=new Int32Array(this._heap,this._padMaxChunkLen+320,5);e=t.buffer.slice(t.byteOffset,t.byteOffset+t.byteLength)}return{offset:this._offset,heap:e}},e.prototype.setState=function(e){return this._offset=e.offset,20===e.heap.byteLength?new Int32Array(this._heap,this._padMaxChunkLen+320,5).set(new Int32Array(e.heap)):this._h32.set(new Int32Array(e.heap)),this},e.prototype.rawEnd=function(){var e=this._offset,t=e%this._maxChunkLen,n=this._padChunk(t,e);this._core.hash(n,this._padMaxChunkLen);var r=c(this._heap,this._padMaxChunkLen);return this._initState(this._heap,this._padMaxChunkLen),r},e.prototype.end=function(){return o(this.rawEnd().buffer)},e}();e.exports=u,e.exports._core=r},function(e,t){for(var n=new Array(256),r=0;r<256;r++)n[r]=(r<16?"0":"")+r.toString(16);e.exports.toHex=function(e){for(var t=new Uint8Array(e),r=new Array(e.byteLength),i=0;i<r.length;i++)r[i]=n[t[i]];return r.join("")},e.exports.ceilHeapSize=function(e){var t=0;if(e<=65536)return 65536;if(e<16777216)for(t=1;t<e;t<<=1);else for(t=16777216;t<e;t+=16777216);return t},e.exports.isDedicatedWorkerScope=function(e){var t="WorkerGlobalScope"in e&&e instanceof e.WorkerGlobalScope,n="SharedWorkerGlobalScope"in e&&e instanceof e.SharedWorkerGlobalScope,r="ServiceWorkerGlobalScope"in e&&e instanceof e.ServiceWorkerGlobalScope;return t&&!n&&!r}},function(e,t,n){e.exports=function(){var e=n(0),t=function(e,n,r,i,o){var s=new self.FileReader;s.onloadend=function(){if(s.error)return o(s.error);var a=s.result;n+=s.result.byteLength;try{e.append(a)}catch(h){return void o(h)}n<i.size?t(e,n,r,i,o):o(null,e.end())},s.readAsArrayBuffer(i.slice(n,n+r))},r=!0;return self.onmessage=function(n){if(r){var i=n.data.data,o=n.data.file,s=n.data.id;if(void 0!==s&&(o||i)){var a=n.data.blockSize||4194304,h=new e(a);h.resetState();var c=function(e,t){e?self.postMessage({id:s,error:e.name}):self.postMessage({id:s,hash:t})};i&&function(e,t,n){try{n(null,e.digest(t))}catch(r){return n(r)}}(h,i,c),o&&t(h,0,a,o,c)}}},function(){r=!1}}},function(e,t,n){var r=n(4),i=n(0),o=n(7),s=n(2),a=n(1).isDedicatedWorkerScope,h="undefined"!=typeof self&&a(self);i.disableWorkerBehaviour=h?s():function(){},i.createWorker=function(){var e=r(2),t=e.terminate;return e.terminate=function(){URL.revokeObjectURL(e.objectURL),t.call(e)},e},i.createHash=o,e.exports=i},function(e,t,n){function r(e){var t={};function n(r){if(t[r])return t[r].exports;var i=t[r]={i:r,l:!1,exports:{}};return e[r].call(i.exports,i,i.exports,n),i.l=!0,i.exports}n.m=e,n.c=t,n.i=function(e){return e},n.d=function(e,t,r){n.o(e,t)||Object.defineProperty(e,t,{configurable:!1,enumerable:!0,get:r})},n.r=function(e){Object.defineProperty(e,"__esModule",{value:!0})},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="/",n.oe=function(e){throw console.error(e),e};var r=n(n.s=ENTRY_MODULE);return r.default||r}function i(e){return(e+"").replace(/[.?*+^$[\]\\(){}|-]/g,"\\$&")}function o(e,t,r){var o={};o[r]=[];var s=t.toString(),a=s.match(/^function\s?\(\w+,\s*\w+,\s*(\w+)\)/);if(!a)return o;for(var h,c=a[1],u=new RegExp("(\\\\n|\\W)"+i(c)+"\\((/\\*.*?\\*/)?s?.*?([\\.|\\-|\\+|\\w|/|@]+).*?\\)","g");h=u.exec(s);)"dll-reference"!==h[3]&&o[r].push(h[3]);for(u=new RegExp("\\("+i(c)+'\\("(dll-reference\\s([\\.|\\-|\\+|\\w|/|@]+))"\\)\\)\\((/\\*.*?\\*/)?s?.*?([\\.|\\-|\\+|\\w|/|@]+).*?\\)',"g");h=u.exec(s);)e[h[2]]||(o[r].push(h[1]),e[h[2]]=n(h[1]).m),o[h[2]]=o[h[2]]||[],o[h[2]].push(h[4]);return o}function s(e){return Object.keys(e).reduce((function(t,n){return t||e[n].length>0}),!1)}e.exports=function(e,t){t=t||{};var i={main:n.m},a=t.all?{main:Object.keys(i)}:function(e,t){for(var n={main:[t]},r={main:[]},i={main:{}};s(n);)for(var a=Object.keys(n),h=0;h<a.length;h++){var c=a[h],u=n[c].pop();if(i[c]=i[c]||{},!i[c][u]&&e[c][u]){i[c][u]=!0,r[c]=r[c]||[],r[c].push(u);for(var l=o(e,e[c][u],c),f=Object.keys(l),d=0;d<f.length;d++)n[f[d]]=n[f[d]]||[],n[f[d]]=n[f[d]].concat(l[f[d]])}}return r}(i,e),h="";Object.keys(a).filter((function(e){return"main"!==e})).forEach((function(e){for(var t=0;a[e][t];)t++;a[e].push(t),i[e][t]="(function(module, exports, __webpack_require__) { module.exports = __webpack_require__; })",h=h+"var "+e+" = ("+r.toString().replace("ENTRY_MODULE",JSON.stringify(t))+")({"+a[e].map((function(t){return JSON.stringify(t)+": "+i[e][t].toString()})).join(",")+"});\n"})),h=h+"("+r.toString().replace("ENTRY_MODULE",JSON.stringify(e))+")({"+a.main.map((function(e){return JSON.stringify(e)+": "+i.main[e].toString()})).join(",")+"})(self);";var c=new window.Blob([h],{type:"text/javascript"});if(t.bare)return c;var u=(window.URL||window.webkitURL||window.mozURL||window.msURL).createObjectURL(c),l=new window.Worker(u);return l.objectURL=u,l}},function(e,t){e.exports=function(e,t,n){"use asm";var r=new e.Int32Array(n);function i(e,t){e=e|0;t=t|0;var n=0,i=0,o=0,s=0,a=0,h=0,c=0,u=0,l=0,f=0,d=0,p=0,g=0,y=0;o=r[t+320>>2]|0;a=r[t+324>>2]|0;c=r[t+328>>2]|0;l=r[t+332>>2]|0;d=r[t+336>>2]|0;for(n=0;(n|0)<(e|0);n=n+64|0){s=o;h=a;u=c;f=l;p=d;for(i=0;(i|0)<64;i=i+4|0){y=r[n+i>>2]|0;g=((o<<5|o>>>27)+(a&c|~a&l)|0)+((y+d|0)+1518500249|0)|0;d=l;l=c;c=a<<30|a>>>2;a=o;o=g;r[e+i>>2]=y}for(i=e+64|0;(i|0)<(e+80|0);i=i+4|0){y=(r[i-12>>2]^r[i-32>>2]^r[i-56>>2]^r[i-64>>2])<<1|(r[i-12>>2]^r[i-32>>2]^r[i-56>>2]^r[i-64>>2])>>>31;g=((o<<5|o>>>27)+(a&c|~a&l)|0)+((y+d|0)+1518500249|0)|0;d=l;l=c;c=a<<30|a>>>2;a=o;o=g;r[i>>2]=y}for(i=e+80|0;(i|0)<(e+160|0);i=i+4|0){y=(r[i-12>>2]^r[i-32>>2]^r[i-56>>2]^r[i-64>>2])<<1|(r[i-12>>2]^r[i-32>>2]^r[i-56>>2]^r[i-64>>2])>>>31;g=((o<<5|o>>>27)+(a^c^l)|0)+((y+d|0)+1859775393|0)|0;d=l;l=c;c=a<<30|a>>>2;a=o;o=g;r[i>>2]=y}for(i=e+160|0;(i|0)<(e+240|0);i=i+4|0){y=(r[i-12>>2]^r[i-32>>2]^r[i-56>>2]^r[i-64>>2])<<1|(r[i-12>>2]^r[i-32>>2]^r[i-56>>2]^r[i-64>>2])>>>31;g=((o<<5|o>>>27)+(a&c|a&l|c&l)|0)+((y+d|0)-1894007588|0)|0;d=l;l=c;c=a<<30|a>>>2;a=o;o=g;r[i>>2]=y}for(i=e+240|0;(i|0)<(e+320|0);i=i+4|0){y=(r[i-12>>2]^r[i-32>>2]^r[i-56>>2]^r[i-64>>2])<<1|(r[i-12>>2]^r[i-32>>2]^r[i-56>>2]^r[i-64>>2])>>>31;g=((o<<5|o>>>27)+(a^c^l)|0)+((y+d|0)-899497514|0)|0;d=l;l=c;c=a<<30|a>>>2;a=o;o=g;r[i>>2]=y}o=o+s|0;a=a+h|0;c=c+u|0;l=l+f|0;d=d+p|0}r[t+320>>2]=o;r[t+324>>2]=a;r[t+328>>2]=c;r[t+332>>2]=l;r[t+336>>2]=d}return{hash:i}}},function(e,t){var n=this,r=void 0;"undefined"!=typeof self&&void 0!==self.FileReaderSync&&(r=new self.FileReaderSync);var i=function(e,t,n,r,i,o){var s=void 0,a=o%4,h=(i+a)%4,c=i-h;switch(a){case 0:t[o]=e[r+3];case 1:t[o+1-(a<<1)|0]=e[r+2];case 2:t[o+2-(a<<1)|0]=e[r+1];case 3:t[o+3-(a<<1)|0]=e[r]}if(!(i<h+(4-a))){for(s=4-a;s<c;s=s+4|0)n[o+s>>2|0]=e[r+s]<<24|e[r+s+1]<<16|e[r+s+2]<<8|e[r+s+3];switch(h){case 3:t[o+c+1|0]=e[r+c+2];case 2:t[o+c+2|0]=e[r+c+1];case 1:t[o+c+3|0]=e[r+c]}}};e.exports=function(e,t,o,s,a,h){if("string"==typeof e)return function(e,t,n,r,i,o){var s=void 0,a=o%4,h=(i+a)%4,c=i-h;switch(a){case 0:t[o]=e.charCodeAt(r+3);case 1:t[o+1-(a<<1)|0]=e.charCodeAt(r+2);case 2:t[o+2-(a<<1)|0]=e.charCodeAt(r+1);case 3:t[o+3-(a<<1)|0]=e.charCodeAt(r)}if(!(i<h+(4-a))){for(s=4-a;s<c;s=s+4|0)n[o+s>>2]=e.charCodeAt(r+s)<<24|e.charCodeAt(r+s+1)<<16|e.charCodeAt(r+s+2)<<8|e.charCodeAt(r+s+3);switch(h){case 3:t[o+c+1|0]=e.charCodeAt(r+c+2);case 2:t[o+c+2|0]=e.charCodeAt(r+c+1);case 1:t[o+c+3|0]=e.charCodeAt(r+c)}}}(e,t,o,s,a,h);if(e instanceof Array)return i(e,t,o,s,a,h);if(n&&n.Buffer&&n.Buffer.isBuffer(e))return i(e,t,o,s,a,h);if(e instanceof ArrayBuffer)return i(new Uint8Array(e),t,o,s,a,h);if(e.buffer instanceof ArrayBuffer)return i(new Uint8Array(e.buffer,e.byteOffset,e.byteLength),t,o,s,a,h);if(e instanceof Blob)return function(e,t,n,i,o,s){var a=void 0,h=s%4,c=(o+h)%4,u=o-c,l=new Uint8Array(r.readAsArrayBuffer(e.slice(i,i+o)));switch(h){case 0:t[s]=l[3];case 1:t[s+1-(h<<1)|0]=l[2];case 2:t[s+2-(h<<1)|0]=l[1];case 3:t[s+3-(h<<1)|0]=l[0]}if(!(o<c+(4-h))){for(a=4-h;a<u;a=a+4|0)n[s+a>>2|0]=l[a]<<24|l[a+1]<<16|l[a+2]<<8|l[a+3];switch(c){case 3:t[s+u+1|0]=l[u+2];case 2:t[s+u+2|0]=l[u+1];case 1:t[s+u+3|0]=l[u]}}}(e,t,o,s,a,h);throw new Error("Unsupported data type.")}},function(e,t,n){var r=n(0),i=n(1).toHex,o=function(){function e(){!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e),this._rusha=new r,this._rusha.resetState()}return e.prototype.update=function(e){return this._rusha.append(e),this},e.prototype.digest=function(e){var t=this._rusha.rawEnd().buffer;if(!e)return t;if("hex"===e)return i(t);throw new Error("unsupported digest encoding")},e}();e.exports=function(){return new o}}])},"object"==typeof ot.exports?ot.exports=tt():"object"==typeof ot.exports?ot.exports.Rusha=tt():et.Rusha=tt(),ot=ot.exports;var st,at=new ot,ht="undefined"!=typeof window?window:self,ct=ht.crypto||ht.msCrypto||{},ut=ct.subtle||ct.webkitSubtle;function lt(e){return at.digest(e)}try{ut.digest({name:"sha-1"},new Uint8Array).catch((function(){ut=!1}))}catch(dt){ut=!1}(st=function(e,t){ut?("string"==typeof e&&(e=function(e){for(var t=e.length,n=new Uint8Array(t),r=0;r<t;r++)n[r]=e.charCodeAt(r);return n}(e)),ut.digest({name:"sha-1"},e).then((function(e){t(function(e){for(var t=e.length,n=[],r=0;r<t;r++){var i=e[r];n.push((i>>>4).toString(16)),n.push((15&i).toString(16))}return n.join("")}(new Uint8Array(e)))}),(function(){t(lt(e))}))):"undefined"!=typeof window?function(e,t){nt||(nt=ot.createWorker(),rt=1,it={},nt.onmessage=function(e){var t=e.data.id,n=it[t];delete it[t],null!=e.data.error?n(new Error("Rusha worker error: "+e.data.error)):n(null,e.data.hash)}),it[rt]=t,nt.postMessage({id:rt,data:e}),rt+=1}(e,(function(n,r){t(n?lt(e):r)})):queueMicrotask(()=>t(lt(e)))}).sync=lt;var ft={};return function(e){const t=k("p2pt");ft=class extends q{constructor(e=[],n=""){super(),this.announceURLs=e,this.trackers={},this.peers={},this.msgChunks={},this.responseWaiting={},n&&this.setIdentifier(n),this._peerIdBuffer=H(20),this._peerId=this._peerIdBuffer.toString("hex"),this._peerIdBinary=this._peerIdBuffer.toString("binary"),t("my peer id: "+this._peerId)}setIdentifier(t){this.identifierString=t,this.infoHash=st.sync(t).toLowerCase(),this._infoHashBuffer=e.from(this.infoHash,"hex"),this._infoHashBinary=this._infoHashBuffer.toString("binary")}start(){this.on("peer",e=>{let n=!1;this.peers[e.id]||(n=!0,this.peers[e.id]={},this.responseWaiting[e.id]={}),e.on("connect",()=>{this.peers[e.id][e.channelName]=e,n&&this.emit("peerconnect",e)}),e.on("data",n=>{if(this.emit("data",e,n),n=n.toString(),t("got a message from "+e.id),"^"===n[0])try{n=JSON.parse(n.slice(1)),e.respond=this._peerRespond(e,n.id);let t=this._chunkHandler(n);!1!==t&&(n.o&&(t=JSON.parse(t)),this.responseWaiting[e.id][n.id]?(this.responseWaiting[e.id][n.id]([e,t]),delete this.responseWaiting[e.id][n.id]):this.emit("msg",e,t),this._destroyChunks(n.id))}catch(r){console.log(r)}}),e.on("error",n=>{this._removePeer(e),t("Error in connection : "+n)}),e.on("close",()=>{this._removePeer(e),t("Connection closed with "+e.id)})}),this.on("update",e=>{const t=this.trackers[this.announceURLs.indexOf(e.announce)];this.emit("trackerconnect",t,this.getTrackerStats())}),this.on("warning",e=>{this.emit("trackerwarning",e,this.getTrackerStats())}),this._fetchPeers()}_removePeer(e){if(!this.peers[e.id])return!1;delete this.peers[e.id][e.channelName],0===Object.keys(this.peers[e.id]).length&&(this.emit("peerclose",e),delete this.responseWaiting[e.id],delete this.peers[e.id])}send(e,n,r=""){return new Promise((i,o)=>{const s={id:""!==r?r:Math.floor(1e5*Math.random()+1e5),msg:n};"object"==typeof n&&(s.msg=JSON.stringify(n),s.o=1);try{if(!e.connected)for(const t in this.peers[e.id])if((e=this.peers[e.id][t]).connected)break;this.responseWaiting[e.id]||(this.responseWaiting[e.id]={}),this.responseWaiting[e.id][s.id]=i}catch(c){return o(Error("Connection to peer closed"+c))}let a=0,h="";for(;s.msg.length>0;)s.c=a,h=s.msg.slice(16e3),s.msg=s.msg.slice(0,16e3),h||(s.last=!0),e.send("^"+JSON.stringify(s)),s.msg=h,a++;t("sent a message to "+e.id)})}requestMorePeers(){return new Promise(e=>{for(const t in this.trackers)this.trackers[t].announce({numwant:50});e(this.peers)})}getTrackerStats(){let e=0;for(const t in this.trackers)this.trackers[t].socket&&this.trackers[t].socket.connected&&e++;return{connected:e,total:this.announceURLs.length}}destroy(){let e;for(e in this.peers)for(const t in this.peers[e])this.peers[e][t].destroy();for(e in this.trackers)this.trackers[e].destroy()}_peerRespond(e,t){return n=>this.send(e,n,t)}_chunkHandler(e){return this.msgChunks[e.id]||(this.msgChunks[e.id]=[]),this.msgChunks[e.id][e.c]=e.msg,!!e.last&&this.msgChunks[e.id].join("")}_destroyChunks(e){delete this.msgChunks[e]}_defaultAnnounceOpts(e={}){return null==e.numwant&&(e.numwant=50),null==e.uploaded&&(e.uploaded=0),null==e.downloaded&&(e.downloaded=0),e}_fetchPeers(){for(const e in this.announceURLs)this.trackers[e]=new Ke(this,this.announceURLs[e]),this.trackers[e].announce({numwant:50})}}}.call(this,u({}).Buffer),ft}));

/***/ }),

/***/ "../tetris-core/dist/controller/game.js":
/*!******************************************************************!*\
  !*** d:/Repositories/tetris/tetris-core/dist/controller/game.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var model_1 = __webpack_require__(/*! ../model */ "../tetris-core/dist/model/index.js");
var full_board_exception_1 = __webpack_require__(/*! ../exceptions/full-board.exception */ "../tetris-core/dist/exceptions/full-board.exception.js");
var Game = /** @class */ (function () {
    function Game() {
        this.gameId = 0;
        this.scoring = new model_1.ScoringSystem();
        this.levels = [];
        this.currentLevelIndex = -1;
        this.board = new model_1.Board();
    }
    Game.prototype.init = function () {
        this.attachToController();
        this.view.setupBoard(model_1.Board.ROWS, model_1.Board.COLUMNS);
        this.view.drawBoard(this.board);
        this.initializeLevels();
    };
    Game.prototype.newGame = function () {
        this.view.showSingleOrMultiplayerOptions();
    };
    Game.prototype.changeMultiplayerConnection = function (singleOrMultiplayerConnection) {
        this.multiplayer = singleOrMultiplayerConnection;
        this.attachToMultiplayer();
    };
    Game.prototype.singlePlayerOptionSelected = function () {
        this.view.hideSingleOrMultiplayerOptions();
        this.start();
    };
    Game.prototype.multiplayerOptionSelected = function () {
        this.view.hideSingleOrMultiplayerOptions();
        this.view.showMultiplayerOptionsCreateOrJoinGame();
    };
    Game.prototype.createMultiplayerGame = function () {
        this.view.hideCreateOrJoinGame();
        this.gameId = this.multiplayer.createNewGame();
        this.showMultiplayerGameId();
    };
    Game.prototype.joinGame = function () {
        this.view.hideCreateOrJoinGame();
        this.view.showEnterGameId();
    };
    Game.prototype.joinGameWithId = function (gameId) {
        this.gameId = gameId;
        this.multiplayer.joinGame(gameId);
        this.view.hideEnterGameId();
    };
    Game.prototype.showMultiplayerGameId = function () {
        this.view.showNewMultiplayerGameCreateWithId(this.gameId);
    };
    Game.prototype.mute = function () {
        this.soundPlayer.mute();
    };
    Game.prototype.unMute = function () {
        this.soundPlayer.unMute();
    };
    Game.prototype.start = function () {
        this.currentLevelIndex = -1;
        this.scoring.reset();
        this.view.hideGameOver();
        this.startNewLevel();
    };
    Game.prototype.initializeLevels = function () {
        this.levels = model_1.LevelFactory.Levels();
    };
    Game.prototype.attachToController = function () {
        var _this = this;
        this.controller.onMoveLeft(function () { return _this.moveLeft(); });
        this.controller.onMoveRight(function () { return _this.moveRight(); });
        this.controller.onMoveDown(function () { return _this.moveDown(); });
        this.controller.onRotate(function () { return _this.rotate(); });
    };
    Game.prototype.attachToMultiplayer = function () {
        var _this = this;
        this.multiplayer.onPlayer2BoardUpdated(function (board) { return _this.updatePlayer2Board(board); });
        this.multiplayer.onPlayer2PieceUpdated(function (piece) { return _this.updatePlayer2Piece(piece); });
        this.multiplayer.onPlayer2Connected(function () { return _this.player2Connected(); });
    };
    Game.prototype.player2Connected = function () {
        this.view.hideNewMultiplayerGameCreateWithId();
        this.start();
    };
    Game.prototype.updatePlayer2Piece = function (piece) {
        this.view.drawPlayer2Piece(piece);
    };
    Game.prototype.updatePlayer2Board = function (board) {
        this.view.drawPlayer2Board(board);
    };
    Game.prototype.moveLeft = function () {
        var pieceInNewPosition = this.piece.clone();
        pieceInNewPosition.moveLeft();
        this.movePieceToNewPositionIfNoCollision(pieceInNewPosition);
    };
    Game.prototype.moveRight = function () {
        var pieceInNewPosition = this.piece.clone();
        pieceInNewPosition.moveRight();
        this.movePieceToNewPositionIfNoCollision(pieceInNewPosition);
    };
    Game.prototype.moveDown = function () {
        return __awaiter(this, void 0, void 0, function () {
            var pieceInNewPosition;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        pieceInNewPosition = this.piece.clone();
                        pieceInNewPosition.moveDown();
                        if (!!this.movePieceToNewPositionIfNoCollision(pieceInNewPosition)) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.freezePiece()];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2: return [2 /*return*/];
                }
            });
        });
    };
    Game.prototype.rotate = function () {
        var pieceInNewPosition = this.piece.clone();
        pieceInNewPosition.rotate();
        if (this.movePieceToNewPositionIfNoCollision(pieceInNewPosition)) {
            this.soundPlayer.playRotate();
        }
    };
    Game.prototype.freezePiece = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.pauseFallingPiece();
                        this.controller.lock();
                        this.freezePieceOnDashboard();
                        this.calculateScoringForNewFreezedPiece();
                        return [4 /*yield*/, this.removeLinesIfAny()];
                    case 1:
                        _a.sent();
                        try {
                            if (this.nextPiece) {
                                this.putNextPieceIntoBoard();
                                this.controller.unlock();
                                this.startFallingPiece();
                            }
                            else {
                                this.levelCompleted();
                            }
                        }
                        catch (error) {
                            if (error instanceof full_board_exception_1.FullBoardException) {
                                this.gameOver();
                            }
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    Game.prototype.freezePieceOnDashboard = function () {
        this.board.freezePiece(this.piece);
        this.drawBoard();
        this.soundPlayer.playFreeze();
    };
    Game.prototype.calculateScoringForNewFreezedPiece = function () {
        this.scoring.pieceDrop(this.currentLevelIndex + 1);
        this.showScore();
    };
    Game.prototype.showScore = function () {
        var score = this.scoring.getScore();
        this.view.showScore(score);
    };
    Game.prototype.levelCompleted = function () {
        var _this = this;
        this.soundPlayer.stopMusicBackground();
        this.view.showLevelCompleted();
        this.soundPlayer.playLevelComplete();
        setTimeout(function () {
            _this.view.hideLevelCompleted();
            _this.startNewLevel();
        }, 5000);
    };
    Game.prototype.removeLinesIfAny = function () {
        return __awaiter(this, void 0, void 0, function () {
            var totalCompletedLines, completedLineInfo, lineIndex;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        totalCompletedLines = 0;
                        completedLineInfo = this.board.isACompletedLine();
                        _a.label = 1;
                    case 1:
                        if (!(completedLineInfo !== null)) return [3 /*break*/, 3];
                        totalCompletedLines++;
                        lineIndex = completedLineInfo.lineIndex;
                        return [4 /*yield*/, this.cleanALine(lineIndex)];
                    case 2:
                        _a.sent();
                        this.showTotalLines();
                        completedLineInfo = this.board.isACompletedLine();
                        return [3 /*break*/, 1];
                    case 3:
                        this.completedLinesCurrentLevel += totalCompletedLines;
                        if (totalCompletedLines > 0) {
                            this.scoring.linesPerClear(totalCompletedLines, this.currentLevelIndex + 1);
                            this.showScore();
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    Game.prototype.cleanALine = function (lineNumber) {
        return __awaiter(this, void 0, void 0, function () {
            var me, waitForContinue;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        me = this;
                        this.soundPlayer.playLineCompleted();
                        this.view.cleanLine(lineNumber);
                        waitForContinue = new Promise(function (resolve, reject) {
                            setTimeout(function () {
                                me.board.removeLine(lineNumber);
                                me.drawBoard();
                                resolve('');
                            }, 500);
                        });
                        return [4 /*yield*/, waitForContinue];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    Game.prototype.putNextPieceIntoBoard = function () {
        this.piece = this.nextPiece;
        this.centerPiece();
        this.drawPiece();
        this.moveNextShape();
    };
    Game.prototype.gameOver = function () {
        this.pauseFallingPiece();
        this.soundPlayer.stopMusicBackground();
        this.soundPlayer.playGameOver();
        this.view.showGameOver();
    };
    Game.prototype.moveNextShape = function () {
        var nextShape = this.level.getNextShape();
        if (nextShape) {
            this.nextPiece = new model_1.Piece(nextShape);
            this.drawNextShape();
        }
        else {
            this.nextPiece = null;
            this.view.cleanNextShape();
        }
    };
    Game.prototype.drawNextShape = function () {
        this.view.drawNextShape(this.nextPiece.shape);
    };
    Game.prototype.movePieceToNewPositionIfNoCollision = function (pieceInNewPosition) {
        var canAllocatePiece = this.board.canAllocatePiece(pieceInNewPosition);
        if (canAllocatePiece) {
            this.drawBoard();
            this.piece = pieceInNewPosition;
            this.drawPiece();
        }
        return canAllocatePiece;
    };
    Game.prototype.startNewLevel = function () {
        this.pauseFallingPiece();
        this.currentLevelIndex++;
        this.initLevelVariables();
        this.startLevelGame();
        this.startFallingPiece();
    };
    Game.prototype.initLevelVariables = function () {
        this.completedLinesCurrentLevel = 0;
        this.board.clean();
        this.level = this.levels[this.currentLevelIndex];
        this.level.init();
        this.piece = new model_1.Piece(this.level.getNextShape());
        this.nextPiece = new model_1.Piece(this.level.getNextShape());
    };
    Game.prototype.startLevelGame = function () {
        this.showNewLevelStart();
        this.showTotalLines();
        this.showScore();
        this.centerPiece();
        this.drawBoard();
        this.drawPiece();
        this.drawNextShape();
        this.playLevelMusic();
        this.resumeControl();
    };
    Game.prototype.resumeControl = function () {
        this.controller.unlock();
    };
    Game.prototype.playLevelMusic = function () {
        this.soundPlayer.playMusicBackground(this.currentLevelIndex);
    };
    Game.prototype.showTotalLines = function () {
        this.view.showTotalLines(this.completedLinesCurrentLevel);
    };
    Game.prototype.showNewLevelStart = function () {
        this.view.showNewLevelStart(this.currentLevelIndex + 1);
    };
    Game.prototype.startFallingPiece = function () {
        var me = this;
        this.fallingPieceInterval = setInterval(function () { return me.moveDown(); }, me.level.speed);
    };
    Game.prototype.pauseFallingPiece = function () {
        clearInterval(this.fallingPieceInterval);
    };
    Game.prototype.drawPiece = function () {
        this.view.drawPiece(this.piece);
        this.multiplayer.sendNewPieceToPlayer2(this.piece);
    };
    Game.prototype.drawBoard = function () {
        this.view.drawBoard(this.board);
        this.multiplayer.sendNewBoardToPlayer2(this.board);
    };
    Game.prototype.centerPiece = function () {
        var boardMiddleX = this.board.getMiddleX();
        var shapeMiddleX = this.piece.shape.matrix.length / 2;
        this.piece.x = Math.floor(boardMiddleX - shapeMiddleX);
        this.piece.y = this.board.getTopY();
        if (!this.board.canAllocatePiece(this.piece)) {
            throw new full_board_exception_1.FullBoardException();
        }
    };
    return Game;
}());
exports.Game = Game;


/***/ }),

/***/ "../tetris-core/dist/controller/multiplayer.js":
/*!*************************************************************************!*\
  !*** d:/Repositories/tetris/tetris-core/dist/controller/multiplayer.js ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var p2pt_1 = __importDefault(__webpack_require__(/*! p2pt */ "../p2pt/src/p2pt.umd.min.js"));
var Multiplayer = /** @class */ (function () {
    function Multiplayer() {
        this.trackersAnnounceURLs = [
            'wss://tracker.openwebtorrent.com',
            'wss://tracker.sloppyta.co:443/announce',
            'wss://open.tube:443/tracker/socket',
            'ws://tracker.sloppyta.co:80/announce',
            'ws://tracker.btsync.cf:6969/announce',
        ];
    }
    Multiplayer.prototype.joinGame = function (gameId) {
        this.createP2PTInstance(gameId);
    };
    Multiplayer.prototype.createNewGame = function () {
        var gameId = this.createNewGameId();
        this.createP2PTInstance(gameId);
        return gameId;
    };
    Multiplayer.prototype.onPlayer2Connected = function (func) {
        this.player2Connected = func;
    };
    Multiplayer.prototype.onPlayer2PieceUpdated = function (func) {
        this.player2PieceUpdated = func;
    };
    Multiplayer.prototype.onPlayer2BoardUpdated = function (func) {
        this.player2BoardUpdated = func;
    };
    Multiplayer.prototype.sendNewBoardToPlayer2 = function (board) {
        var msg = {
            id: "[BOARD-UPDATED]",
            board: board
        };
        this.p2pt.send(this.peerPlayer2, msg);
    };
    Multiplayer.prototype.sendNewPieceToPlayer2 = function (piece) {
        var msg = {
            id: "[PIECE-UPDATED]",
            piece: piece
        };
        this.p2pt.send(this.peerPlayer2, msg);
    };
    Multiplayer.prototype.createNewGameId = function () {
        return new Date().getTime();
    };
    Multiplayer.prototype.createP2PTInstance = function (gameId) {
        var _this = this;
        var gameIdentifier = "tetris-" + gameId;
        console.log("\uD83D\uDE80 ~ file: multiplayer.ts ~ line 35 ~ Multiplayer ~ createP2PTInstance ~ gameIdentifier", gameIdentifier);
        this.p2pt = new p2pt_1.default(this.trackersAnnounceURLs, gameIdentifier);
        this.p2pt.on('trackerconnect', function (tracker, stats) { return _this.onConnectionSuccess(tracker, stats); });
        this.p2pt.on('peerconnect', function (peer) { return _this.onPeerConnected(peer); });
        this.p2pt.on('peerclose', function (peer) { return _this.onPeerClose(peer); });
        this.p2pt.on('msg', function (peer, msg) { return _this.onMessageReceived(peer, msg); });
        this.p2pt.start();
    };
    Multiplayer.prototype.onMessageReceived = function (peer, msg) {
        console.log("\uD83D\uDE80 ~ file: multiplayer.ts ~ line 45 ~ Multiplayer ~ onMessageReceived ~ peer", peer);
        console.log("\uD83D\uDE80 ~ file: multiplayer.ts ~ line 45 ~ Multiplayer ~ onMessageReceived ~ msg", msg);
        if (msg.id === "[BOARD-UPDATED]") {
            this.player2BoardUpdated(msg.board);
        }
        if (msg.id === "[PIECE-UPDATED]") {
            this.player2PieceUpdated(msg.piece);
        }
    };
    Multiplayer.prototype.onConnectionSuccess = function (tracker, stats) {
        console.log("\uD83D\uDE80 ~ file: multiplayer.ts ~ line 41 ~ Multiplayer ~ onConnectionSuccess ~ onConnectionSuccess");
        console.log('Connected to tracker : ' + tracker.announceUrl);
        console.log('Tracker stats : ' + JSON.stringify(stats));
    };
    Multiplayer.prototype.onPeerConnected = function (peer) {
        console.log("\uD83D\uDE80 ~ file: multiplayer.ts ~ line 47 ~ Multiplayer ~ onPeerConnected ~ onPeerConnected");
        this.peerPlayer2 = peer;
        this.player2Connected();
    };
    Multiplayer.prototype.onPeerClose = function (peer) {
        console.log("\uD83D\uDE80 ~ file: multiplayer.ts ~ line 52 ~ Multiplayer ~ onPeerClose ~ onPeerClose");
    };
    return Multiplayer;
}());
exports.Multiplayer = Multiplayer;


/***/ }),

/***/ "../tetris-core/dist/controller/single-player.js":
/*!***************************************************************************!*\
  !*** d:/Repositories/tetris/tetris-core/dist/controller/single-player.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var SinglePlayer = /** @class */ (function () {
    function SinglePlayer() {
    }
    SinglePlayer.prototype.sendNewBoardToPlayer2 = function (board) {
    };
    SinglePlayer.prototype.sendNewPieceToPlayer2 = function (piece) {
    };
    SinglePlayer.prototype.onPlayer2Connected = function (func) {
    };
    SinglePlayer.prototype.onPlayer2PieceUpdated = function (func) {
    };
    SinglePlayer.prototype.onPlayer2BoardUpdated = function (func) {
    };
    SinglePlayer.prototype.createNewGame = function () {
        return new Date().getTime();
    };
    SinglePlayer.prototype.joinGame = function (gameId) {
    };
    return SinglePlayer;
}());
exports.SinglePlayer = SinglePlayer;


/***/ }),

/***/ "../tetris-core/dist/exceptions/full-board.exception.js":
/*!**********************************************************************************!*\
  !*** d:/Repositories/tetris/tetris-core/dist/exceptions/full-board.exception.js ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var FullBoardException = /** @class */ (function (_super) {
    __extends(FullBoardException, _super);
    function FullBoardException() {
        var _this = _super.call(this, 'No space on top for new piece') || this;
        Object.setPrototypeOf(_this, FullBoardException.prototype);
        return _this;
    }
    return FullBoardException;
}(Error));
exports.FullBoardException = FullBoardException;


/***/ }),

/***/ "../tetris-core/dist/index.js":
/*!********************************************************!*\
  !*** d:/Repositories/tetris/tetris-core/dist/index.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(__webpack_require__(/*! ./controller/game */ "../tetris-core/dist/controller/game.js"));
__export(__webpack_require__(/*! ./controller/multiplayer */ "../tetris-core/dist/controller/multiplayer.js"));
__export(__webpack_require__(/*! ./controller/single-player */ "../tetris-core/dist/controller/single-player.js"));


/***/ }),

/***/ "../tetris-core/dist/model/block-style.js":
/*!********************************************************************!*\
  !*** d:/Repositories/tetris/tetris-core/dist/model/block-style.js ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var BlockStyle = /** @class */ (function () {
    function BlockStyle() {
    }
    return BlockStyle;
}());
exports.BlockStyle = BlockStyle;


/***/ }),

/***/ "../tetris-core/dist/model/board.js":
/*!**************************************************************!*\
  !*** d:/Repositories/tetris/tetris-core/dist/model/board.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var block_style_1 = __webpack_require__(/*! ./block-style */ "../tetris-core/dist/model/block-style.js");
var Board = /** @class */ (function () {
    function Board() {
        this.board = [];
        this.clean();
    }
    Board.prototype.removeLine = function (lineToRemove) {
        var newBoard = [];
        for (var r = 0; r < Board.ROWS; ++r) {
            var row = this.board[r];
            if (r !== lineToRemove) {
                newBoard.push(row);
            }
        }
        newBoard.unshift(this.createEmptyRow());
        this.board = newBoard;
    };
    Board.prototype.isACompletedLine = function () {
        for (var rowIndex = this.board.length - 1; rowIndex >= 0; rowIndex--) {
            var row = this.board[rowIndex];
            var completedLine = this.isRowCompleted(row);
            if (completedLine) {
                var completedLine_1 = new CompletedLineInfo(rowIndex);
                return completedLine_1;
            }
        }
        return null;
    };
    Board.prototype.isRowCompleted = function (row) {
        for (var columnIndex = 0; columnIndex < row.length; columnIndex++) {
            var value = row[columnIndex];
            if (value === null) {
                return false;
            }
        }
        return true;
    };
    Board.prototype.freezePiece = function (piece) {
        var matrix = piece.shape.matrix;
        for (var rowIndex = 0; rowIndex < matrix.length; rowIndex++) {
            var row = matrix[rowIndex];
            for (var columnIndex = 0; columnIndex < row.length; columnIndex++) {
                var value = row[columnIndex];
                if (value > 0) {
                    var xInBoard = columnIndex + piece.x;
                    var yInBoard = rowIndex + piece.y;
                    this.maskAsOccupied(xInBoard, yInBoard, piece);
                }
            }
        }
    };
    Board.prototype.canAllocatePiece = function (tentativePiece) {
        var matrix = tentativePiece.shape.matrix;
        for (var rowIndex = 0; rowIndex < matrix.length; rowIndex++) {
            var row = matrix[rowIndex];
            for (var columnIndex = 0; columnIndex < row.length; columnIndex++) {
                var value = row[columnIndex];
                if (value > 0) {
                    var tentativeXInBoard = columnIndex + tentativePiece.x;
                    var tentativeYInBoard = rowIndex + tentativePiece.y;
                    if ((tentativeXInBoard < 0) || (tentativeXInBoard > Board.COLUMNS - 1) ||
                        (tentativeYInBoard > Board.ROWS - 1) ||
                        this.isOccupied(tentativeXInBoard, tentativeYInBoard)) {
                        return false;
                    }
                }
            }
        }
        return true;
    };
    Board.prototype.maskAsOccupied = function (x, y, piece) {
        var blockStyle = new block_style_1.BlockStyle();
        blockStyle.fillStyle = piece.fillStyle();
        blockStyle.strokeStyle = piece.strokeStyle();
        this.board[y][x] = blockStyle;
    };
    Board.prototype.isOccupied = function (x, y) {
        var value = this.board[y][x];
        return value !== null;
    };
    Board.prototype.getTopY = function () {
        return 0;
    };
    Board.prototype.getMiddleX = function () {
        return Board.COLUMNS / 2;
    };
    Board.prototype.clean = function () {
        for (var r = 0; r < Board.ROWS; ++r) {
            this.board[r] = this.createEmptyRow();
        }
    };
    Board.prototype.createEmptyRow = function () {
        var emptyRow = [];
        for (var c = 0; c < Board.COLUMNS; ++c) {
            emptyRow[c] = null;
        }
        return emptyRow;
    };
    Board.COLUMNS = 10;
    Board.ROWS = 20;
    return Board;
}());
exports.Board = Board;
var CompletedLineInfo = /** @class */ (function () {
    function CompletedLineInfo(lineNumber) {
        this.lineIndex = lineNumber;
    }
    return CompletedLineInfo;
}());
exports.CompletedLineInfo = CompletedLineInfo;


/***/ }),

/***/ "../tetris-core/dist/model/index.js":
/*!**************************************************************!*\
  !*** d:/Repositories/tetris/tetris-core/dist/model/index.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(__webpack_require__(/*! ./board */ "../tetris-core/dist/model/board.js"));
__export(__webpack_require__(/*! ./level-factory */ "../tetris-core/dist/model/level-factory.js"));
__export(__webpack_require__(/*! ./level */ "../tetris-core/dist/model/level.js"));
__export(__webpack_require__(/*! ./piece */ "../tetris-core/dist/model/piece.js"));
__export(__webpack_require__(/*! ./scoring-system */ "../tetris-core/dist/model/scoring-system.js"));
__export(__webpack_require__(/*! ./shape */ "../tetris-core/dist/model/shape.js"));


/***/ }),

/***/ "../tetris-core/dist/model/level-factory.js":
/*!**********************************************************************!*\
  !*** d:/Repositories/tetris/tetris-core/dist/model/level-factory.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var level_1 = __webpack_require__(/*! ./level */ "../tetris-core/dist/model/level.js");
var shape_factory_1 = __webpack_require__(/*! ./shape-factory */ "../tetris-core/dist/model/shape-factory.js");
var LevelFactory = /** @class */ (function () {
    function LevelFactory() {
    }
    LevelFactory.Levels = function () {
        var levels = [];
        levels.push(this.createLevel(500, 30)); // 1
        levels.push(this.createLevel(450, 30)); // 2
        levels.push(this.createLevel(420, 30)); // 3
        levels.push(this.createLevel(400, 40)); // 4
        levels.push(this.createLevel(280, 40)); // 5
        levels.push(this.createLevel(270, 50)); // 6
        levels.push(this.createLevel(220, 50)); // 7
        levels.push(this.createLevel(200, 60)); // 8
        levels.push(this.createLevel(180, 70)); // 9
        levels.push(this.createLevel(130, 80)); // 10
        levels.push(this.createLevel(90, 2000)); // 11
        return levels;
    };
    LevelFactory.createLevel = function (speed, numberOfPieces) {
        var level = new level_1.Level(speed);
        for (var i = 0; i < numberOfPieces; i++) {
            level.addShapes(shape_factory_1.ShapeFactory.getRandom());
        }
        return level;
    };
    return LevelFactory;
}());
exports.LevelFactory = LevelFactory;


/***/ }),

/***/ "../tetris-core/dist/model/level.js":
/*!**************************************************************!*\
  !*** d:/Repositories/tetris/tetris-core/dist/model/level.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Level = /** @class */ (function () {
    function Level(speed) {
        this.nextShapeIndex = 0;
        this.shapes = [];
        this.speed = speed;
    }
    Level.prototype.init = function () {
        this.nextShapeIndex = 0;
    };
    Level.prototype.addShapes = function (shape) {
        this.shapes.push(shape);
    };
    Level.prototype.getNextShape = function () {
        var nextShape = null;
        if (this.nextShapeIndex < this.shapes.length) {
            nextShape = this.shapes[this.nextShapeIndex];
            this.nextShapeIndex++;
        }
        return nextShape;
    };
    return Level;
}());
exports.Level = Level;


/***/ }),

/***/ "../tetris-core/dist/model/piece.js":
/*!**************************************************************!*\
  !*** d:/Repositories/tetris/tetris-core/dist/model/piece.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Piece = /** @class */ (function () {
    function Piece(shape) {
        this.shape = shape;
    }
    Piece.prototype.moveLeft = function () {
        this.x--;
    };
    Piece.prototype.clone = function () {
        var clone = new Piece(this.shape.clone());
        clone.x = this.x;
        clone.y = this.y;
        return clone;
    };
    Piece.prototype.moveRight = function () {
        this.x++;
    };
    Piece.prototype.moveDown = function () {
        this.y++;
    };
    Piece.prototype.rotate = function () {
        this.shape.rotate();
    };
    Piece.prototype.strokeStyle = function () {
        return this.shape.strokeStyle;
    };
    Piece.prototype.fillStyle = function () {
        return this.shape.fillStyle;
    };
    return Piece;
}());
exports.Piece = Piece;


/***/ }),

/***/ "../tetris-core/dist/model/scoring-system.js":
/*!***********************************************************************!*\
  !*** d:/Repositories/tetris/tetris-core/dist/model/scoring-system.js ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var ScoringSystem = /** @class */ (function () {
    function ScoringSystem() {
        this.currentScore = 0;
        this.pieceDropLevelScoring = [
            1,
            1,
            2,
            2,
            5,
            5,
            7,
            7,
            8,
            10,
            10,
        ];
        this.lineLevelScoring = [
            [100, 400, 900, 2000],
            [100, 400, 900, 2000],
            [200, 800, 1800, 4000],
            [200, 800, 1800, 4000],
            [300, 1200, 2700, 6000],
            [400, 1500, 3600, 8000],
            [400, 1500, 3600, 8000],
            [600, 1500, 4000, 8000],
            [600, 1600, 4500, 9000],
            [700, 1700, 5000, 10000],
            [700, 2000, 5000, 10000],
        ];
    }
    ScoringSystem.prototype.linesPerClear = function (lines, currentLevel) {
        var levelIndex = currentLevel - 1;
        if (levelIndex >= this.lineLevelScoring.length) {
            levelIndex = this.lineLevelScoring.length - 1;
        }
        var level = this.lineLevelScoring[levelIndex];
        var lineIndex = lines - 1;
        var points = level[lineIndex];
        this.currentScore += points;
    };
    ScoringSystem.prototype.pieceDrop = function (currentLevel) {
        var levelIndex = currentLevel - 1;
        if (levelIndex >= this.pieceDropLevelScoring.length) {
            levelIndex = this.pieceDropLevelScoring.length - 1;
        }
        var pointsPerDrop = this.pieceDropLevelScoring[levelIndex];
        this.currentScore += pointsPerDrop;
    };
    ScoringSystem.prototype.reset = function () {
        this.currentScore = 0;
    };
    ScoringSystem.prototype.getScore = function () {
        return this.currentScore;
    };
    return ScoringSystem;
}());
exports.ScoringSystem = ScoringSystem;


/***/ }),

/***/ "../tetris-core/dist/model/shape-factory.js":
/*!**********************************************************************!*\
  !*** d:/Repositories/tetris/tetris-core/dist/model/shape-factory.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var shape_1 = __webpack_require__(/*! ./shape */ "../tetris-core/dist/model/shape.js");
var ShapeFactory = /** @class */ (function () {
    function ShapeFactory() {
    }
    ShapeFactory.getRandom = function () {
        var totalShapes = this.shapes.length;
        var randomShapeIndex = Math.floor(Math.random() * totalShapes);
        return this.shapes[randomShapeIndex]();
    };
    ShapeFactory.i = function () {
        var shape = new shape_1.Shape();
        shape.matrix = [[1, 1, 1, 1],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]];
        shape.fillStyle = '#F60005';
        shape.strokeStyle = '#F56F74';
        return shape;
    };
    ShapeFactory.o = function () {
        var shape = new shape_1.Shape();
        shape.matrix = [[1, 1],
            [1, 1]];
        shape.fillStyle = '#003AF4';
        shape.strokeStyle = '#6F8FF8';
        return shape;
    };
    ShapeFactory.j = function () {
        var shape = new shape_1.Shape();
        shape.matrix = [[1, 0, 0],
            [1, 1, 1],
            [0, 0, 0]];
        shape.fillStyle = '#F9DB34';
        shape.strokeStyle = '#FBEB8B';
        return shape;
    };
    ShapeFactory.l = function () {
        var shape = new shape_1.Shape();
        shape.matrix = [[0, 0, 1],
            [1, 1, 1],
            [0, 0, 0]];
        shape.fillStyle = '#C904F3';
        shape.strokeStyle = '#D284F4';
        return shape;
    };
    ShapeFactory.s = function () {
        var shape = new shape_1.Shape();
        shape.matrix = [[0, 1, 1],
            [1, 1, 0],
            [0, 0, 0]];
        shape.fillStyle = '#46CCFC';
        shape.strokeStyle = '#92E1FD';
        return shape;
    };
    ShapeFactory.t = function () {
        var shape = new shape_1.Shape();
        shape.matrix = [[0, 1, 0],
            [1, 1, 1],
            [0, 0, 0]];
        shape.fillStyle = '#55B218';
        shape.strokeStyle = '#9EEB82';
        return shape;
    };
    ShapeFactory.z = function () {
        var shape = new shape_1.Shape();
        shape.matrix = [[1, 1, 0],
            [0, 1, 1],
            [0, 0, 0]];
        shape.fillStyle = '#F19318';
        shape.strokeStyle = '#E9B061';
        return shape;
    };
    ShapeFactory.shapes = [
        ShapeFactory.i,
        ShapeFactory.o,
        ShapeFactory.j,
        ShapeFactory.l,
        ShapeFactory.s,
        ShapeFactory.t,
        ShapeFactory.z,
    ];
    return ShapeFactory;
}());
exports.ShapeFactory = ShapeFactory;


/***/ }),

/***/ "../tetris-core/dist/model/shape.js":
/*!**************************************************************!*\
  !*** d:/Repositories/tetris/tetris-core/dist/model/shape.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Shape = /** @class */ (function () {
    function Shape() {
    }
    Shape.prototype.clone = function () {
        var clone = new Shape();
        clone.matrix = JSON.parse(JSON.stringify(this.matrix));
        clone.strokeStyle = this.strokeStyle;
        clone.fillStyle = this.fillStyle;
        return clone;
    };
    Shape.prototype.rotate = function () {
        var _a;
        var _this = this;
        var N = this.matrix.length - 1; // use a constant
        // use arrow functions and nested map;
        var result = this.matrix.map(function (row, i) {
            return row.map(function (val, j) { return _this.matrix[N - j][i]; });
        });
        this.matrix.length = 0; // hold original array reference
        (_a = this.matrix).push.apply(_a, result); // Spread operator
    };
    return Shape;
}());
exports.Shape = Shape;


/***/ }),

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");




const routes = [];
class AppRoutingModule {
}
AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ factory: function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); }, imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppRoutingModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
                exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tetris_core_dist__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tetris-core/dist */ "../tetris-core/dist/index.js");
/* harmony import */ var tetris_core_dist__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tetris_core_dist__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var tetris_core_dist_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tetris-core/dist/model */ "../tetris-core/dist/model/index.js");
/* harmony import */ var tetris_core_dist_model__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(tetris_core_dist_model__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _key_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./key-controller */ "./src/app/key-controller.ts");
/* harmony import */ var _sound_manager__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./sound-manager */ "./src/app/sound-manager.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");








const _c0 = ["board"];
const _c1 = ["player2Board"];
const _c2 = ["next"];
function AppComponent_div_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "New Game Created with id:");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7, " Share this id to other player and wait for joining.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx_r0.gameId);
} }
function AppComponent_div_4_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "input", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function AppComponent_div_4_Template_input_ngModelChange_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r9.gameId = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "a", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function AppComponent_div_4_Template_a_click_2_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r10); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r11.onJoinGameWithId(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Join Game");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx_r1.gameId);
} }
function AppComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "a", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function AppComponent_div_5_Template_a_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r13); const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r12.onSinglePlayer(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Single");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "a", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function AppComponent_div_5_Template_a_click_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r13); const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r14.onMultiPlayer(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "Multiplayer");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function AppComponent_div_6_Template(rf, ctx) { if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "a", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function AppComponent_div_6_Template_a_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r16); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r15.onCreateGame(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Create");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "a", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function AppComponent_div_6_Template_a_click_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r16); const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r17.onJoinGame(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "Join");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function AppComponent_div_16_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "GAME OVER");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function AppComponent_div_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "LEVEL COMPLETED");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
const _c3 = function (a0, a1) { return { "playSound mb-menu": a0, "muteSound mb-menu": a1 }; };
class AppComponent {
    constructor() {
        this.title = 'tetris-view';
        this.game = new tetris_core_dist__WEBPACK_IMPORTED_MODULE_0__["Game"]();
        this.isMute = false;
        this.levelNumber = '';
        this.totalLines = '';
        this.score = 0;
        this.isGameOver = false;
        this.isLevelCompleted = false;
        this.backgroundLevelClass = 'backgroundLevel1';
        this.singleOrMultiplayerOptionsVisible = false;
        this.multiplayerOptionsCreateOrJoinVisible = false;
        this.newMultiplayerGameCreatedVisible = false;
        this.enterGameIdVisible = false;
        this.gameId = 0;
    }
    ngAfterViewInit() {
        this.game.view = this;
        this.game.controller = new _key_controller__WEBPACK_IMPORTED_MODULE_3__["KeyController"]();
        this.game.soundPlayer = new _sound_manager__WEBPACK_IMPORTED_MODULE_4__["SoundManager"]();
        this.game.init();
        this.setupNext();
    }
    showEnterGameId() {
        this.enterGameIdVisible = true;
    }
    getGameId() {
        return this.gameId;
    }
    hideEnterGameId() {
        this.enterGameIdVisible = false;
    }
    showNewMultiplayerGameCreateWithId(gameId) {
        this.gameId = gameId;
        this.newMultiplayerGameCreatedVisible = true;
    }
    hideNewMultiplayerGameCreateWithId() {
        this.newMultiplayerGameCreatedVisible = false;
    }
    hideCreateOrJoinGame() {
        this.multiplayerOptionsCreateOrJoinVisible = false;
    }
    showMultiplayerOptionsCreateOrJoinGame() {
        this.multiplayerOptionsCreateOrJoinVisible = true;
    }
    hideSingleOrMultiplayerOptions() {
        this.singleOrMultiplayerOptionsVisible = false;
    }
    showSingleOrMultiplayerOptions() {
        this.singleOrMultiplayerOptionsVisible = true;
    }
    onCreateGame() {
        this.game.createMultiplayerGame();
    }
    onJoinGame() {
        this.game.joinGame();
    }
    onSinglePlayer() {
        this.game.changeMultiplayerConnection(new tetris_core_dist__WEBPACK_IMPORTED_MODULE_0__["SinglePlayer"]());
        this.game.singlePlayerOptionSelected();
    }
    onJoinGameWithId() {
        this.game.joinGameWithId(this.gameId);
    }
    onMultiPlayer() {
        this.game.changeMultiplayerConnection(new tetris_core_dist__WEBPACK_IMPORTED_MODULE_0__["Multiplayer"]());
        this.game.multiplayerOptionSelected();
    }
    showGameOver() {
        this.isGameOver = true;
    }
    hideGameOver() {
        this.isGameOver = false;
    }
    showLevelCompleted() {
        this.isLevelCompleted = true;
    }
    hideLevelCompleted() {
        this.isLevelCompleted = false;
    }
    showScore(score) {
        this.score = score;
    }
    showNewLevelStart(levelNumber) {
        this.backgroundLevelClass = `backgroundLevel${levelNumber}`;
        this.levelNumber = '' + levelNumber;
    }
    showTotalLines(currentLevelLines) {
        this.totalLines = '' + currentLevelLines;
    }
    setupBoard(rows, columns) {
        this.board = this.canvasBoard.nativeElement.getContext('2d');
        this.setupGameBoard(rows, columns, this.board);
        this.cleanBoard(this.board);
        this.player2Board = this.player2CanvasBoard.nativeElement.getContext('2d');
        this.setupGameBoard(rows, columns, this.player2Board);
        this.cleanBoard(this.player2Board);
    }
    setupGameBoard(rows, columns, board) {
        const BLOCK_SIZE = 30;
        board.canvas.width = columns * BLOCK_SIZE;
        board.canvas.height = rows * BLOCK_SIZE;
        board.scale(BLOCK_SIZE, BLOCK_SIZE);
    }
    ngOnInit() { }
    onNewGame() {
        this.game.newGame();
    }
    onMuteOrUnmute() {
        if (this.isMute) {
            this.game.unMute();
        }
        else {
            this.game.mute();
        }
        this.isMute = !this.isMute;
    }
    drawPlayer2Piece(piece) {
        console.log(`🚀 ~ file: app.component.ts ~ line 176 ~ AppComponent ~ drawPlayer2Piece ~ piece`, piece);
    }
    showPlayer2Score(score) {
        console.log(`🚀 ~ file: app.component.ts ~ line 180 ~ AppComponent ~ showPlayer2Score ~ score`, score);
    }
    showPlayer2TotalLines(currentLevelLines) {
        console.log(`🚀 ~ file: app.component.ts ~ line 184 ~ AppComponent ~ showPlayer2TotalLines ~ currentLevelLines`, currentLevelLines);
    }
    cleanLine(lineIndex) {
        for (let x = 0; x < tetris_core_dist_model__WEBPACK_IMPORTED_MODULE_2__["Board"].ROWS + 1; x++) {
            this.board.fillStyle = '#DB83DB';
            this.board.strokeStyle = '#A09FDD';
            this.board.lineWidth = 0.1;
            this.roundRect(this.board, x, lineIndex, 1, 1, 0.3);
            this.board.fill();
            this.board.stroke();
        }
    }
    setupNext() {
        this.next = this.canvasNext.nativeElement.getContext('2d');
        const BLOCK_SIZE = 20;
        const MAX_BLOCKS_PER_PIECE = 4 + 1; // extra 1 to avoid borders cut
        this.next.canvas.width = MAX_BLOCKS_PER_PIECE * BLOCK_SIZE;
        this.next.canvas.height = MAX_BLOCKS_PER_PIECE * BLOCK_SIZE;
        this.next.scale(BLOCK_SIZE, BLOCK_SIZE);
    }
    drawNextShape(nextShape) {
        const shapeMiddleX = nextShape.matrix.length / 2;
        const offsetX = Math.floor(2 - shapeMiddleX) + 0.5;
        const offsetY = 0.5;
        this.cleanNextShape();
        nextShape.matrix.forEach((row, y) => {
            row.forEach((value, x) => {
                if (value > 0) {
                    this.next.strokeStyle = nextShape.strokeStyle;
                    this.next.fillStyle = nextShape.fillStyle;
                    this.next.lineWidth = 0.1;
                    this.roundRect(this.next, x + offsetX, y + offsetY, 1, 1, 0.3);
                    this.next.fill();
                    this.next.stroke();
                }
            });
        });
    }
    /**
     * Draws a rounded rectangle using the current state of the canvas.
     * If you omit the last three params, it will draw a rectangle
     * outline with a 5 pixel border radius
     * @param {CanvasRenderingContext2D} ctx
     * @param {Number} x The top left x coordinate
     * @param {Number} y The top left y coordinate
     * @param {Number} width The width of the rectangle
     * @param {Number} height The height of the rectangle
     * @param {Number} [radius = 5] The corner radius; It can also be an object to specify different radii for corners
     * @param {Number} [radius.tl = 0] Top left
     * @param {Number} [radius.tr = 0] Top right
     * @param {Number} [radius.br = 0] Bottom right
     * @param {Number} [radius.bl = 0] Bottom left
     */
    roundRect(ctx, x, y, width, height, radius) {
        if (typeof radius === 'undefined') {
            radius = 5;
        }
        let allRadius = { tl: 0, tr: 0, br: 0, bl: 0 };
        if (typeof radius === 'number') {
            allRadius = { tl: radius, tr: radius, br: radius, bl: radius };
        }
        else {
            const defaultRadius = { tl: 0, tr: 0, br: 0, bl: 0 };
            // tslint:disable-next-line:forin
            for (const side in defaultRadius) {
                allRadius[side] = allRadius[side] || defaultRadius[side];
            }
        }
        ctx.beginPath();
        ctx.moveTo(x + allRadius.tl, y);
        ctx.lineTo(x + width - allRadius.tr, y);
        ctx.quadraticCurveTo(x + width, y, x + width, y + allRadius.tr);
        ctx.lineTo(x + width, y + height - allRadius.br);
        ctx.quadraticCurveTo(x + width, y + height, x + width - allRadius.br, y + height);
        ctx.lineTo(x + allRadius.bl, y + height);
        ctx.quadraticCurveTo(x, y + height, x, y + height - allRadius.bl);
        ctx.lineTo(x, y + allRadius.tl);
        ctx.quadraticCurveTo(x, y, x + allRadius.tl, y);
        ctx.closePath();
    }
    cleanNextShape() {
        this.next.clearRect(0, 0, this.next.canvas.width, this.next.canvas.height);
    }
    drawPiece(piece) {
        piece.shape.matrix.forEach((row, y) => {
            row.forEach((value, x) => {
                if (value > 0) {
                    const fromX = x + piece.x;
                    const toY = y + piece.y;
                    this.board.strokeStyle = piece.strokeStyle();
                    this.board.fillStyle = piece.fillStyle();
                    this.board.lineWidth = 0.1;
                    this.roundRect(this.board, fromX, toY, 1, 1, 0.3);
                    this.board.fill();
                    this.board.stroke();
                }
            });
        });
    }
    cleanBoard(board) {
        board.fillStyle = 'black';
        board.fillRect(0, 0, board.canvas.width, board.canvas.height);
    }
    drawBoard(board) {
        this.drawGameBoard(this.board, board);
    }
    drawPlayer2Board(board) {
        this.drawGameBoard(this.player2Board, board);
    }
    drawGameBoard(canvasBoard, board) {
        this.cleanBoard(canvasBoard);
        board.board.forEach((row, y) => {
            row.forEach((value, x) => {
                if (value !== null) {
                    canvasBoard.strokeStyle = value.strokeStyle;
                    canvasBoard.fillStyle = value.fillStyle;
                    canvasBoard.lineWidth = 0.1;
                    this.roundRect(canvasBoard, x, y, 1, 1, 0.3);
                    canvasBoard.fill();
                    canvasBoard.stroke();
                }
            });
        });
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(); };
AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], viewQuery: function AppComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_c0, true);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_c1, true);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_c2, true);
    } if (rf & 2) {
        var _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.canvasBoard = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.player2CanvasBoard = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.canvasNext = _t.first);
    } }, decls: 38, vars: 17, consts: [[1, "header"], [1, "title"], ["class", "window-layer", 4, "ngIf"], [1, "menu"], ["href", "#", 1, "newGame", "mb-menu", 3, "click"], ["href", "#", 3, "ngClass", "click"], [1, "main"], ["id", "board", 1, "game-board"], ["board", ""], ["class", "gameOver", 4, "ngIf"], ["class", "levelCompleted", 4, "ngIf"], [1, "score"], ["id", "next", 1, "next"], ["next", ""], ["id", "score"], ["id", "lines"], ["id", "level"], ["id", "player2Board", 1, "game-board"], ["player2Board", ""], [1, "window-layer"], ["type", "text", "placeholder", "enter game id", 1, "form-control", 3, "ngModel", "ngModelChange"], ["href", "#", 1, "primary", 3, "click"], ["href", "#", 1, "secondary", 3, "click"], [1, "gameOver"], [1, "levelCompleted"]], template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "h1", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "TETRIS");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, AppComponent_div_3_Template, 8, 1, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, AppComponent_div_4_Template, 4, 1, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, AppComponent_div_5_Template, 5, 0, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, AppComponent_div_6_Template, 5, 0, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "a", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function AppComponent_Template_a_click_9_listener() { return ctx.onNewGame(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10, "New Game");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "a", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function AppComponent_Template_a_click_11_listener() { return ctx.onMuteOrUnmute(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](14, "canvas", 7, 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](16, AppComponent_div_16_Template, 3, 0, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](17, AppComponent_div_17_Template, 3, 0, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](20, "canvas", 12, 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](23, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](24, "Score: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](25, "span", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](26);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](27, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](28, "Lines: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](29, "span", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](30);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](31, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](32, "Level: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](33, "span", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](34);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](35, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](36, "canvas", 17, 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.newMultiplayerGameCreatedVisible);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.enterGameIdVisible);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.singleOrMultiplayerOptionsVisible);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.multiplayerOptionsCreateOrJoinVisible);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassMapInterpolate1"]("container ", ctx.backgroundLevelClass, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction2"](14, _c3, ctx.isMute, !ctx.isMute));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.isMute ? "Play Sound" : "Mute");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.isGameOver);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.isLevelCompleted);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.score);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.totalLines);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.levelNumber);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_5__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgClass"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["NgModel"]], styles: ["@font-face {\n  font-family: tetrisFont;\n  src: url(\"/assets/fonts/tetri.ttf\");\n}\n@font-face {\n  font-family: tetris2Font;\n  src: url(\"/assets/fonts/tetrisyde.ttf\");\n}\n@font-face {\n  font-family: tetris3Font;\n  src: url(\"/assets/fonts/muni.ttf\");\n}\n.header[_ngcontent-%COMP%] {\n  text-align: center;\n  max-width: 850px;\n}\n.container[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-around;\n  max-width: 850px;\n  padding: 40px;\n  border-radius: 5px;\n}\n.menu[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  margin: 5px;\n  min-width: 120px;\n}\n.main[_ngcontent-%COMP%] {\n  position: relative;\n}\n.mb-menu[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n}\n.score[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  font-family: tetris3Font;\n  font-size: xxx-large;\n  margin: 5px;\n  min-width: 130px;\n}\n.score[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  padding: 5px;\n  background-color: white;\n  border-radius: 5px;\n}\n.game-board[_ngcontent-%COMP%] {\n  border: double white;\n  border-radius: 5px;\n}\n.title[_ngcontent-%COMP%] {\n  font-family: tetris2Font;\n  padding-left: 100px;\n  font-size: medium;\n}\n#next[_ngcontent-%COMP%] {\n  position: absolute;\n  box-sizing: border-box;\n  background-color: black;\n  border: double white;\n  border-radius: 5px;\n}\n.newGame[_ngcontent-%COMP%] {\n  box-shadow: 3px 4px 0px 0px #1564ad;\n  background: linear-gradient(to bottom, #79bbff 5%, #378de5 100%);\n  background-color: #79bbff;\n  border-radius: 5px;\n  border: 1px solid #337bc4;\n  display: inline-block;\n  cursor: pointer;\n  color: #ffffff;\n  font-family: Arial;\n  font-size: 17px;\n  font-weight: bold;\n  padding: 5px;\n  text-decoration: none;\n  text-shadow: 0px 1px 0px #528ecc;\n}\n.newGame[_ngcontent-%COMP%]:hover {\n  background: linear-gradient(to bottom, #378de5 5%, #79bbff 100%);\n  background-color: #378de5;\n}\n.newGame[_ngcontent-%COMP%]:active {\n  position: relative;\n  top: 1px;\n}\n.muteSound[_ngcontent-%COMP%] {\n  box-shadow: 3px 4px 0px 0px #8a2a21;\n  background: linear-gradient(to bottom, #c62d1f 5%, #f24437 100%);\n  background-color: #c62d1f;\n  border-radius: 5px;\n  border: 1px solid #d02718;\n  display: inline-block;\n  cursor: pointer;\n  color: #ffffff;\n  font-family: Arial;\n  font-size: 17px;\n  font-weight: bold;\n  padding: 5px;\n  text-decoration: none;\n  text-shadow: 0px 1px 0px #810e05;\n}\n.muteSound[_ngcontent-%COMP%]:hover {\n  background: linear-gradient(to bottom, #f24437 5%, #c62d1f 100%);\n  background-color: #f24437;\n}\n.muteSound[_ngcontent-%COMP%]:active {\n  position: relative;\n  top: 1px;\n}\n.playSound[_ngcontent-%COMP%] {\n  box-shadow: 3px 4px 0px 0px #9acc85;\n  background: linear-gradient(to bottom, #74ad5a 5%, #68a54b 100%);\n  background-color: #74ad5a;\n  border-radius: 5px;\n  border: 1px solid #3b6e22;\n  display: inline-block;\n  cursor: pointer;\n  color: #ffffff;\n  font-family: Arial;\n  font-size: 17px;\n  font-weight: bold;\n  padding: 5px;\n  text-decoration: none;\n  text-shadow: 0px 1px 0px #92b879;\n}\n.playSound[_ngcontent-%COMP%]:hover {\n  background: linear-gradient(to bottom, #68a54b 5%, #74ad5a 100%);\n  background-color: #68a54b;\n}\n.playSound[_ngcontent-%COMP%]:active {\n  position: relative;\n  top: 1px;\n}\n.gallery[_ngcontent-%COMP%] {\n  margin-top: auto;\n}\n.gameOver[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 40%;\n  left: 12%;\n  font-family: tetris3Font;\n  font-size: 6em;\n  color: red;\n  text-align: center;\n  background-color: #000000c4;\n  border: double;\n  padding-left: 14px;\n  padding-right: 14px;\n}\n.levelCompleted[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 40%;\n  left: 7%;\n  font-family: tetris3Font;\n  font-size: 4em;\n  color: green;\n  text-align: center;\n  background-color: #000000c4;\n  border: double;\n  padding-left: 14px;\n  padding-right: 14px;\n}\n.backgroundLevel1[_ngcontent-%COMP%] {\n  background-image: url(\"/assets/img/airplane.jpg\");\n}\n.backgroundLevel2[_ngcontent-%COMP%] {\n  background-image: url(\"/assets/img/building.jpg\");\n}\n.backgroundLevel3[_ngcontent-%COMP%] {\n  background-image: url(\"/assets/img/heart.jpg\");\n}\n.backgroundLevel4[_ngcontent-%COMP%] {\n  background-image: url(\"/assets/img/robot.jpg\");\n}\n.backgroundLevel5[_ngcontent-%COMP%] {\n  background-image: url(\"/assets/img/cam.jpg\");\n}\n.backgroundLevel6[_ngcontent-%COMP%] {\n  background-image: url(\"/assets/img/ants.jpg\");\n}\n.backgroundLevel7[_ngcontent-%COMP%] {\n  background-image: url(\"/assets/img/falling.jpg\");\n}\n.backgroundLevel8[_ngcontent-%COMP%] {\n  background-image: url(\"/assets/img/missingPiece.jpg\");\n}\n.backgroundLevel9[_ngcontent-%COMP%] {\n  background-image: url(\"/assets/img/perfectSpot.jpg\");\n}\n.backgroundLevel10[_ngcontent-%COMP%] {\n  background-image: url(\"/assets/img/wherei.jpg\");\n}\n.backgroundLevel11[_ngcontent-%COMP%] {\n  background-image: url(\"/assets/img/matrix.jpg\");\n}\n.window-layer[_ngcontent-%COMP%] {\n  position: absolute;\n  border-radius: 5px;\n  padding: 15px;\n  top: 30%;\n  left: 370px;\n  z-index: 9999;\n  background-color: #3f5c93;\n  width: 300px;\n  height: 150px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border: 1px solid #1f2f47;\n}\n.window-layer[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-family: tetris3Font;\n  font-size: xxx-large;\n}\n.window-layer[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  background-color: white;\n}\n.primary[_ngcontent-%COMP%] {\n  box-shadow: inset 0px 0px 15px 3px #23395e;\n  background: linear-gradient(to bottom, #2e466e 5%, #415989 100%);\n  background-color: #2e466e;\n  border-radius: 17px;\n  border: 1px solid #1f2f47;\n  display: inline-block;\n  cursor: pointer;\n  color: #ffffff;\n  font-family: Arial;\n  font-size: 15px;\n  padding: 6px 13px;\n  text-decoration: none;\n  text-shadow: 0px 1px 0px #263666;\n  margin: 15px;\n}\n.primary[_ngcontent-%COMP%]:hover {\n  background: linear-gradient(to bottom, #415989 5%, #2e466e 100%);\n  background-color: #415989;\n}\n.primary[_ngcontent-%COMP%]:active {\n  position: relative;\n  top: 1px;\n}\n.secondary[_ngcontent-%COMP%] {\n  box-shadow: inset 0px 0px 15px 3px #f29c93;\n  background: linear-gradient(to bottom, #fe1a00 5%, #ce0100 100%);\n  background-color: #fe1a00;\n  border-radius: 17px;\n  border: 1px solid #d83526;\n  display: inline-block;\n  cursor: pointer;\n  color: #ffffff;\n  font-family: Arial;\n  font-size: 15px;\n  padding: 6px 13px;\n  text-decoration: none;\n  text-shadow: 0px 1px 0px #b23e35;\n  margin: 15px;\n}\n.secondary[_ngcontent-%COMP%]:hover {\n  background: linear-gradient(to bottom, #ce0100 5%, #fe1a00 100%);\n  background-color: #ce0100;\n}\n.secondary[_ngcontent-%COMP%]:active {\n  position: relative;\n  top: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsdUJBQUE7RUFDQSxtQ0FBQTtBQUNGO0FBRUE7RUFDRSx3QkFBQTtFQUNBLHVDQUFBO0FBQUY7QUFHQTtFQUNFLHdCQUFBO0VBQ0Esa0NBQUE7QUFERjtBQUlBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtBQUZGO0FBS0E7RUFDRSxhQUFBO0VBQ0EsNkJBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtBQUZGO0FBS0E7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7QUFGRjtBQUtBO0VBQ0Usa0JBQUE7QUFGRjtBQUtBO0VBQ0UsbUJBQUE7QUFGRjtBQUtBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsOEJBQUE7RUFDQSx3QkFBQTtFQUNBLG9CQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0FBRkY7QUFJRTtFQUNFLFlBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0FBRko7QUFPQTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7QUFKRjtBQU9BO0VBQ0Usd0JBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0FBSkY7QUFPQTtFQUNFLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7QUFKRjtBQU9BO0VBQ0MsbUNBQUE7RUFDQSxnRUFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNDLFlBQUE7RUFDRCxxQkFBQTtFQUNBLGdDQUFBO0FBSkQ7QUFNQTtFQUNDLGdFQUFBO0VBQ0EseUJBQUE7QUFIRDtBQUtBO0VBQ0Msa0JBQUE7RUFDQSxRQUFBO0FBRkQ7QUFLQTtFQUNDLG1DQUFBO0VBQ0EsZ0VBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxxQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxnQ0FBQTtBQUZEO0FBSUE7RUFDQyxnRUFBQTtFQUNBLHlCQUFBO0FBREQ7QUFHQTtFQUNDLGtCQUFBO0VBQ0EsUUFBQTtBQUFEO0FBR0E7RUFDQyxtQ0FBQTtFQUNBLGdFQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EscUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0VBQ0EsZ0NBQUE7QUFBRDtBQUVBO0VBQ0MsZ0VBQUE7RUFDQSx5QkFBQTtBQUNEO0FBQ0E7RUFDQyxrQkFBQTtFQUNBLFFBQUE7QUFFRDtBQUNBO0VBQ0UsZ0JBQUE7QUFFRjtBQUNBO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLHdCQUFBO0VBQ0EsY0FBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLDJCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUFFRjtBQUNBO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsUUFBQTtFQUNBLHdCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLDJCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUFFRjtBQUNBO0VBQW9CLGlEQUFBO0FBR3BCO0FBRkE7RUFBb0IsaURBQUE7QUFNcEI7QUFMQTtFQUFvQiw4Q0FBQTtBQVNwQjtBQVJBO0VBQW9CLDhDQUFBO0FBWXBCO0FBWEE7RUFBb0IsNENBQUE7QUFlcEI7QUFkQTtFQUFvQiw2Q0FBQTtBQWtCcEI7QUFqQkE7RUFBb0IsZ0RBQUE7QUFxQnBCO0FBcEJBO0VBQW9CLHFEQUFBO0FBd0JwQjtBQXZCQTtFQUFvQixvREFBQTtBQTJCcEI7QUExQkE7RUFBcUIsK0NBQUE7QUE4QnJCO0FBN0JBO0VBQXFCLCtDQUFBO0FBaUNyQjtBQTlCQTtFQUNFLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsUUFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7QUFpQ0Y7QUEvQkU7RUFDRSx3QkFBQTtFQUNBLG9CQUFBO0FBaUNKO0FBL0JJO0VBQ0UsdUJBQUE7QUFpQ047QUE1QkE7RUFDQywwQ0FBQTtFQUNBLGdFQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0VBQ0EscUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EscUJBQUE7RUFDQSxnQ0FBQTtFQUNDLFlBQUE7QUErQkY7QUE3QkE7RUFDQyxnRUFBQTtFQUNBLHlCQUFBO0FBZ0NEO0FBOUJBO0VBQ0Msa0JBQUE7RUFDQSxRQUFBO0FBaUNEO0FBOUJBO0VBQ0MsMENBQUE7RUFDQSxnRUFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLHFCQUFBO0VBQ0EsZ0NBQUE7RUFDQyxZQUFBO0FBaUNGO0FBL0JBO0VBQ0MsZ0VBQUE7RUFDQSx5QkFBQTtBQWtDRDtBQWhDQTtFQUNDLGtCQUFBO0VBQ0EsUUFBQTtBQW1DRCIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBmb250LWZhY2Uge1xuICBmb250LWZhbWlseTogdGV0cmlzRm9udDtcbiAgc3JjOiB1cmwoJy9hc3NldHMvZm9udHMvdGV0cmkudHRmJyk7XG59XG5cbkBmb250LWZhY2Uge1xuICBmb250LWZhbWlseTogdGV0cmlzMkZvbnQ7XG4gIHNyYzogdXJsKCcvYXNzZXRzL2ZvbnRzL3RldHJpc3lkZS50dGYnKTtcbn1cblxuQGZvbnQtZmFjZSB7XG4gIGZvbnQtZmFtaWx5OiB0ZXRyaXMzRm9udDtcbiAgc3JjOiB1cmwoJy9hc3NldHMvZm9udHMvbXVuaS50dGYnKTtcbn1cblxuLmhlYWRlciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWF4LXdpZHRoOiA4NTBweDtcbn1cblxuLmNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xuICBtYXgtd2lkdGg6IDg1MHB4O1xuICBwYWRkaW5nOiA0MHB4O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG59XG5cbi5tZW51IHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgbWFyZ2luOiA1cHg7XG4gIG1pbi13aWR0aDogMTIwcHg7XG59XG5cbi5tYWluIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4ubWItbWVudSB7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59XG5cbi5zY29yZSB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgZm9udC1mYW1pbHk6IHRldHJpczNGb250O1xuICBmb250LXNpemU6IHh4eC1sYXJnZTtcbiAgbWFyZ2luOiA1cHg7XG4gIG1pbi13aWR0aDogMTMwcHg7XG5cbiAgcCB7XG4gICAgcGFkZGluZzogNXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcblxuICB9XG59XG5cbi5nYW1lLWJvYXJkIHtcbiAgYm9yZGVyOiBkb3VibGUgd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDVweCA7XG59XG5cbi50aXRsZSB7XG4gIGZvbnQtZmFtaWx5OiB0ZXRyaXMyRm9udDtcbiAgcGFkZGluZy1sZWZ0OiAxMDBweDtcbiAgZm9udC1zaXplOiBtZWRpdW07XG59XG5cbiNuZXh0IHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbiAgYm9yZGVyOiBkb3VibGUgd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbn1cblxuLm5ld0dhbWUge1xuXHRib3gtc2hhZG93OiAzcHggNHB4IDBweCAwcHggIzE1NjRhZDtcblx0YmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjNzliYmZmIDUlLCAjMzc4ZGU1IDEwMCUpO1xuXHRiYWNrZ3JvdW5kLWNvbG9yOiM3OWJiZmY7XG5cdGJvcmRlci1yYWRpdXM6NXB4O1xuXHRib3JkZXI6MXB4IHNvbGlkICMzMzdiYzQ7XG5cdGRpc3BsYXk6aW5saW5lLWJsb2NrO1xuXHRjdXJzb3I6cG9pbnRlcjtcblx0Y29sb3I6I2ZmZmZmZjtcblx0Zm9udC1mYW1pbHk6QXJpYWw7XG5cdGZvbnQtc2l6ZToxN3B4O1xuXHRmb250LXdlaWdodDpib2xkO1xuICBwYWRkaW5nOiA1cHg7XG5cdHRleHQtZGVjb3JhdGlvbjpub25lO1xuXHR0ZXh0LXNoYWRvdzowcHggMXB4IDBweCAjNTI4ZWNjO1xufVxuLm5ld0dhbWU6aG92ZXIge1xuXHRiYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICMzNzhkZTUgNSUsICM3OWJiZmYgMTAwJSk7XG5cdGJhY2tncm91bmQtY29sb3I6IzM3OGRlNTtcbn1cbi5uZXdHYW1lOmFjdGl2ZSB7XG5cdHBvc2l0aW9uOnJlbGF0aXZlO1xuXHR0b3A6MXB4O1xufVxuXG4ubXV0ZVNvdW5kIHtcblx0Ym94LXNoYWRvdzogM3B4IDRweCAwcHggMHB4ICM4YTJhMjE7XG5cdGJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgI2M2MmQxZiA1JSwgI2YyNDQzNyAxMDAlKTtcblx0YmFja2dyb3VuZC1jb2xvcjojYzYyZDFmO1xuXHRib3JkZXItcmFkaXVzOjVweDtcblx0Ym9yZGVyOjFweCBzb2xpZCAjZDAyNzE4O1xuXHRkaXNwbGF5OmlubGluZS1ibG9jaztcblx0Y3Vyc29yOnBvaW50ZXI7XG5cdGNvbG9yOiNmZmZmZmY7XG5cdGZvbnQtZmFtaWx5OkFyaWFsO1xuXHRmb250LXNpemU6MTdweDtcblx0Zm9udC13ZWlnaHQ6Ym9sZDtcblx0cGFkZGluZzo1cHg7XG5cdHRleHQtZGVjb3JhdGlvbjpub25lO1xuXHR0ZXh0LXNoYWRvdzowcHggMXB4IDBweCAjODEwZTA1O1xufVxuLm11dGVTb3VuZDpob3ZlciB7XG5cdGJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgI2YyNDQzNyA1JSwgI2M2MmQxZiAxMDAlKTtcblx0YmFja2dyb3VuZC1jb2xvcjojZjI0NDM3O1xufVxuLm11dGVTb3VuZDphY3RpdmUge1xuXHRwb3NpdGlvbjpyZWxhdGl2ZTtcblx0dG9wOjFweDtcbn1cblxuLnBsYXlTb3VuZCB7XG5cdGJveC1zaGFkb3c6IDNweCA0cHggMHB4IDBweCAjOWFjYzg1O1xuXHRiYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICM3NGFkNWEgNSUsICM2OGE1NGIgMTAwJSk7XG5cdGJhY2tncm91bmQtY29sb3I6Izc0YWQ1YTtcblx0Ym9yZGVyLXJhZGl1czo1cHg7XG5cdGJvcmRlcjoxcHggc29saWQgIzNiNmUyMjtcblx0ZGlzcGxheTppbmxpbmUtYmxvY2s7XG5cdGN1cnNvcjpwb2ludGVyO1xuXHRjb2xvcjojZmZmZmZmO1xuXHRmb250LWZhbWlseTpBcmlhbDtcblx0Zm9udC1zaXplOjE3cHg7XG5cdGZvbnQtd2VpZ2h0OmJvbGQ7XG5cdHBhZGRpbmc6NXB4O1xuXHR0ZXh0LWRlY29yYXRpb246bm9uZTtcblx0dGV4dC1zaGFkb3c6MHB4IDFweCAwcHggIzkyYjg3OTtcbn1cbi5wbGF5U291bmQ6aG92ZXIge1xuXHRiYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICM2OGE1NGIgNSUsICM3NGFkNWEgMTAwJSk7XG5cdGJhY2tncm91bmQtY29sb3I6IzY4YTU0Yjtcbn1cbi5wbGF5U291bmQ6YWN0aXZlIHtcblx0cG9zaXRpb246cmVsYXRpdmU7XG5cdHRvcDoxcHg7XG59XG5cbi5nYWxsZXJ5IHtcbiAgbWFyZ2luLXRvcDogYXV0bztcbn1cblxuLmdhbWVPdmVye1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNDAlO1xuICBsZWZ0OiAxMiU7XG4gIGZvbnQtZmFtaWx5OiB0ZXRyaXMzRm9udDtcbiAgZm9udC1zaXplOiA2ZW07XG4gIGNvbG9yOiByZWQ7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwMDAwMGM0O1xuICBib3JkZXI6IGRvdWJsZTtcbiAgcGFkZGluZy1sZWZ0OiAxNHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxNHB4O1xufVxuXG4ubGV2ZWxDb21wbGV0ZWR7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA0MCU7XG4gIGxlZnQ6IDclO1xuICBmb250LWZhbWlseTogdGV0cmlzM0ZvbnQ7XG4gIGZvbnQtc2l6ZTogNGVtO1xuICBjb2xvcjogZ3JlZW47XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwMDAwMGM0O1xuICBib3JkZXI6IGRvdWJsZTtcbiAgcGFkZGluZy1sZWZ0OiAxNHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxNHB4O1xufVxuXG4uYmFja2dyb3VuZExldmVsMSB7IGJhY2tncm91bmQtaW1hZ2U6IHVybCgnL2Fzc2V0cy9pbWcvYWlycGxhbmUuanBnJyk7fVxuLmJhY2tncm91bmRMZXZlbDIgeyBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy9hc3NldHMvaW1nL2J1aWxkaW5nLmpwZycpO31cbi5iYWNrZ3JvdW5kTGV2ZWwzIHsgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcvYXNzZXRzL2ltZy9oZWFydC5qcGcnKTt9XG4uYmFja2dyb3VuZExldmVsNCB7IGJhY2tncm91bmQtaW1hZ2U6IHVybCgnL2Fzc2V0cy9pbWcvcm9ib3QuanBnJyk7fVxuLmJhY2tncm91bmRMZXZlbDUgeyBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy9hc3NldHMvaW1nL2NhbS5qcGcnKTt9XG4uYmFja2dyb3VuZExldmVsNiB7IGJhY2tncm91bmQtaW1hZ2U6IHVybCgnL2Fzc2V0cy9pbWcvYW50cy5qcGcnKTt9XG4uYmFja2dyb3VuZExldmVsNyB7IGJhY2tncm91bmQtaW1hZ2U6IHVybCgnL2Fzc2V0cy9pbWcvZmFsbGluZy5qcGcnKTt9XG4uYmFja2dyb3VuZExldmVsOCB7IGJhY2tncm91bmQtaW1hZ2U6IHVybCgnL2Fzc2V0cy9pbWcvbWlzc2luZ1BpZWNlLmpwZycpO31cbi5iYWNrZ3JvdW5kTGV2ZWw5IHsgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcvYXNzZXRzL2ltZy9wZXJmZWN0U3BvdC5qcGcnKTt9XG4uYmFja2dyb3VuZExldmVsMTAgeyBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy9hc3NldHMvaW1nL3doZXJlaS5qcGcnKTt9XG4uYmFja2dyb3VuZExldmVsMTEgeyBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy9hc3NldHMvaW1nL21hdHJpeC5qcGcnKTt9XG5cblxuLndpbmRvdy1sYXllciB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBwYWRkaW5nOiAxNXB4O1xuICB0b3A6IDMwJTtcbiAgbGVmdDogMzcwcHg7XG4gIHotaW5kZXg6IDk5OTk7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYig2MywgOTIsIDE0Nyk7XG4gIHdpZHRoOiAzMDBweDtcbiAgaGVpZ2h0OiAxNTBweDtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGJvcmRlcjogMXB4IHNvbGlkICMxZjJmNDc7XG5cbiAgcCB7XG4gICAgZm9udC1mYW1pbHk6IHRldHJpczNGb250O1xuICAgIGZvbnQtc2l6ZTogeHh4LWxhcmdlO1xuXG4gICAgc3BhbiB7XG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgICB9XG4gIH1cbn1cblxuLnByaW1hcnkge1xuXHRib3gtc2hhZG93Omluc2V0IDBweCAwcHggMTVweCAzcHggIzIzMzk1ZTtcblx0YmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjMmU0NjZlIDUlLCAjNDE1OTg5IDEwMCUpO1xuXHRiYWNrZ3JvdW5kLWNvbG9yOiMyZTQ2NmU7XG5cdGJvcmRlci1yYWRpdXM6MTdweDtcblx0Ym9yZGVyOjFweCBzb2xpZCAjMWYyZjQ3O1xuXHRkaXNwbGF5OmlubGluZS1ibG9jaztcblx0Y3Vyc29yOnBvaW50ZXI7XG5cdGNvbG9yOiNmZmZmZmY7XG5cdGZvbnQtZmFtaWx5OkFyaWFsO1xuXHRmb250LXNpemU6MTVweDtcblx0cGFkZGluZzo2cHggMTNweDtcblx0dGV4dC1kZWNvcmF0aW9uOm5vbmU7XG5cdHRleHQtc2hhZG93OjBweCAxcHggMHB4ICMyNjM2NjY7XG4gIG1hcmdpbjogMTVweDtcbn1cbi5wcmltYXJ5OmhvdmVyIHtcblx0YmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjNDE1OTg5IDUlLCAjMmU0NjZlIDEwMCUpO1xuXHRiYWNrZ3JvdW5kLWNvbG9yOiM0MTU5ODk7XG59XG4ucHJpbWFyeTphY3RpdmUge1xuXHRwb3NpdGlvbjpyZWxhdGl2ZTtcblx0dG9wOjFweDtcbn1cblxuLnNlY29uZGFyeSB7XG5cdGJveC1zaGFkb3c6aW5zZXQgMHB4IDBweCAxNXB4IDNweCAjZjI5YzkzO1xuXHRiYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICNmZTFhMDAgNSUsICNjZTAxMDAgMTAwJSk7XG5cdGJhY2tncm91bmQtY29sb3I6I2ZlMWEwMDtcblx0Ym9yZGVyLXJhZGl1czoxN3B4O1xuXHRib3JkZXI6MXB4IHNvbGlkICNkODM1MjY7XG5cdGRpc3BsYXk6aW5saW5lLWJsb2NrO1xuXHRjdXJzb3I6cG9pbnRlcjtcblx0Y29sb3I6I2ZmZmZmZjtcblx0Zm9udC1mYW1pbHk6QXJpYWw7XG5cdGZvbnQtc2l6ZToxNXB4O1xuXHRwYWRkaW5nOjZweCAxM3B4O1xuXHR0ZXh0LWRlY29yYXRpb246bm9uZTtcblx0dGV4dC1zaGFkb3c6MHB4IDFweCAwcHggI2IyM2UzNTtcbiAgbWFyZ2luOiAxNXB4O1xufVxuLnNlY29uZGFyeTpob3ZlciB7XG5cdGJhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgI2NlMDEwMCA1JSwgI2ZlMWEwMCAxMDAlKTtcblx0YmFja2dyb3VuZC1jb2xvcjojY2UwMTAwO1xufVxuLnNlY29uZGFyeTphY3RpdmUge1xuXHRwb3NpdGlvbjpyZWxhdGl2ZTtcblx0dG9wOjFweDtcbn1cblxuXG4iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](AppComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"],
        args: [{
                selector: 'app-root',
                templateUrl: './app.component.html',
                styleUrls: ['./app.component.scss'],
            }]
    }], null, { canvasBoard: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
            args: ['board', { static: false }]
        }], player2CanvasBoard: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
            args: ['player2Board', { static: false }]
        }], canvasNext: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
            args: ['next', { static: false }]
        }] }); })();


/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");






class AppModule {
}
AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]] });
AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ factory: function AppModule_Factory(t) { return new (t || AppModule)(); }, providers: [], imports: [[
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]], imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
        _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](AppModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"],
        args: [{
                declarations: [
                    _app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]
                ],
                imports: [
                    _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                    _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"],
                    _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                ],
                providers: [],
                bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]]
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/key-controller.ts":
/*!***********************************!*\
  !*** ./src/app/key-controller.ts ***!
  \***********************************/
/*! exports provided: KeyController */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "KeyController", function() { return KeyController; });
class KeyController {
    constructor() {
        this.isAvailable = true;
        document.onkeydown = (e) => {
            switch (e.which) {
                case 37: // left
                    if (this.isAvailable) {
                        this.moveLef();
                    }
                    break;
                case 38: // up
                    if (this.isAvailable) {
                        this.rotate();
                    }
                    break;
                case 39: // right
                    if (this.isAvailable) {
                        this.moveRight();
                    }
                    break;
                case 40: // down
                    if (this.isAvailable) {
                        this.moveDown();
                    }
                    break;
                default:
                    return; // exit this handler for other keys
            }
            e.preventDefault(); // prevent the default action (scroll / move caret)
        };
    }
    onMoveDown(moveDown) {
        this.moveDown = moveDown;
    }
    onMoveRight(moveRight) {
        this.moveRight = moveRight;
    }
    onMoveLeft(moveLeft) {
        this.moveLef = moveLeft;
    }
    onRotate(rotate) {
        this.rotate = rotate;
    }
    lock() {
        this.isAvailable = false;
    }
    unlock() {
        this.isAvailable = true;
    }
}


/***/ }),

/***/ "./src/app/sound-manager.ts":
/*!**********************************!*\
  !*** ./src/app/sound-manager.ts ***!
  \**********************************/
/*! exports provided: SoundManager */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SoundManager", function() { return SoundManager; });
/* harmony import */ var _sound__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sound */ "./src/app/sound.ts");

class SoundManager {
    constructor() {
        this.effectFolder = '/assets/effects';
        this.musicFolder = '/assets/music';
        // EFFECTS
        this.trackRotate = `${this.effectFolder}/se_game_rotate.wav`;
        this.trackLine = `${this.effectFolder}/se_game_single.wav`;
        this.trackLevelCompleted = `${this.musicFolder}/10 - You Did It (Complete) - Tetris (Atari) (Arcade) - Soundtrack - Arcade.mp3`;
        this.trackFreeze = `${this.effectFolder}/se_game_hold.wav`;
        this.trackGameOver = `${this.musicFolder}/11 - Game Over - Tetris (Atari) (Arcade) - Soundtrack - Arcade.mp3`;
        // MUSIC
        this.trackLoginska = `${this.musicFolder}/02 - Loginska - Tetris (Atari) (Arcade) - Soundtrack - Arcade.mp3`;
        this.trackBradinsky = `${this.musicFolder}/04 - Bradinsky - Tetris (Atari) (Arcade) - Soundtrack - Arcade.mp3`;
        this.trackKalinka = `${this.musicFolder}/06 - Kalinka - Tetris (Atari) (Arcade) - Soundtrack - Arcade.mp3`;
        this.trackTroika = `${this.musicFolder}/08 - Troika - Tetris (Atari) (Arcade) - Soundtrack - Arcade.mp3`;
        this.musicLevelTrackList = [
            this.trackLoginska,
            this.trackBradinsky,
            this.trackKalinka,
            this.trackTroika,
            this.trackLoginska,
            this.trackBradinsky,
            this.trackKalinka,
            this.trackTroika,
        ];
        this.isMuted = false;
    }
    mute() {
        this.isMuted = true;
        if (this.musicBackground) {
            this.musicBackground.mute();
        }
    }
    unMute() {
        this.isMuted = false;
        if (this.musicBackground) {
            this.musicBackground.unMute();
        }
    }
    playGameOver() {
        this.playSound(this.trackGameOver);
    }
    playFreeze() {
        this.playSound(this.trackFreeze);
    }
    playRotate() {
        this.playSound(this.trackRotate);
    }
    playLineCompleted() {
        this.playSound(this.trackLine);
    }
    playLevelComplete() {
        this.playSound(this.trackLevelCompleted);
    }
    playMusicBackground(level) {
        let trackIndex = level;
        if (level >= this.musicLevelTrackList.length) {
            trackIndex = 0;
        }
        const src = this.musicLevelTrackList[trackIndex];
        this.playMusic(src);
    }
    stopMusicBackground() {
        this.musicBackground.stop();
    }
    playSound(src) {
        const sound = new _sound__WEBPACK_IMPORTED_MODULE_0__["Sound"](src);
        if (this.isMuted) {
            sound.mute();
        }
        sound.play();
        return sound;
    }
    playMusic(src) {
        if (this.musicBackground) {
            this.musicBackground.stop();
        }
        this.musicBackground = this.playSound(src);
        this.musicBackground.activateLoop();
    }
}


/***/ }),

/***/ "./src/app/sound.ts":
/*!**************************!*\
  !*** ./src/app/sound.ts ***!
  \**************************/
/*! exports provided: Sound */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Sound", function() { return Sound; });
class Sound {
    constructor(src) {
        this.createAudioElement(src);
        document.body.appendChild(this.audio);
    }
    createAudioElement(src) {
        this.audio = document.createElement('audio');
        this.audio.src = src;
        this.audio.preload = 'auto';
        this.audio.controls = false;
        this.audio.style.display = 'none';
        this.audio.volume = 0.2;
    }
    play() {
        const promise = this.audio.play();
        if (promise !== undefined) {
            promise.then(_ => {
                // Autoplay started!
            }).catch(error => {
                console.log(`🚀 ~ file: sound.ts ~ line 27 ~ Sound ~ play ~ error`, error);
                // Autoplay was prevented.
                // Show a "Play" button so that user can start playback.
            });
        }
    }
    stop() {
        this.audio.pause();
    }
    mute() {
        this.audio.muted = true;
    }
    unMute() {
        this.audio.muted = false;
    }
    activateLoop() {
        this.audio.loop = true;
    }
}


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\Repositories\tetris\tetris-view\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map